# -*- coding: utf-8 -*-
#𝑮𝒖𝒏𝒂𝒌𝒂𝒏𝒍𝒂𝒉 𝑺𝑪 𝒊𝒏𝒊 𝒅𝒆𝒏𝒈𝒂𝒏 𝒃𝒊𝒋𝒂𝒌,
#𝑯𝒂𝒓𝒈𝒂𝒊 𝒔𝒂𝒏𝒈 𝒄𝒓𝒆𝒂𝒕𝒐𝒓 𝒅𝒂𝒏 𝒋𝒂𝒏𝒈𝒂𝒏 𝒔𝒐𝒏𝒈𝒐𝒏𝒈 𝒂𝒕𝒂𝒖 𝒔𝒐𝒎𝒃𝒐𝒏𝒈 𝒋𝒊𝒌𝒂 𝒃𝒆𝒍𝒖𝒎 𝒃𝒊𝒔𝒂 𝒎𝒆𝒎𝒃𝒖𝒂𝒕 𝑺𝑪 𝒔𝒆𝒏𝒅𝒊𝒓𝒊.
#𝑫𝒊𝒂𝒕𝒂𝒔 𝒍𝒂𝒏𝒈𝒊𝒕 𝒎𝒂𝒔𝒊𝒉 𝒂𝒅𝒂 𝒍𝒂𝒏𝒈𝒊𝒕,𝒔𝒆𝒎𝒂𝒌𝒊𝒏 𝒌𝒊𝒕𝒂 𝒃𝒊𝒔𝒂 𝒎𝒆𝒎𝒃𝒖𝒂𝒕 𝒅𝒂𝒏 𝒎𝒆𝒎𝒂𝒉𝒂𝒎𝒊,
#𝒔𝒆𝒎𝒂𝒌𝒊𝒏𝒍𝒂𝒉 𝒃𝒊𝒋𝒂𝒌𝒔𝒂𝒏𝒂 𝒅𝒂𝒏 𝒃𝒊𝒔𝒂 𝒔𝒂𝒍𝒊𝒏𝒈 𝒎𝒆𝒏𝒈𝒉𝒂𝒓𝒈𝒂𝒊.
#-Bye: {Lea Killer} + (Angrust Lipro)
from leakiller import *
from threading import Thread
from multiprocessing import Pool, Process
from subprocess import check_output
from datetime import datetime
from time import sleep
from bs4 import BeautifulSoup
import time, random, pytz, atexit, ctypes, livejson, sys, shutil, json, codecs, ast, threading, glob, re, string, asyncio, os, traceback, requests, six, urllib, urllib.parse
#==============================================================================#
cl = LINE("panducahya969@gmail.com","panducahya26")
cl.log("Auth Token : " + str(cl.authToken))
ka = LINE("panducahya62@gmail.com","panducahya26")
ka.log("Auth Token : " + str(ka.authToken))
kb = LINE("fahriwahyu25@gmail.com","panducahya26")
kb.log("Auth Token : " + str(kb.authToken))
kc = LINE("botbaru822@gmail.com","panducahya26")
kc.log("Auth Token : " + str(kc.authToken))
kd = LINE("fahri.wahyu2007@gmail.com","panducahya26")
kd.log("Auth Token : " + str(kd.authToken))
ke = LINE("fahriwahyu1025@gmail.com","panducahya26")
ke.log("Auth Token : " + str(ke.authToken))
k1 = LINE("akunsingapore001@gmail.com","panducahya26")
k1.log("Auth Token : " + str(k1.authToken))
#==============[●●●●●●]==============#
print ("𝑳𝒐𝒈𝒊𝒏 𝑺𝒖𝒄𝒄𝒆𝒔")
call = cl
linePoll = OEPoll(cl)
Bismillah=[cl,ka,kb,kc,kd]
Amin=[ka,kb,kc,kd,ke]
Aakun=[kb,kc,kd,ke]
Bakun=[ka,kc,kd,ke]
Cakun=[ka,kb,kd,ke]
Dakun=[ka,kc,kb,ke]
Eakun=[ka,kb,kd,kc]
mid = cl.getProfile().mid
Amid = ka.getProfile().mid
Bmid = kb.getProfile().mid
Cmid = kc.getProfile().mid
Dmid = kd.getProfile().mid
Emid = ke.getProfile().mid
Smid = k1.getProfile().mid
Bots=[mid,Amid,Bmid,Cmid,Dmid,Emid,Smid]
Zie = ["u1e812bcfc29ed4d9eae95a64a59b9568"]
Lea = Bots+Zie
botlist=[cl,ka,kb,kc,kd,ke,k1]
msg_dict = {}
msg_dict1 = {}
#==============[ Main Json ]==============#
Leakiller = livejson.File('settingSB.json')
#================================#
wait = {
    "blacklist":{}
}
cctv = {
    "cyduk":{},
    "point":{},
    "sidermem":{}
}
mulai = time.time()
smuleaudio = {}
tz = pytz.timezone("Asia/Jakarta")
timeNow = datetime.now(tz=tz)
def cTime_to_datetime(unixtime):
    return datetime.fromtimestamp(int(str(unixtime)[:len(str(unixtime))-3]))
def dt_to_str(dt):
    return dt.strftime('%H:%M:%S')
def delete_log():
    ndt = datetime.now()
    for data in msg_dict:
        if (datetime.utcnow() - cTime_to_datetime(msg_dict[data]["createdTime"])) > timedelta(1):
            if "path" in msg_dict[data]:
                cl.deleteFile(msg_dict[data]["path"])
            del msg_dict[data]
def delete_log1():
    ndt = datetime.now()
    for data in msg_dict1:
        if (datetime.utcnow() - cTime_to_datetime(msg_dict1[data]["createdTime"])) > timedelta(1):
            del msg_dict1[msg_id]
def atend():
    with open("Log_data.json","w",encoding='utf8') as f:
        json.dump(msg_dict, f, ensure_ascii=False, indent=4,separators=(',', ': '))
atexit.register(atend)
def atend1():
    with open("Log_data.json","w",encoding='utf8') as f:
        json.dump(msg_dict1, f, ensure_ascii=False, indent=4,separators=(',', ': '))
atexit.register(atend)
def restart_program():
    python = sys.executable
    os.execl(python, python, * sys.argv)
def restartBot():
    python = sys.executable
    os.execl(python, python, *sys.argv)
def likePost(self, mid, postId, likeType=1001):
    if mid is None:
        mid = cl.profile.mid
    if likeType not in [1001,1002,1003,1004,1005,1006]:
        raise Exception('Invalid parameter likeType')
    params = {'homeId': mid, 'sourceType': 'TIMELINE'}
    url = cl.server.urlEncode(cl.server.LINE_TIMELINE_API, '/v23/like/create', params)
    data = {'likeType': likeType, 'postId': postId, 'actorId': mid}
    r = cl.server.postContent(url, data=data, headers=cl.server.channelHeaders)
    return r.json()
def createComment(self, mid, postId, text):
    if mid is None:
        mid = self.profile.mid
    params = {'homeId': mid, 'sourceType': 'TIMELINE'}
    url = self.server.urlEncode(self.server.LINE_TIMELINE_API, '/v39/comment/create.json', params)
    data = {'commentText': text, 'activityExternalId': postId, 'actorId': mid}
    data = json.dumps(data)
    r = self.server.postContent(url, data=data, headers=self.server.timelineHeaders)
    return r.json()
def waktu(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d Hari %02d Jam %02d Menit %02d Detik' % (days, hours, mins, secs)
def runtime(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d Hari %02d Jam %02d Menit %02d Detik' % (days, hours, mins, secs)
def welcomeMembers(to, mid):
    try:
        arrData = ""
        textx = "「Member Join {}」\ ".format(str(len(mid)))
        arr = []
        no = 1
        num = 2
        for i in mid:
            ginfo = cl.getGroup(to)
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention+Leakiller["sambutan"]+"\ndi group : "+str(ginfo.name)
            if no < len(mid):
                no += 1
                textx += "%i " % (num)
                num=(num+1)
            else:
                try:
                    no = "\n╚══[ {} ]".format(str(cl.getGroup(to).name))
                except:
                    no = "\n╚══[ Success ]"
        cl.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        cl.sendMessage(to, "[ INFO ] Error :\n" + str(error))
def command(text):
    pesan = text.lower()
    if pesan.startswith(Leakiller["keyCmd"]):
        cmd = pesan.replace(Leakiller["keyCmd"],"")
    else:
        cmd = "command"
    return cmd
def help():
    key = Leakiller["keyCmd"]
    key = key.title()
    helpMessage = "═══════✤𝐋𝐞𝐚✤═══════╗\n║「✤𝐌𝐄𝐍𝐔 𝐋𝐞𝐚 𝐊𝐢𝐥𝐥𝐞𝐫✤」\n╠═══════✤𝐋𝐞𝐚✤═══════╝\n" + \
                  "║┍✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝑴𝒆\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝑴𝒊𝒅 「@」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝑰𝒏𝒇𝒐「@」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝑲𝒊𝒄𝒌𝒆𝒓 𝒌𝒊𝒄𝒌「@」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝑲𝒊𝒔𝒔「@」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝑩𝒐𝒕 𝒌𝒊𝒄𝒌「@」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝒁1-5 𝒌𝒊𝒄𝒌「@」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝑨𝒅𝒅 𝒄𝒐𝒏「@」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝑴𝒚𝒃𝒐𝒕\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝑺𝒕𝒂𝒕𝒖𝒔\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝑨𝒃𝒐𝒖𝒕\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "/𝒓𝒆𝒃𝒐𝒐𝒕\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝑹𝒖𝒏𝒕𝒊𝒎𝒆\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝑪𝒓𝒆𝒂𝒕𝒐𝒓\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝑺𝒑\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + ".𝑺𝒑\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝐖𝐨𝐲\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝒎𝒂𝒔𝒖𝒌\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝒑𝒖𝒍𝒂𝒏𝒈\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝒂𝒋𝒔 𝒔𝒕𝒂𝒚\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝒂𝒋𝒔 𝒋𝒐𝒊𝒏\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝒂𝒋𝒔 𝒃𝒚𝒆\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "/𝐛𝐲𝐞\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝑳𝒆𝒂𝒗𝒆「𝑵𝒂𝒎𝒂𝒈𝒓𝒖𝒑」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝑮𝒊𝒏𝒇𝒐\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝑶𝒖𝒓𝒍\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝒁𝒐𝒖𝒓??\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝑪??𝒓𝒍\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝒁𝒄𝒖????\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝒂𝒍𝒍 𝒈𝒓𝒐𝒖𝒑\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝒁𝒂𝒍𝒍 𝒖𝒓𝒍𝒈𝒓𝒖𝒑\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝒈𝒓𝒖𝒑𝒍𝒊𝒔𝒕\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝒍𝒊𝒔𝒕𝒃𝒐𝒕\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝒊𝒏𝒇𝒐𝒈𝒓𝒖𝒑「𝒂𝒏𝒈𝒌𝒂」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝒊𝒏𝒇𝒐𝒎𝒆𝒎「𝒂𝒏𝒈𝒌𝒂」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝒎𝒚𝒓𝒆𝒄??𝒂𝒕\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝒓𝒆𝒄𝒉𝒂𝒕\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝒍𝒖𝒓𝒌「𝒐𝒏/𝒐𝒇𝒇」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝒍𝒖𝒓𝒌𝒆𝒓𝒔\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝒔𝒊𝒅𝒆𝒓「𝒐𝒏/𝒐𝒇𝒇」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝒎𝒆𝒑𝒊𝒄𝒕\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝒖𝒑𝒑𝒊𝒄𝒕\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝒑𝒊𝒄𝒕𝒈𝒓𝒖𝒑\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝒃𝒄𝒈:「𝑻𝒆𝒙𝒕」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝒔𝒆𝒕𝒌𝒆𝒚「𝑵𝒆𝒘 𝑲𝒆𝒚」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝒎𝒚𝒌𝒆𝒚\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝒓𝒆𝒔𝒆𝒕𝒌𝒆𝒚\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝒊𝒅 𝒍𝒊𝒏𝒆:「𝑰𝒅 𝑳𝒊𝒏𝒆 𝒏𝒚𝒂」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝒔𝒉𝒐𝒍𝒂𝒕:「𝑵𝒂𝒎𝒂 𝑲𝒐𝒕𝒂」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝒄𝒖𝒂𝒄𝒂:「𝑵𝒂𝒎𝒂 𝑲𝒐𝒕𝒂」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝒍𝒐𝒌𝒂𝒔𝒊:「𝑵𝒂𝒎𝒂 𝑲𝒐𝒕𝒂」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝒎𝒖𝒔𝒊𝒄:「𝑱𝒖𝒅𝒖𝒍 𝑳𝒂𝒈𝒖」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝒍𝒊𝒓𝒊𝒌:「𝑱𝒖𝒅𝒖𝒍 𝑳𝒂𝒈𝒖」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝒀𝒕3:「𝑱𝒖𝒅𝒖𝒍 𝑳𝒂𝒈𝒖」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝒀𝒕4:「𝑱𝒖𝒅𝒖𝒍 𝑽𝒊𝒅𝒆𝒐」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝒑𝒓𝒐𝒇𝒊𝒍𝒆𝒊𝒈:「𝑵𝒂𝒎𝒂 𝑰𝑮」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝒄𝒆𝒌𝒅𝒂𝒕𝒆:「𝒕𝒈𝒍-𝒃𝒍𝒏-𝒕𝒉𝒏」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝒎𝒂𝒙:「𝒂𝒏𝒈𝒌𝒂」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝒔𝒑𝒂𝒎𝒕𝒂𝒈「@」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝒔𝒄𝒂𝒍𝒍:「𝒋𝒖𝒎𝒍𝒂𝒉𝒏𝒚𝒂」\n" + \
                  "║┕✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝒔𝒄𝒂𝒍𝒍 \n" + \
                  "╠═══════✤𝐋𝐞𝐚✤═══════╗\n║「✤𝐌𝐄𝐍𝐔 𝐋𝐞𝐚 𝐏𝐑𝐎𝐓𝐄𝐂𝐓𝐈𝐎𝐍✤」\n╚═══════✤𝐋𝐞𝐚✤═══════╝"
    return helpMessage

def helpset():
    key = Leakiller["keyCmd"]
    key = key.title()
    helpMessage1 = "╔═══════✤𝐋𝐞𝐚✤═══════╗\n║「✤𝐌𝐄𝐍𝐔 𝐋𝐞𝐚 𝐊𝐢𝐥𝐥𝐞𝐫✤」\n╠═══════✤𝐋𝐞𝐚✤═══════╝\n" + \
                  "║┍✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝒏𝒐𝒕𝒂𝒈「𝒐𝒏/𝒐𝒇𝒇」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝑷𝒓𝒐𝒕𝒆𝒄𝒕「𝒐𝒏/𝒐𝒇𝒇」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝑷𝒓𝒐𝒒𝒓「𝒐𝒏/𝒐𝒇𝒇」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝑷𝒓𝒐𝒋𝒐𝒊𝒏「𝒐𝒏/𝒐𝒇𝒇」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝑨𝒖𝒕𝒐𝒌𝒊𝒄𝒌「𝒐𝒏/𝒐𝒇𝒇」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝑷𝒓𝒐𝒄𝒂𝒏𝒄𝒆𝒍「𝒐𝒏/𝒐𝒇𝒇」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝑺𝒕𝒊𝒄𝒌𝒆𝒓「𝒐𝒏/𝒐𝒇𝒇」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝑹𝒆𝒔𝒑𝒐𝒏「𝒐𝒏/𝒐𝒇𝒇」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝑪𝒐𝒏𝒕𝒂𝒄𝒕「𝒐𝒏/𝒐𝒇𝒇」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝑨𝒖𝒕𝒐𝒋𝒐𝒊𝒏「𝒐𝒏/𝒐𝒇𝒇」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝑨𝒖𝒕𝒐𝒂𝒅𝒅「𝒐𝒏/𝒐𝒇𝒇」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝑾𝒆𝒍𝒄𝒐𝒎𝒆「𝒐𝒏/𝒐𝒇𝒇」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝑨𝒖𝒕𝒐𝒍𝒆𝒂𝒗𝒆「𝒐𝒏/𝒐𝒇𝒇」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝑱𝒕𝒊𝒄𝒌𝒆𝒕「𝒐𝒏/𝒐𝒇𝒇」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝑰𝒏𝒕𝒂「𝒐𝒏/𝒐𝒇𝒇」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝑩𝒐𝒕:𝒐𝒏\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝑩𝒐𝒕:𝒅𝒆𝒍𝒍\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝑨𝒅𝒅𝒃𝒐𝒕「@」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝑫𝒆𝒍𝒃𝒐𝒕「@」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝑹𝒆𝒇𝒓𝒆𝒔𝒉\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝑴𝒚𝒃𝒐𝒕\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝑨𝒅𝒎𝒊𝒏 𝒍𝒊𝒔𝒕\n" + \
                  "║┕✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝑷𝒓𝒐𝒍𝒊𝒔𝒕\n" + \
                  "╠═══════✤𝐋𝐞𝐚✤═══════╗\n║「✤𝐌𝐄𝐍𝐔 𝐋𝐞𝐚 𝐏𝐑𝐎𝐓𝐄𝐂𝐓𝐈𝐎𝐍✤」\n╚═══════✤𝐋𝐞𝐚✤═══════╝"
    return helpMessage1

def helpbot():
    key = Leakiller["keyCmd"]
    key = key.title()
    helpMessage2 = "═══════✤𝐋𝐞𝐚✤═══════╗\n║「✤𝐌𝐄𝐍𝐔 𝐋𝐞𝐚 𝐊𝐢𝐥𝐥𝐞𝐫✤」\n╠═══════✤𝐋𝐞𝐚✤═══════╝\n" + \
                  "║┍✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝑪𝒃𝒂𝒏\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝑩𝒂𝒏:𝒐𝒏\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝑼𝒏𝒃𝒂𝒏:𝒐𝒏\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝑩𝒂𝒏「@」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝑼𝒏𝒃𝒂𝒏「@」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝑻𝒃𝒂𝒏「@」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝑼𝒕𝒃𝒂𝒏「@」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝑻𝒃𝒂𝒏:𝒐𝒏\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝑼𝒕𝒃𝒂𝒏:𝒐𝒏\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝑩𝒂𝒏𝒍𝒊𝒔𝒕\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝑻𝒃𝒂𝒏𝒍𝒊𝒔𝒕\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝑹𝒆𝒇𝒓𝒆𝒔𝒉\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝑪𝒆𝒌𝒎𝒔𝒈\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝑺𝒊𝒅𝒆𝒓:「𝑻𝒆𝒙𝒕」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝑺𝒑𝒂𝒎:「𝑻𝒆𝒙𝒕」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝑨𝒅𝒅:「𝑻𝒆𝒙𝒕」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝑻𝒂𝒈:「𝑻𝒆𝒙𝒕」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝑾𝒆𝒍𝒄𝒐𝒎𝒆:「𝑻𝒆𝒙𝒕」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝒁𝒏𝒂𝒎𝒆:「𝑵𝒂𝒎𝒂」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝒁1𝒄𝒏:「𝑵𝒂𝒎𝒂」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝒁2𝒄𝒏:「𝑵𝒂𝒎𝒂」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝒁3𝒄𝒏:「𝑵𝒂𝒎𝒂」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝒁4𝒄𝒏:「𝑵𝒂𝒎𝒂」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝒁5𝒄𝒏:「𝑵𝒂𝒎𝒂」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝑲𝒊𝒄𝒌𝒆𝒓𝒄𝒏:「𝑵𝒂𝒎𝒂」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝑲𝒊𝒄𝒌𝒆𝒓𝒑𝒊𝒄𝒕「𝑲 𝒇𝒉𝒐𝒕𝒐」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝒁1𝒑𝒊𝒄𝒕「𝑲𝒊𝒓𝒊𝒎 𝒇𝒉𝒐𝒕𝒐」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝒁2𝒑𝒊𝒄𝒕「𝑲𝒊𝒓𝒊𝒎 𝒇𝒉𝒐𝒕𝒐」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝒁3𝒑𝒊𝒄𝒕「𝑲𝒊𝒓𝒊𝒎 𝒇𝒉𝒐𝒕𝒐」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝒁4𝒑𝒊𝒄𝒕「𝑲𝒊𝒓𝒊𝒎 𝒇𝒉𝒐𝒕𝒐」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝒁5𝒑𝒊𝒄𝒕「𝑲𝒊𝒓𝒊𝒎 𝒇𝒉𝒐𝒕𝒐」\n" + \
                  "║┝✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝑮𝒊𝒇𝒕:「𝑴𝒊𝒅」「𝑱𝒖𝒎𝒍𝒂𝒉」\n" + \
                  "║┕✤𝐋𝐞𝐚✤✍ ⚘ " + key + "𝑺𝒑𝒂𝒎:「𝑴𝒊𝒅」「𝑱𝒖𝒎𝒍𝒂𝒉」\n" + \
                  "╠═══════✤𝐋𝐞𝐚✤═══════╗\n║「✤𝐌𝐄𝐍𝐔 𝐋𝐞𝐚 𝐏𝐑𝐎𝐓𝐄𝐂𝐓𝐈𝐎𝐍✤」\n╚═══════✤𝐋𝐞𝐚✤═══════╝"
    return helpMessage2

def bot(op):
    global time
    global ast
    global groupParam
    try:
        if op.type == 11:
            if op.param2 in wait["blacklist"]:
                if cl.getGroup(op.param1).preventedJoinByTicket == False:
                    if op.param2 not in Lea and op.param2 not in Leakiller["Bots"] and op.param2 not in Leakiller["admin"]:
                        random.choice(Amin).kickoutFromGroup(op.param1,[op.param2])
                        G = cl.getGroup(op.param1)
                        G.preventedJoinByTicket = True
                        cl.updateGroup(G)
                    else:pass
        if op.type == 13:
            if op.param2 in wait["blacklist"]:
                if op.param2 not in Lea and op.param2 not in Leakiller["Bots"] and op.param2 not in Leakiller["admin"]:
                    try:
                        ka.cancelGroupInvitation(op.param1,[op.param3])
                    except:
                        try:
                            kb.cancelGroupInvitation(op.param1,[op.param3])
                        except:
                            try:
                                kc.cancelGroupInvitation(op.param1,[op.param3])
                            except:
                                try:
                                    kd.cancelGroupInvitation(op.param1,[op.param3])
                                except:
                                    try:
                                        ke.cancelGroupInvitation(op.param1,[op.param3])
                                    except:
                                        pass
                else:pass
            if op.param3 in wait["blacklist"]:
                if op.param2 not in Lea and op.param2 not in Leakiller["Bots"] and op.param2 not in Leakiller["admin"]:
                    try:
                        ke.cancelGroupInvitation(op.param1,[op.param3])
                    except:
                        try:
                            kd.cancelGroupInvitation(op.param1,[op.param3])
                        except:
                            try:
                                kc.cancelGroupInvitation(op.param1,[op.param3])
                            except:
                                try:
                                    kb.cancelGroupInvitation(op.param1,[op.param3])
                                except:
                                    try:
                                        ka.cancelGroupInvitation(op.param1,[op.param3])
                                    except:
                                        pass
                else:pass
            if op.param3 in wait["blacklist"]:
                if op.param2 not in Lea and op.param2 not in Leakiller["Bots"] and op.param2 not in Leakiller["admin"]:
                    try:
                        ka.cancelGroupInvitation(op.param1,[op.param3])
                        ka.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            kb.cancelGroupInvitation(op.param1,[op.param3])
                            kb.kickoutFromGroup(op.param1,[op.param2])
                        except:
                            try:
                                kc.cancelGroupInvitation(op.param1,[op.param3])
                                kc.kickoutFromGroup(op.param1,[op.param2])
                            except:
                                try:
                                    kd.cancelGroupInvitation(op.param1,[op.param3])
                                    kd.kickoutFromGroup(op.param1,[op.param2])
                                except:
                                    try:
                                        ke.cancelGroupInvitation(op.param1,[op.param3])
                                        ke.kickoutFromGroup(op.param1,[op.param2])
                                    except:
                                        pass
                else:pass
        if op.type == 15:
            if op.param2 in Bots:
                try:
                    random.choice(Amin).inviteIntoGroup(op.param1,[Smid])
                except:
                    try:
                        cl.inviteIntoGroup(op.param1,[Smid])
                    except:
                        pass
        if op.type == 17:
            if op.param2 in wait["blacklist"]:
                if op.param2 not in Lea and op.param2 not in Leakiller["Bots"] and op.param2 not in Leakiller["admin"]:
                    try:
                        ke.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            kd.kickoutFromGroup(op.param1,[op.param2])
                        except:
                            try:
                                kc.kickoutFromGroup(op.param1,[op.param2])
                            except:
                                try:
                                    kb.kickoutFromGroup(op.param1,[op.param2])
                                except:
                                    try:
                                        ka.kickoutFromGroup(op.param1,[op.param2])
                                    except:
                                        pass
                else:pass
        if op.type == 32:
            if op.param2 in wait["blacklist"]:
                if op.param2 not in Lea and op.param2 not in Leakiller["Bots"] and op.param2 not in Leakiller["admin"]:
                    try:
                        ka.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            kb.kickoutFromGroup(op.param1,[op.param2])
                        except:
                            try:
                                kc.kickoutFromGroup(op.param1,[op.param2])
                            except:
                                try:
                                    kd.kickoutFromGroup(op.param1,[op.param2])
                                except:
                                    try:
                                        ke.kickoutFromGroup(op.param1,[op.param2])
                                    except:
                                        pass
                else:pass
        if op.type == 32:
            if op.param3 in Lea or op.param3 in Leakiller["Bots"] or op.param3 in Leakiller["admin"]:
                if op.param2 not in Lea and op.param2 not in Leakiller["Bots"] and op.param2 not in Leakiller["admin"]:
                    wait["blacklist"][op.param2] = True
                    try:
                        ka.findAndAddContactsByMid(op.param3)
                        ka.kickoutFromGroup(op.param1,[op.param2])
                        ka.inviteIntoGroup(op.param1,[op.param3])
                    except:
                        try:
                            kb.findAndAddContactsByMid(op.param3)
                            kb.kickoutFromGroup(op.param1,[op.param2])
                            kb.inviteIntoGroup(op.param1,[op.param3])
                        except:
                            try:
                                kc.findAndAddContactsByMid(op.param3)
                                kc.kickoutFromGroup(op.param1,[op.param2])
                                kc.inviteIntoGroup(op.param1,[op.param3])
                            except:
                                try:
                                    kd.findAndAddContactsByMid(op.param3)
                                    kd.kickoutFromGroup(op.param1,[op.param2])
                                    kd.inviteIntoGroup(op.param1,[op.param3])
                                except:
                                    try:
                                        ke.findAndAddContactsByMid(op.param3)
                                        ke.kickoutFromGroup(op.param1,[op.param2])
                                        ke.inviteIntoGroup(op.param1,[op.param3])
                                    except:
                                        try:
                                            cl.findAndAddContactsByMid(op.param3)
                                            cl.kickoutFromGroup(op.param1,[op.param2])
                                            cl.inviteIntoGroup(op.param1,[op.param3])
                                        except:
                                            pass
                else:pass
        if op.type == 19:
            if mid in op.param3:
                if op.param2 not in Lea and op.param2 not in Leakiller["Bots"] and op.param2 not in Leakiller["admin"]:
                    wait["blacklist"][op.param2] = True
                    try:
                        ka.kickoutFromGroup(op.param1,[op.param2])
                        ka.inviteIntoGroup(op.param1,[op.param3])
                        cl.acceptGroupInvitation(op.param1)
                    except:
                        try:
                            kb.kickoutFromGroup(op.param1,[op.param2])
                            kb.inviteIntoGroup(op.param1,[op.param3])
                            cl.acceptGroupInvitation(op.param1)
                        except:
                            try:
                                kc.kickoutFromGroup(op.param1,[op.param2])
                                kc.inviteIntoGroup(op.param1,[op.param3])
                                cl.acceptGroupInvitation(op.param1)
                            except:
                                try:
                                    kd.kickoutFromGroup(op.param1,[op.param2])
                                    kd.inviteIntoGroup(op.param1,[op.param3])
                                    cl.acceptGroupInvitation(op.param1)
                                except:
                                    try:
                                        ke.inviteIntoGroup(op.param1,[op.param3])
                                        ke.kickoutFromGroup(op.param1,[op.param2])
                                        cl.acceptGroupInvitation(op.param1)
                                    except:
                                        try:
                                            random.choice(Amin).inviteIntoGroup(op.param1,[op.param3])
                                            random.choice(Amin).kickoutFromGroup(op.param1,[op.param2])
                                            cl.acceptGroupInvitation(op.param1)
                                        except:
                                            pass
                    try:
                        k1.acceptGroupInvitation(op.param1)
                        x = k1.getGroup(op.param1)
                        x.preventedJoinByTicket = False
                        k1.updateGroup(x)
                        Ti = k1.reissueGroupTicket(op.param1)
                        time.sleep(0.001)
                        cl.acceptGroupInvitationByTicket(op.param1,Ti)
                        ka.acceptGroupInvitationByTicket(op.param1,Ti)
                        kb.acceptGroupInvitationByTicket(op.param1,Ti)
                        kc.acceptGroupInvitationByTicket(op.param1,Ti)
                        kd.acceptGroupInvitationByTicket(op.param1,Ti)
                        ke.acceptGroupInvitationByTicket(op.param1,Ti)
                        k1.kickoutFromGroup(op.param1,[op.param2])
                        k1.leaveGroup(op.param1)
                        x = cl.getGroup(op.param1)
                        x.preventedJoinByTicket = True
                        cl.updateGroup(x)
                    except:
                        try:
                            ke.kickoutFromGroup(op.param1,[op.param2])
                            ke.inviteIntoGroup(op.param1,[op.param3])
                            cl.acceptGroupInvitation(op.param1)
                        except:
                            try:
                                kd.kickoutFromGroup(op.param1,[op.param2])
                                kd.inviteIntoGroup(op.param1,[op.param3])
                                cl.acceptGroupInvitation(op.param1)
                            except:
                                try:
                                    kc.kickoutFromGroup(op.param1,[op.param2])
                                    kc.inviteIntoGroup(op.param1,[op.param3])
                                    cl.acceptGroupInvitation(op.param1)
                                except:
                                    try:
                                        kb.inviteIntoGroup(op.param1,[op.param3])
                                        kb.kickoutFromGroup(op.param1,[op.param2])
                                        cl.acceptGroupInvitation(op.param1)
                                    except:
                                        try:
                                            ka.inviteIntoGroup(op.param1,[op.param3])
                                            ka.kickoutFromGroup(op.param1,[op.param2])
                                            cl.acceptGroupInvitation(op.param1)
                                        except:
                                            try:
                                                random.choice(Amin).inviteIntoGroup(op.param1,[op.param3])
                                                random.choice(Amin).kickoutFromGroup(op.param1,[op.param2])
                                                cl.acceptGroupInvitation(op.param1)
                                            except:
                                                   G = ke.getGroup(op.param1)
                                                   G.preventedJoinByTicket = False
                                                   ke.updateGroup(G)
                                                   Ticket = ke.reissueGroupTicket(op.param1)
                                                   ka.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                   kb.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                   kc.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                   kd.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                   cl.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                   random.choice(Amin).kickoutFromGroup(op.param1,[op.param2])
                else:pass
                return
            if Amid in op.param3:
                if op.param2 not in Lea and op.param2 not in Leakiller["Bots"] and op.param2 not in Leakiller["admin"]:
                    wait["blacklist"][op.param2] = True
                    try:
                        kb.inviteIntoGroup(op.param1,[op.param3])
                        kb.kickoutFromGroup(op.param1,[op.param2])
                        ka.acceptGroupInvitation(op.param1)
                    except:
                        try:
                            kc.inviteIntoGroup(op.param1,[op.param3])
                            kc.kickoutFromGroup(op.param1,[op.param2])
                            ka.acceptGroupInvitation(op.param1)
                        except:
                            try:
                                kd.inviteIntoGroup(op.param1,[op.param3])
                                kd.kickoutFromGroup(op.param1,[op.param2])
                                ka.acceptGroupInvitation(op.param1)
                            except:
                                try:
                                    ke.nviteIntoGroup(op.param1,[op.param3])
                                    ke.kickoutFromGroup(op.param1,[op.param2])
                                    ke.acceptGroupInvitation(op.param1)
                                except:
                                    try:
                                        cl.inviteIntoGroup(op.param1,[op.param3])
                                        cl.kickoutFromGroup(op.param1,[op.param2])
                                        ka.acceptGroupInvitation(op.param1)
                                    except:
                                        try:
                                            random.choice(Aakun).kickoutFromGroup(op.param1,[op.param2])
                                            random.choice(Aakun).inviteIntoGroup(op.param1,[op.param3])
                                            ka.acceptGroupInvitation(op.param1)
                                        except:
                                               G = ke.getGroup(op.param1)
                                               G.preventedJoinByTicket = False
                                               ke.updateGroup(G)
                                               Ticket = ke.reissueGroupTicket(op.param1)
                                               ka.acceptGroupInvitationByTicket(op.param1,Ticket)
                                               kb.acceptGroupInvitationByTicket(op.param1,Ticket)
                                               kc.acceptGroupInvitationByTicket(op.param1,Ticket)
                                               kd.acceptGroupInvitationByTicket(op.param1,Ticket)
                                               cl.acceptGroupInvitationByTicket(op.param1,Ticket)
                                               random.choice(Amin).kickoutFromGroup(op.param1,[op.param2])
                else:pass
                return
            if Bmid in op.param3:
                if op.param2 not in Lea and op.param2 not in Leakiller["Bots"] and op.param2 not in Leakiller["admin"]:
                    wait["blacklist"][op.param2] = True
                    try:
                        kc.inviteIntoGroup(op.param1,[op.param3])
                        kc.kickoutFromGroup(op.param1,[op.param2])
                        kb.acceptGroupInvitation(op.param1)
                    except:
                        try:
                            kd.inviteIntoGroup(op.param1,[op.param3])
                            kd.kickoutFromGroup(op.param1,[op.param2])
                            kb.acceptGroupInvitation(op.param1)
                        except:
                            try:
                                ke.inviteIntoGroup(op.param1,[op.param3])
                                ke.kickoutFromGroup(op.param1,[op.param2])
                                kb.acceptGroupInvitation(op.param1)
                            except:
                                try:
                                    ka.inviteIntoGroup(op.param1,[op.param3])
                                    ka.kickoutFromGroup(op.param1,[op.param2])
                                    kb.acceptGroupInvitation(op.param1)
                                except:
                                    try:
                                        cl.kickoutFromGroup(op.param1,[op.param2])
                                        cl.inviteIntoGroup(op.param1,[op.param3])
                                        kb.acceptGroupInvitation(op.param1)
                                    except:
                                        try:
                                            random.choice(Bakun).kickoutFromGroup(op.param1,[op.param2])
                                            random.choice(Bakun).inviteIntoGroup(op.param1,[op.param3])
                                            kb.acceptGroupInvitation(op.param1)
                                        except:
                                               G = kd.getGroup(op.param1)
                                               G.preventedJoinByTicket = False
                                               kd.updateGroup(G)
                                               Ticket = kd.reissueGroupTicket(op.param1)
                                               ka.acceptGroupInvitationByTicket(op.param1,Ticket)
                                               kb.acceptGroupInvitationByTicket(op.param1,Ticket)
                                               kc.acceptGroupInvitationByTicket(op.param1,Ticket)
                                               ke.acceptGroupInvitationByTicket(op.param1,Ticket)
                                               cl.acceptGroupInvitationByTicket(op.param1,Ticket)
                                               random.choice(Amin).kickoutFromGroup(op.param1,[op.param2])
                else:pass
                return
            if Cmid in op.param3:
                if op.param2 not in Lea and op.param2 not in Leakiller["Bots"] and op.param2 not in Leakiller["admin"]:
                    wait["blacklist"][op.param2] = True
                    try:
                        kd.kickoutFromGroup(op.param1,[op.param2])
                        kd.inviteIntoGroup(op.param1,[op.param3])
                        kc.acceptGroupInvitation(op.param1)
                    except:
                        try:
                            ke.kickoutFromGroup(op.param1,[op.param2])
                            ke.inviteIntoGroup(op.param1,[op.param3])
                            kc.acceptGroupInvitation(op.param1)
                        except:
                            try:
                                ka.kickoutFromGroup(op.param1,[op.param2])
                                ka.inviteIntoGroup(op.param1,[op.param3])
                                kc.acceptGroupInvitation(op.param1)
                            except:
                                try:
                                    kb.kickoutFromGroup(op.param1,[op.param2])
                                    kb.inviteIntoGroup(op.param1,[op.param3])
                                    kc.acceptGroupInvitation(op.param1)
                                except:
                                    try:
                                        cl.kickoutFromGroup(op.param1,[op.param2])
                                        cl.inviteIntoGroup(op.param1,[op.param3])
                                        kc.acceptGroupInvitation(op.param1)
                                    except:
                                        try:
                                            random.choice(Cakun).kickoutFromGroup(op.param1,[op.param2])
                                            random.choice(Cakun).inviteIntoGroup(op.param1,[op.param3])
                                            kc.acceptGroupInvitation(op.param1)
                                        except:
                                               G = ka.getGroup(op.param1)
                                               G.preventedJoinByTicket = False
                                               ka.updateGroup(G)
                                               Ticket = ka.reissueGroupTicket(op.param1)
                                               ke.acceptGroupInvitationByTicket(op.param1,Ticket)
                                               kb.acceptGroupInvitationByTicket(op.param1,Ticket)
                                               kc.acceptGroupInvitationByTicket(op.param1,Ticket)
                                               kd.acceptGroupInvitationByTicket(op.param1,Ticket)
                                               cl.acceptGroupInvitationByTicket(op.param1,Ticket)
                                               random.choice(Amin).kickoutFromGroup(op.param1,[op.param2])
                else:pass
                return
            if Dmid in op.param3:
                if op.param2 not in Lea and op.param2 not in Leakiller["Bots"] and op.param2 not in Leakiller["admin"]:
                    wait["blacklist"][op.param2] = True
                    try:
                        ke.kickoutFromGroup(op.param1,[op.param2])
                        ke.inviteIntoGroup(op.param1,[op.param3])
                        kd.acceptGroupInvitation(op.param1)
                    except:
                        try:
                            ka.kickoutFromGroup(op.param1,[op.param2])
                            ka.inviteIntoGroup(op.param1,[op.param3])
                            kd.acceptGroupInvitation(op.param1)
                        except:
                            try:
                                kb.kickoutFromGroup(op.param1,[op.param2])
                                kb.inviteIntoGroup(op.param1,[op.param3])
                                kd.acceptGroupInvitation(op.param1)
                            except:
                                try:
                                    kc.kickoutFromGroup(op.param1,[op.param2])
                                    kc.inviteIntoGroup(op.param1,[op.param3])
                                    kd.acceptGroupInvitation(op.param1)
                                except:
                                    try:
                                        cl.kickoutFromGroup(op.param1,[op.param2])
                                        cl.inviteIntoGroup(op.param1,[op.param3])
                                        kd.acceptGroupInvitation(op.param1)
                                    except:
                                        try:
                                            random.choice(Dakun).kickoutFromGroup(op.param1,[op.param2])
                                            random.choice(Dakun).inviteIntoGroup(op.param1,[op.param3])
                                            kd.acceptGroupInvitation(op.param1)
                                        except:
                                               G = kb.getGroup(op.param1)
                                               G.preventedJoinByTicket = False
                                               kb.updateGroup(G)
                                               Ticket = kb.reissueGroupTicket(op.param1)
                                               ka.acceptGroupInvitationByTicket(op.param1,Ticket)
                                               ke.acceptGroupInvitationByTicket(op.param1,Ticket)
                                               kc.acceptGroupInvitationByTicket(op.param1,Ticket)
                                               kd.acceptGroupInvitationByTicket(op.param1,Ticket)
                                               cl.acceptGroupInvitationByTicket(op.param1,Ticket)
                                               random.choice(Amin).kickoutFromGroup(op.param1,[op.param2])
                else:pass
                return
            if Emid in op.param3:
                if op.param2 not in Lea and op.param2 not in Leakiller["Bots"] and op.param2 not in Leakiller["admin"]:
                    wait["blacklist"][op.param2] = True
                    try:
                        ka.kickoutFromGroup(op.param1,[op.param2])
                        ka.inviteIntoGroup(op.param1,[op.param3])
                        ke.acceptGroupInvitation(op.param1)
                    except:
                        try:
                            kb.kickoutFromGroup(op.param1,[op.param2])
                            kb.inviteIntoGroup(op.param1,[op.param3])
                            ke.acceptGroupInvitation(op.param1)
                        except:
                            try:
                                kc.kickoutFromGroup(op.param1,[op.param2])
                                kc.inviteIntoGroup(op.param1,[op.param3])
                                ke.acceptGroupInvitation(op.param1)
                            except:
                                try:
                                    kd.kickoutFromGroup(op.param1,[op.param2])
                                    kd.inviteIntoGroup(op.param1,[op.param3])
                                    ke.acceptGroupInvitation(op.param1)
                                except:
                                    try:
                                        cl.kickoutFromGroup(op.param1,[op.param2])
                                        cl.inviteIntoGroup(op.param1,[op.param3])
                                        ke.acceptGroupInvitation(op.param1)
                                    except:
                                        try:
                                            random.choice(Eakun).kickoutFromGroup(op.param1,[op.param2])
                                            random.choice(Eakun).inviteIntoGroup(op.param1,[op.param3])
                                            ke.acceptGroupInvitation(op.param1)
                                        except:
                                               G = kc.getGroup(op.param1)
                                               G.preventedJoinByTicket = False
                                               kc.updateGroup(G)
                                               Ticket = kc.reissueGroupTicket(op.param1)
                                               ke.acceptGroupInvitationByTicket(op.param1,Ticket)
                                               kb.acceptGroupInvitationByTicket(op.param1,Ticket)
                                               kc.acceptGroupInvitationByTicket(op.param1,Ticket)
                                               kd.acceptGroupInvitationByTicket(op.param1,Ticket)
                                               cl.acceptGroupInvitationByTicket(op.param1,Ticket)
                                               random.choice(Amin).kickoutFromGroup(op.param1,[op.param2])
                else:pass
                return
            if Smid in op.param3:
                if op.param2 not in Lea and op.param2 not in Leakiller["Bots"] and op.param2 not in Leakiller["admin"]:
                    wait["blacklist"][op.param2] = True
                    try:
                        ke.kickoutFromGroup(op.param1,[op.param2])
                        ke.inviteIntoGroup(op.param1,[op.param3])
                    except:
                        try:
                            ka.kickoutFromGroup(op.param1,[op.param2])
                            ka.inviteIntoGroup(op.param1,[op.param3])
                        except:
                            try:
                                kb.kickoutFromGroup(op.param1,[op.param2])
                                kb.inviteIntoGroup(op.param1,[op.param3])
                            except:
                                try:
                                    kc.kickoutFromGroup(op.param1,[op.param2])
                                    kc.inviteIntoGroup(op.param1,[op.param3])
                                except:
                                    try:
                                        kd.kickoutFromGroup(op.param1,[op.param2])
                                        kd.inviteIntoGroup(op.param1,[op.param3])
                                    except:
                                        try:
                                            random.choice(Amin).kickoutFromGroup(op.param1,[op.param2])
                                            random.choice(Amin).inviteIntoGroup(op.param1,[op.param3])
                                        except:
                                            pass
                else:pass
                return
            if op.param3 in Zie:
                if op.param2 not in Lea:
                    wait["blacklist"][op.param2] = True
                    try:
                        k1.acceptGroupInvitation(op.param1)
                        k1.inviteIntoGroup(op.param1,[op.param3])
                        k1.kickoutFromGroup(op.param1,[op.param2])
                        x = cl.getGroup(op.param1)
                        x.preventedJoinByTicket = False
                        cl.updateGroup(x)
                        Ti = cl.reissueGroupTicket(op.param1)
                        time.sleep(0.001)
                        ka.acceptGroupInvitationByTicket(op.param1,Ti)
                        kb.acceptGroupInvitationByTicket(op.param1,Ti)
                        kc.acceptGroupInvitationByTicket(op.param1,Ti)
                        kd.acceptGroupInvitationByTicket(op.param1,Ti)
                        ke.acceptGroupInvitationByTicket(op.param1,Ti)
                        k1.leaveGroup(op.param1)
                        x = cl.getGroup(op.param1)
                        x.preventedJoinByTicket = True
                        cl.updateGroup(x)
                    except:
                        pass
            if op.type == 19:
                if op.param3 in Lea:
                    if op.param2 not in Lea:
                        wait["blacklist"][op.param2] = True
                        try:
                            cl.findAndAddContactsByMid(op.param3)
                            cl.inviteIntoGroup(op.param1,[op.param3])
                            cl.kickoutFromGroup(op.param1,[op.param2])
                            x = cl.getGroup(op.param1)
                            x.preventedJoinByTicket = False
                            cl.updateGroup(x)
                            Ti = cl.reissueGroupTicket(op.param1)
                            time.sleep(0.001)
                            ka.acceptGroupInvitationByTicket(op.param1,Ti)
                            kb.acceptGroupInvitationByTicket(op.param1,Ti)
                            kc.acceptGroupInvitationByTicket(op.param1,Ti)
                            kd.acceptGroupInvitationByTicket(op.param1,Ti)
                            ke.acceptGroupInvitationByTicket(op.param1,Ti)
                            k1.leaveGroup(op.param1)
                            x = cl.getGroup(op.param1)
                            x.preventedJoinByTicket = True
                            cl.updateGroup(x)
                        except:
                            try:
                                kb.findAndAddContactsByMid(op.param3)
                                kb.kickoutFromGroup(op.param1,[op.param2])
                                kb.inviteIntoGroup(op.param1,[op.param3])
                            except:
                                try:
                                    kc.findAndAddContactsByMid(op.param3)
                                    kc.kickoutFromGroup(op.param1,[op.param2])
                                    kc.inviteIntoGroup(op.param1,[op.param3])
                                except:
                                    try:
                                        kd.findAndAddContactsByMid(op.param3)
                                        kd.kickoutFromGroup(op.param1,[op.param2])
                                        kd.inviteIntoGroup(op.param1,[op.param3])
                                    except:
                                        try:
                                            ke.findAndAddContactsByMid(op.param3)
                                            ke.kickoutFromGroup(op.param1,[op.param2])
                                            ke.inviteIntoGroup(op.param1,[op.param3])
                                        except:
                                            try:
                                                ka.findAndAddContactsByMid(op.param3)
                                                ka.kickoutFromGroup(op.param1,[op.param2])
                                                ka.inviteIntoGroup(op.param1,[op.param3])
                                            except:
                                                try:
                                                    cl.findAndAddContactsByMid(op.param3)
                                                    cl.kickoutFromGroup(op.param1,[op.param2])
                                                    cl.inviteIntoGroup(op.param1,[op.param3])
                                                except:
                                                    try:
                                                        k1.findAndAddContactsByMid(op.param3)
                                                        k1.kickoutFromGroup(op.param1,[op.param2])
                                                        k1.inviteIntoGroup(op.param1,[op.param3])
                                                    except:
                                                        try:
                                                           random.choice(Amin).findAndAddContactsByMid(op.param3)
                                                           random.choice(Amin).kickoutFromGroup(op.param1,[op.param2])
                                                           random.choice(Amin).inviteIntoGroup(op.param1,[op.param3])
                                                        except:
                                                            pass
                    else:pass
                    return
                if op.param3 in Leakiller["Bots"]:
                    if op.param2 not in Lea or op.param2 not in Leakiller["Bots"] or op.param2 not in Leakiller["admin"]:
                        wait["blacklist"][op.param2] = True
                        try:
                            ka.findAndAddContactsByMid(op.param3)
                            ka.kickoutFromGroup(op.param1,[op.param2])
                            ka.inviteIntoGroup(op.param1,[op.param3])
                        except:
                            try:
                                kb.findAndAddContactsByMid(op.param3)
                                kb.kickoutFromGroup(op.param1,[op.param2])
                                kb.inviteIntoGroup(op.param1,[op.param3])
                            except:
                                try:
                                    kc.findAndAddContactsByMid(op.param3)
                                    kc.kickoutFromGroup(op.param1,[op.param2])
                                    kc.inviteIntoGroup(op.param1,[op.param3])
                                except:
                                    try:
                                        kd.findAndAddContactsByMid(op.param3)
                                        kd.kickoutFromGroup(op.param1,[op.param2])
                                        kd.inviteIntoGroup(op.param1,[op.param3])
                                    except:
                                        try:
                                            ke.findAndAddContactsByMid(op.param3)
                                            ke.kickoutFromGroup(op.param1,[op.param2])
                                            ke.inviteIntoGroup(op.param1,[op.param3])
                                        except:
                                            try:
                                                random.choice(Bismillah).findAndAddContactsByMid(op.param3)
                                                random.choice(Bismillah).kickoutFromGroup(op.param1,[op.param2])
                                                random.choice(Bismillah).inviteIntoGroup(op.param1,[op.param3])
                                            except:
                                                pass
                    else:pass
                    return
                if op.param3 in Leakiller["admin"]:
                    if op.param2 not in Lea or op.param2 not in Leakiller["Bots"] or op.param2 not in Leakiller["admin"]:
                        wait["blacklist"][op.param2] = True
                        try:
                            ka.findAndAddContactsByMid(op.param3)
                            ka.kickoutFromGroup(op.param1,[op.param2])
                            ka.inviteIntoGroup(op.param1,[op.param3])
                        except:
                            try:
                                kb.findAndAddContactsByMid(op.param3)
                                kb.kickoutFromGroup(op.param1,[op.param2])
                                kb.inviteIntoGroup(op.param1,[op.param3])
                            except:
                                try:
                                    kc.findAndAddContactsByMid(op.param3)
                                    kc.kickoutFromGroup(op.param1,[op.param2])
                                    kc.inviteIntoGroup(op.param1,[op.param3])
                                except:
                                    try:
                                        kd.findAndAddContactsByMid(op.param3)
                                        kd.kickoutFromGroup(op.param1,[op.param2])
                                        kd.inviteIntoGroup(op.param1,[op.param3])
                                    except:
                                        try:
                                            ke.findAndAddContactsByMid(op.param3)
                                            ke.kickoutFromGroup(op.param1,[op.param2])
                                            ke.inviteIntoGroup(op.param1,[op.param3])
                                        except:
                                            try:
                                                random.choice(Bismillah).findAndAddContactsByMid(op.param3)
                                                random.choice(Bismillah).kickoutFromGroup(op.param1,[op.param2])
                                                random.choice(Bismillah).inviteIntoGroup(op.param1,[op.param3])
                                            except:
                                                pass
                    else:pass
                    return
        if op.type == 0:
            return
        if op.type == 5:
            if Leakiller["autoAdd"] == True:
                if op.param2 not in Lea:
                    cl.findAndAddContactsByMid(op.param1)
                    if (Leakiller["message"] in [" "," ","\n",None]):
                        pass
                    else:
                        cl.sendMessage(op.param1, Leakiller["message"])
        if op.type == 11:
            if op.param1 in Leakiller["proqr"]:
                if op.param2 not in Lea and op.param2 not in Leakiller["Bots"] and op.param2 not in Leakiller["admin"]:
                    if cl.getGroup(op.param1).preventedJoinByTicket == False:
                        wait["blacklist"][op.param2] = True
                        random.choice(Amin).kickoutFromGroup(op.param1,[op.param2])
                        Z = random.choice(Bismillah).getGroup(op.param1)
                        Z.preventedJoinByTicket = True
                        random.choice(Bismillah).updateGroup(Z)
                else:
                    pass
        if op.type == 11:
            if op.param1 in Leakiller["intaPoint"]:
                if op.param2 in Lea and op.param2 in Leakiller["Bots"] and op.param2 not in Leakiller["admin"]:
                    pass
                else:
                    X = cl.getGroup(op.param1)
                    if X.preventedJoinByTicket == True:
                        pass
                    else:
                        cl.updateGroup(X)
                        invsend = 0
                        Ti = cl.reissueGroupTicket(op.param1)
                        ka.acceptGroupInvitationByTicket(op.param1,Ti)
                        kb.acceptGroupInvitationByTicket(op.param1,Ti)
                        kc.acceptGroupInvitationByTicket(op.param1,Ti)
                        kd.acceptGroupInvitationByTicket(op.param1,Ti)
                        ke.acceptGroupInvitationByTicket(op.param1,Ti)
        if op.type == 13:
            if mid in op.param3:
                if Leakiller["autoJoin"] == True:
                    if op.param2 not in Lea and op.param2 not in Leakiller["Bots"] and op.param2 not in Leakiller["admin"]:
                        cl.acceptGroupInvitation(op.param1)
                        cl.leaveGroup(op.param1)
                    else:
                        cl.acceptGroupInvitation(op.param1)
            if Amid in op.param3:
                if Leakiller["autoJoin"] == True:
                    if op.param2 not in Lea and op.param2 not in Leakiller["Bots"] and op.param2 not in Leakiller["admin"]:
                        ka.acceptGroupInvitation(op.param1)
                        ka.leaveGroup(op.param1)
                    else:
                        ka.acceptGroupInvitation(op.param1)
            if Bmid in op.param3:
                if Leakiller["autoJoin"] == True:
                    if op.param2 not in Lea and op.param2 not in Leakiller["Bots"] and op.param2 not in Leakiller["admin"]:
                        kb.acceptGroupInvitation(op.param1)
                        kb.leaveGroup(op.param1)
                    else:
                        kb.acceptGroupInvitation(op.param1)
            if Cmid in op.param3:
                if Leakiller["autoJoin"] == True:
                    if op.param2 not in Lea and op.param2 not in Leakiller["Bots"] and op.param2 not in Leakiller["admin"]:
                        kc.acceptGroupInvitation(op.param1)
                        kc.leaveGroup(op.param1)
                    else:
                        kc.acceptGroupInvitation(op.param1)
            if Dmid in op.param3:
                if Leakiller["autoJoin"] == True:
                    if op.param2 not in Lea and op.param2 not in Leakiller["Bots"] and op.param2 not in Leakiller["admin"]:
                        kd.acceptGroupInvitation(op.param1)
                        kd.leaveGroup(op.param1)
                    else:
                        kd.acceptGroupInvitation(op.param1)
            if Emid in op.param3:
                if Leakiller["autoJoin"] == True:
                    if op.param2 not in Lea and op.param2 not in Leakiller["Bots"] and op.param2 not in Leakiller["admin"]:
                        ke.acceptGroupInvitation(op.param1)
                        ke.leaveGroup(op.param1)
                    else:
                        ke.acceptGroupInvitation(op.param1)
        if op.type == 13:
            if op.param1 in Leakiller["proInvite"]:
                if op.param2 in Lea or op.param2 in Leakiller["Bots"] or op.param2 in Leakiller["admin"]:
                    pass
                else:
                    try:
                        if op.param3 in Lea or op.param3 in Leakiller["Bots"] or op.param3 in Leakiller["admin"]:
                            pass
                        else:
                           if op.param2 not in Lea or op.param2 not in Leakiller["Bots"] or op.param2 not in Leakiller["admin"]:
                                wait["blacklist"][op.param2] = True
                                random.choice(Amin).kickoutFromGroup(op.param1,[op.param2])
                                anu = cl.getCompactGroup(op.param1)
                                if anu.invitee is not None:
                                    pipo = [a.mid for a in anu.invitee]
                                    for target in pipo:
                                        if target in op.param3 and target not in Lea and target not in Leakiller["Bots"] and target not in Leakiller["admin"]:
                                            wait["blacklist"][target] = True
                                            random.choice(Bismillah).cancelGroupInvitation(op.param1,[target])
                           else:pass
                    except:
                        pass
        if op.type == 15:
            if op.param1 in Leakiller["leaveMsg"]:
                if op.param2 not in Lea and op.param2 not in Leakiller["admin"] and op.param2 not in Leakiller["Bots"]:
                    return
                else:
                    cl.sendMessage(op.param1, Leakiller["leftmsg"])
        if op.type == 17:
            if op.param1 in Leakiller["welcome"]:
                if op.param2 in Lea or op.param2 in Leakiller["Bots"] or op.param2 in Leakiller["admin"]:
                    pass
                ginfo = cl.getGroup(op.param1)
                contact = cl.getContact(op.param2).picturePath
                image = 'http://dl.profile.line.naver.jp'+contact
                welcomeMembers(op.param1, [op.param2])
                cl.sendImageWithURL(op.param1, image)
        if op.type == 19:
            if op.param1 in Leakiller["proKick"]:
                if op.param2 in Lea or op.param2 in Leakiller["Bots"] or op.param2 in Leakiller["admin"]:
                    pass
                else:
                    try:
                        if op.param2 not in Lea and op.param2 not in Leakiller["Bots"] and op.param2 not in Leakiller["admin"]:
                            wait["blacklist"][op.param2] = True
                            if op.param3 not in wait["blacklist"]:
                                try:
                                    ka.findAndAddContactsByMid(op.param3)
                                    ka.kickoutFromGroup(op.param1,[op.param2])
                                    ka.inviteIntoGroup(op.param1,[op.param3])
                                except:
                                    try:
                                        kb.findAndAddContactsByMid(op.param3)
                                        kb.kickoutFromGroup(op.param1,[op.param2])
                                        kb.inviteIntoGroup(op.param1,[op.param3])
                                    except:
                                        try:
                                            kc.findAndAddContactsByMid(op.param3)
                                            kc.kickoutFromGroup(op.param1,[op.param2])
                                            kc.inviteIntoGroup(op.param1,[op.param3])
                                        except:
                                            try:
                                                kd.findAndAddContactsByMid(op.param3)
                                                kd.kickoutFromGroup(op.param1,[op.param2])
                                                kd.inviteIntoGroup(op.param1,[op.param3])
                                            except:
                                                try:
                                                    ke.findAndAddContactsByMid(op.param3)
                                                    ke.kickoutFromGroup(op.param1,[op.param2])
                                                    ke.inviteIntoGroup(op.param1,[op.param3])
                                                except:
                                                    pass
                            else:pass
                        else:pass
                    except:
                        pass
        if op.type == 32:
            if op.param1 in Leakiller["proCancel"]:
                if op.param2 in Lea or op.param2 in Leakiller["Bots"] or op.param2 in Leakiller["admin"]:
                    pass
                else:
                    try:
                        if op.param2 not in Lea and op.param2 not in Leakiller["Bots"] and op.param2 not in Leakiller["admin"]:
                            wait["blacklist"][op.param2] = True
                            if op.param3 not in wait["blacklist"]:
                                try:
                                    ka.findAndAddContactsByMid(op.param3)
                                    ka.kickoutFromGroup(op.param1,[op.param2])
                                    ka.inviteIntoGroup(op.param1,[op.param3])
                                except:
                                    try:
                                        kb.findAndAddContactsByMid(op.param3)
                                        kb.kickoutFromGroup(op.param1,[op.param2])
                                        kb.inviteIntoGroup(op.param1,[op.param3])
                                    except:
                                        try:
                                            kc.findAndAddContactsByMid(op.param3)
                                            kc.kickoutFromGroup(op.param1,[op.param2])
                                            kc.inviteIntoGroup(op.param1,[op.param3])
                                        except:
                                            try:
                                                kd.findAndAddContactsByMid(op.param3)
                                                kd.kickoutFromGroup(op.param1,[op.param2])
                                                kd.inviteIntoGroup(op.param1,[op.param3])
                                            except:
                                                try:
                                                    ke.findAndAddContactsByMid(op.param3)
                                                    ke.kickoutFromGroup(op.param1,[op.param2])
                                                    ke.inviteIntoGroup(op.param1,[op.param3])
                                                except:
                                                    pass
                            else:pass
                        else:pass
                    except:
                        pass
        if op.type == 55:
            try:
                if op.param1 in Leakiller["readPoint"]:
                   if op.param2 in Leakiller["readMember"][op.param1]:
                       pass
                   else:
                       Leakiller["readMember"][op.param1][op.param2] = True
                else:
                   pass
            except:
                pass
        if op.type == 55:
            if cctv['cyduk'][op.param1]==True:
                if op.param1 in cctv['point']:
                    Name = cl.getContact(op.param2).displayName
                    if Name in cctv['sidermem'][op.param1]:
                        pass
                    else:
                        cctv['sidermem'][op.param1] += "\n~ " + Name
                        siderMembers(op.param1, [op.param2])
        if op.type == 65:
            if Leakiller["Unsend"] == True:
                try:
                    at = op.param1
                    msg_id = op.param2
                    if msg_id in msg_dict:
                        if msg_dict[msg_id]["from"]:
                           if msg_dict[msg_id]["text"] == 'Gambarnya dibawah':
                                ginfo = cl.getGroup(at)
                                ryan = cl.getContact(msg_dict[msg_id]["from"])
                                zx = ""
                                zxc = ""
                                zx2 = []
                                xpesan =  "「 Gambar Dihapus 」\n• Pengirim : "
                                ret_ = "• Nama Grup : {}".format(str(ginfo.name))
                                ret_ += "\n• Waktu Ngirim : {}".format(dt_to_str(cTime_to_datetime(msg_dict[msg_id]["createdTime"])))
                                ry = str(ryan.displayName)
                                pesan = ''
                                pesan2 = pesan+"@x \n"
                                xlen = str(len(zxc)+len(xpesan))
                                xlen2 = str(len(zxc)+len(pesan2)+len(xpesan)-1)
                                zx = {'S':xlen, 'E':xlen2, 'M':ryan.mid}
                                zx2.append(zx)
                                zxc += pesan2
                                text = xpesan + zxc + ret_ + ""
                                cl.sendMessage(at, text, contentMetadata={'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}, contentType=0)
                                cl.sendImage(at, msg_dict[msg_id]["data"])
                           else:
                                ginfo = cl.getGroup(at)
                                ryan = cl.getContact(msg_dict[msg_id]["from"])
                                ret_ =  "「 Pesan Dihapus 」\n"
                                ret_ += "• Pengirim : {}".format(str(ryan.displayName))
                                ret_ += "\n• Nama Grup : {}".format(str(ginfo.name))
                                ret_ += "\n• Waktu Ngirim : {}".format(dt_to_str(cTime_to_datetime(msg_dict[msg_id]["createdTime"])))
                                ret_ += "\n• Pesannya : {}".format(str(msg_dict[msg_id]["text"]))
                                cl.sendMessage(at, str(ret_))
                        del msg_dict[msg_id]
                except Exception as e:
                    print(e)
        if op.type == 65:
            if Leakiller["Unsend"] == True:
                try:
                    at = op.param1
                    msg_id = op.param2
                    if msg_id in msg_dict1:
                        if msg_dict1[msg_id]["from"]:
                                ginfo = cl.getGroup(at)
                                ryan = cl.getContact(msg_dict1[msg_id]["from"])
                                ret_ =  "「 Sticker Dihapus 」\n"
                                ret_ += "• Pengirim : {}".format(str(ryan.displayName))
                                ret_ += "\n• Nama Grup : {}".format(str(ginfo.name))
                                ret_ += "\n• Waktu Ngirim : {}".format(dt_to_str(cTime_to_datetime(msg_dict1[msg_id]["createdTime"])))
                                ret_ += "{}".format(str(msg_dict1[msg_id]["text"]))
                                cl.sendMessage(at, str(ret_))
                                cl.sendImage(at, msg_dict1[msg_id]["data"])
                        del msg_dict1[msg_id]
                except Exception as e:
                    print(e)
        if op.type == 26:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.toType == 0 or msg.toType == 1 or msg.toType == 2:
                if msg.toType == 0:
                    if sender != cl.profile.mid:
                        to = sender
                    else:
                        to = receiver
                elif msg.toType == 1:
                    to = receiver
                elif msg.toType == 2:
                    to = receiver
                if msg.contentType == 0:
                    msg_dict[msg.id] = {"text": msg.text, "from": msg._from, "createdTime": msg.createdTime, "contentType": msg.contentType, "contentMetadata": msg.contentMetadata}
                if msg.contentType == 1:
                    path = cl.downloadObjectMsg(msg_id)
                    msg_dict[msg.id] = {"text":'Gambarnya dibawah',"data":path,"from":msg._from,"createdTime":msg.createdTime}
                if msg.contentType == 7:
                   stk_id = msg.contentMetadata["STKID"]
                   stk_ver = msg.contentMetadata["STKVER"]
                   pkg_id = msg.contentMetadata["STKPKGID"]
                   ret_ = "\n\n「 Sticker Info 」"
                   ret_ += "\n• Sticker ID : {}".format(stk_id)
                   ret_ += "\n• Sticker Version : {}".format(stk_ver)
                   ret_ += "\n• Sticker Package : {}".format(pkg_id)
                   ret_ += "\n• Sticker Url : line://shop/detail/{}".format(pkg_id)
                   query = int(stk_id)
                   if type(query) == int:
                            data = 'https://stickershop.line-scdn.net/stickershop/v1/sticker/'+str(query)+'/ANDROID/sticker.png'
                            path = cl.downloadFileURL(data)
                            msg_dict1[msg.id] = {"text":str(ret_),"data":path,"from":msg._from,"createdTime":msg.createdTime}
        if op.type == 26:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.toType == 0 and msg.toType == 2:
                if sender != cl.profile.mid:
                    to = sender
                else:
                    to = receiver
            else:
                to = receiver
            if msg.contentType == 0:
                if text is None:
                    return
                if 'MENTION' in msg.contentMetadata.keys()!= None:
                    names = re.findall(r'@(\w+)', text)
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    lists = []
                    for mention in mentionees:
                        if mid in mention['M']:
                            if Leakiller["detectMention"] == True:
                                ca = cl.getContact(sender)
                                cl.sendMessage(to, "halo...☛❲ " + ca.displayName + "❳☚ ")
                                cl.sendMessage(to, Leakiller["msgTag"])
                                cl.sendImageWithURL(to, "http://dl.profile.line-cdn.net/{}" .format(str(ca.pictureStatus)))
                            else:
                                pass
            if msg.contentType == 13:
              if Leakiller["contact"] == True:
                 msg.contentType = 0
                 cl.sendMessage(msg.to,msg.contentMetadata["mid"])
                 if 'displayName' in msg.contentMetadata:
                     contact = cl.getContact(msg.contentMetadata["mid"])
                     path = cl.getContact(msg.contentMetadata["mid"]).picturePath
                     image = 'http://dl.profile.line.naver.jp'+path
                     cl.sendMessage(msg.to,"Nama : " + msg.contentMetadata["displayName"] + "\nMID : " + msg.contentMetadata["mid"] + "\nStatus Msg : " + contact.statusMessage + "\nPicture URL : http://dl.profile.line-cdn.net/" + contact.pictureStatus)
                     cl.sendImageWithURL(msg.to, image)
            if msg.contentType == 16:
                if Leakiller["LikeOn"] == True:
                    url = msg.contentMetadata["postEndUrl"]
                    daftarLike = [1001,1002,1003,1004,1005,1006]
                    likeType = random.choice(daftarLike)
                    cl.likePost(url[25:58], url[66:], likeType)
                    cl.createComment(url[25:58], url[66:], Leakiller["comment"])
            if msg.contentType == 16:
              if Leakiller["checkPost"] == True:
                  try:
                      ret_ = "╔════[ Post Detail ]"
                      if msg.contentMetadata["serviceType"] == "GB":
                          contact = cl.getContact(sender)
                          auth = "\n╠☛ Author : {}".format(str(contact.displayName))
                      else:
                          auth = "\n╠☛ Author : {}".format(str(msg.contentMetadata["serviceName"]))
                      purl = "\n╠☛ Url : {}".format(str(msg.contentMetadata["postEndUrl"]).replace("line://","https://line.me/R/"))
                      ret_ += auth
                      ret_ += purl
                      if "mediaOid" in msg.contentMetadata:
                          object_ = msg.contentMetadata["mediaOid"].replace("svc=myhome|sid=h|","")
                          if msg.contentMetadata["mediaType"] == "V":
                              if msg.contentMetadata["serviceType"] == "GB":
                                  ourl = "\n╠☛ Url Object : https://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&{}".format(str(msg.contentMetadata["mediaOid"]))
                                  murl = "\n╠☛ Url Media : https://obs-us.line-apps.com/myhome/h/download.nhn?{}".format(str(msg.contentMetadata["mediaOid"]))
                              else:
                                  ourl = "\n╠☛ Url Object : https://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&{}".format(str(object_))
                                  murl = "\n╠☛ Url Media : https://obs-us.line-apps.com/myhome/h/download.nhn?{}".format(str(object_))
                              ret_ += murl
                          else:
                              if msg.contentMetadata["serviceType"] == "GB":
                                  ourl = "\n╠☛ Url Object : https://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&{}".format(str(msg.contentMetadata["mediaOid"]))
                              else:
                                  ourl = "\n╠☛ Url Object : https://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&{}".format(str(object_))
                          ret_ += ourl
                      if "stickerId" in msg.contentMetadata:
                          stck = "\n╠☛ Sticker : https://line.me/R/shop/detail/{}".format(str(msg.contentMetadata["packageId"]))
                          ret_ += stck
                      if "text" in msg.contentMetadata:
                          text = "\n╠☛ Note : {}".format(str(msg.contentMetadata["text"]))
                          ret_ += text
                      ret_ += "\n╚══[ ✴ᥣᵋᵅᵝᵒᵗᤰᤈᤌѴᶟᣴᶳᶦᶱᶯᤰᤈᤌ✴ ]"
                      cl.sendMessage(to, str(ret_))
                  except:
                      cl.sendMessage(msg.to,"𝑰𝒏𝒗𝒂𝒍𝒊𝒅 𝑷𝒐𝒔𝒕")
        if op.type == 25 or op.type == 26:
          try:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.toType == 0 or msg.toType == 2:
               if msg.toType == 0:
                    to = receiver
               elif msg.toType == 2:
                    to = receiver
               if msg.contentType == 7:
                 if Leakiller["sticker"] == True:
                    msg.contentType = 0
                    cl.sendMessage(msg.to,"╔══════════════\n╠☛❲𝑪𝒉𝒆𝒄𝒌 𝑺𝒕𝒊𝒄𝒌𝒆𝒓❳\n╠☛ STKID : " + msg.contentMetadata["STKID"] +"\n╠☛ STKPKGID : " + msg.contentMetadata["STKPKGID"] + "\n╠☛ STKVER : " + msg.contentMetadata["STKVER"] + "\n╠☛ " + "line://shop/detail/" + msg.contentMetadata["STKPKGID"] +"\n╚══════════════")
               if msg.contentType == 13:
                 if Leakiller["contact"] == True:
                    msg.contentType = 0
                    cl.sendMessage(msg.to,msg.contentMetadata["mid"])
                    if 'displayName' in msg.contentMetadata:
                        contact = cl.getContact(msg.contentMetadata["mid"])
                        path = cl.getContact(msg.contentMetadata["mid"]).picturePath
                        image = 'http://dl.profile.line.naver.jp'+path
                        cl.sendMessage(msg.to,"╔══════════════\n╠☛ Nama : " + msg.contentMetadata["displayName"] + "\n╠☛ Mid : " + msg.contentMetadata["mid"] + "\n╠☛ Status : " + contact.statusMessage + "\n╠☛ Picture URL : http://dl.profile.line-cdn.net/" + contact.pictureStatus + "\n╚══════════════")
                        cl.sendImageWithURL(msg.to, image)
               if msg.contentType == 13:
                 if msg._from in Zie:
                  if Leakiller["abots"] == True:
                    if msg.contentMetadata["mid"] in Leakiller["Bots"]:
                        cl.sendMessage(msg.to,"𝒘𝒂𝒔 𝒃??𝒕 𝒇𝒓𝒊𝒆𝒏??")
                    else:
                        Leakiller["Bots"][msg.contentMetadata["mid"]] = True
                        cl.sendMessage(msg.to,"𝒔𝒖𝒄𝒄𝒆𝒔 𝒂𝒅?? 𝒃𝒐𝒕𝒔")
                 if Leakiller["dbots"] == True:
                    if msg.contentMetadata["mid"] in Leakiller["Bots"]:
                        del Leakiller["Bots"][msg.contentMetadata["mid"]]
                        cl.sendMessage(msg.to,"𝑺𝒖𝒄𝒄𝒆𝒔 𝒓𝒆𝒎𝒐𝒗𝒆 𝒃𝒐𝒕𝒔")
                    else:
                        cl.sendMessage(msg.to,"𝑪𝒐𝒏𝒕𝒂𝒄𝒕 𝒏𝒐𝒕 𝒊𝒏 𝒍𝒊𝒔𝒕 𝒃𝒐𝒕𝒔")
                 if msg._from in Zie:
                  if Leakiller["addadmin"] == True:
                    if msg.contentMetadata["mid"] in Leakiller["admin"]:
                        cl.sendMessage(msg.to,"𝒘𝒂𝒔 𝒂𝒅𝒎𝒊𝒏")
                    else:
                        Leakiller["admin"][msg.contentMetadata["mid"]] = True
                        cl.sendMessage(msg.to,"succes add admin")
                 if Leakiller["deladmin"] == True:
                    if msg.contentMetadata["mid"] in Leakiller["admin"]:
                        del Leakiller["admin"][msg.contentMetadata["mid"]]
                        cl.sendMessage(msg.to,"𝒔𝒖𝒄𝒄𝒆𝒔 𝒂𝒅𝒅 𝒂𝒅𝒎𝒊𝒏")
                    else:
                        cl.sendMessage(msg.to,"𝑪𝒐𝒏𝒕𝒂𝒄𝒕 𝒏𝒐𝒕 𝒊𝒏 𝒍𝒊𝒔𝒕 𝒂𝒅𝒎𝒊𝒏")
                 if msg._from in Zie:
                  if Leakiller["ablacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["blacklist"]:
                        cl.sendMessage(msg.to,"𝒘𝒂𝒔 𝒃𝒍𝒂𝒄𝒌𝒍𝒊𝒔𝒕")
                    else:
                        wait["blacklist"][msg.contentMetadata["mid"]] = True
                        cl.sendMessage(msg.to,"𝒔𝒖𝒄𝒄𝒆𝒔 𝒂𝒅𝒅 𝒊𝒏 𝒃𝒍𝒂𝒄𝒌𝒍𝒊𝒔𝒕")
                 if Leakiller["dblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["blacklist"]:
                        del wait["blacklist"][msg.contentMetadata["mid"]]
                        cl.sendMessage(msg.to,"𝑺𝒖𝒄𝒄𝒆𝒔 𝒓𝒆𝒎𝒐𝒗𝒆 𝒃𝒍𝒂𝒄𝒌𝒍𝒊𝒔𝒕")
                    else:
                        cl.sendMessage(msg.to,"𝑪𝒐𝒏𝒕𝒂𝒄𝒕 𝒏𝒐𝒕 𝒊𝒏 𝒃𝒍𝒂𝒄𝒌𝒍𝒊𝒔𝒕")
               if msg.toType == 2:
                 if msg._from in Zie:
                   if Leakiller["gPicture"] == True:
                     path = cl.downloadObjectMsg(msg_id)
                     Leakiller["gPicture"] = False
                     cl.updateGroupPicture(msg.to, path)
                     cl.sendMessage(msg.to, "𝑺𝒖𝒄𝒄𝒆𝒔")
               if msg.contentType == 1:
                 if msg._from in Zie:
                   if Leakiller["DPicture"] == True:
                     path1 = ka.downloadObjectMsg(msg_id)
                     path2 = kb.downloadObjectMsg(msg_id)
                     path3 = kc.downloadObjectMsg(msg_id)
                     path4 = kd.downloadObjectMsg(msg_id)
                     path5 = ke.downloadObjectMsg(msg_id)
                     Leakiller["DPicture"] = False
                     ka.updateProfilePicture(path1)
                     ka.sendMessage(msg.to, "𝑺𝒖𝒄𝒄𝒆𝒔 𝒄𝒉𝒂𝒏𝒈𝒆 𝒑𝒊𝒄")
                     kb.updateProfilePicture(path2)
                     kb.sendMessage(msg.to, "𝑺𝒖𝒄𝒄𝒆𝒔 𝒄𝒉𝒂𝒏𝒈𝒆 𝒑𝒊𝒄")
                     kc.updateProfilePicture(path3)
                     kc.sendMessage(msg.to, "𝑺𝒖𝒄𝒄𝒆𝒔 𝒄𝒉𝒂𝒏𝒈𝒆 𝒑𝒊𝒄")
                     kd.updateProfilePicture(path4)
                     kd.sendMessage(msg.to, "𝑺𝒖𝒄𝒄𝒆𝒔 𝒄𝒉𝒂𝒏𝒈𝒆 𝒑𝒊𝒄")
                     ke.updateProfilePicture(path5)
                     ke.sendMessage(msg.to, "𝑺𝒖𝒄𝒄𝒆𝒔 𝒄𝒉𝒂𝒏𝒈𝒆 𝒑𝒊𝒄")
               if msg.contentType == 1:
                 if msg._from in Zie:
                   if mid in Leakiller["cPicture"]:
                     path6 = cl.downloadObjectMsg(msg_id)
                     del Leakiller["cPicture"][mid]
                     cl.updateProfilePicture(path6)
                     cl.sendMessage(msg.to,"𝒔𝒖𝒄𝒄𝒆𝒔 𝒖𝒑𝒅𝒂𝒕𝒆 𝒅𝒊𝒔𝒑𝒍𝒂𝒚 𝒑𝒊𝒄𝒕𝒖𝒓𝒆")
                   if Amid in Leakiller["cPicture"]:
                     path1 = ka.downloadObjectMsg(msg_id)
                     del Leakiller["cPicture"][Amid]
                     ka.updateProfilePicture(path1)
                     ka.sendMessage(msg.to,"𝒔𝒖𝒄𝒄𝒆𝒔 𝒖𝒑𝒅𝒂𝒕𝒆 𝒅𝒊𝒔𝒑𝒍𝒂𝒚 𝒑𝒊𝒄𝒕𝒖𝒓𝒆")
                   if Bmid in Leakiller["cPicture"]:
                     path2 = kb.downloadObjectMsg(msg_id)
                     del Leakiller["cPicture"][Bmid]
                     kb.updateProfilePicture(path2)
                     kb.sendMessage(msg.to,"𝒔𝒖𝒄𝒄𝒆𝒔 𝒖𝒑𝒅𝒂𝒕𝒆 𝒅𝒊𝒔𝒑𝒍𝒂𝒚 𝒑𝒊𝒄𝒕𝒖𝒓𝒆")
                   if Cmid in Leakiller["cPicture"]:
                     path3 = kc.downloadObjectMsg(msg_id)
                     del Leakiller["cPicture"][Cmid]
                     kc.updateProfilePicture(path3)
                     kc.sendMessage(msg.to,"𝒔𝒖𝒄𝒄𝒆𝒔 𝒖𝒑𝒅𝒂𝒕𝒆 𝒅𝒊𝒔𝒑𝒍𝒂𝒚 𝒑𝒊𝒄𝒕𝒖𝒓𝒆")
                   if Dmid in Leakiller["cPicture"]:
                     path4 = kd.downloadObjectMsg(msg_id)
                     del Leakiller["cPicture"][Dmid]
                     kd.updateProfilePicture(path4)
                     kd.sendMessage(msg.to,"𝒔𝒖𝒄𝒄𝒆𝒔 𝒖𝒑𝒅𝒂𝒕𝒆 𝒅𝒊𝒔𝒑𝒍𝒂𝒚 𝒑𝒊𝒄𝒕𝒖𝒓𝒆")
                   if Emid in Leakiller["cPicture"]:
                     path5 = ke.downloadObjectMsg(msg_id)
                     del Leakiller["cPicture"][Emid]
                     ke.updateProfilePicture(path5)
                     ke.sendMessage(msg.to,"𝒔𝒖𝒄𝒄𝒆𝒔 𝒖𝒑𝒅𝒂𝒕𝒆 𝒅𝒊𝒔𝒑𝒍𝒂𝒚 𝒑𝒊𝒄𝒕𝒖𝒓𝒆")
                   if Smid in Leakiller["cPicture"]:
                     path7 = k1.downloadObjectMsg(msg_id)
                     del Leakiller["cPicture"][Smid]
                     k1.updateProfilePicture(path7)
                     k1.sendMessage(msg.to,"𝒔𝒖𝒄𝒄𝒆𝒔 𝒖𝒑𝒅𝒂𝒕𝒆 𝒅𝒊𝒔𝒑𝒍𝒂𝒚 𝒑𝒊𝒄𝒕𝒖𝒓𝒆")
               if msg.contentType == 0:
                    if Leakiller["autoRead"] == True:
                        cl.sendChatChecked(msg.to, msg_id)
                    if text is None:
                        return
                    else:
                        cmd = command(text)
                        if cmd == "menu":
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                               helpMessage = help()
                               cl.sendMessage(to,"╔"+str(helpMessage))

                        if cmd == "menubot":
                            if msg._from in Zie:
                               helpMessage = help()
                               ka.sendMessage(to,"╔"+str(helpMessage))

                        if cmd == "menu1":
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                               helpMessage1 = helpset()
                               cl.sendMessage(to,str(helpMessage1))

                        if cmd == "menubot1":
                            if msg._from in Zie:
                               helpMessage1 = helpset()
                               ka.sendMessage(to,"╔"+str(helpMessage1))

                        if cmd == "on":
                            if msg._from in Zie:
                                Leakiller["selfbot"] = True
                                cl.sendMessage(msg.to, "𝑩𝒐𝒕 𝒕𝒆𝒍𝒂𝒉 𝒅𝒊𝒂𝒌𝒕𝒊𝒇𝒌𝒂𝒏")

                        elif cmd == "off":
                            if msg._from in Zie:
                                Leakiller["selfbot"] = False
                                cl.sendMessage(msg.to, "𝑩𝒐𝒕 𝒕𝒆𝒍𝒂𝒉 𝒅𝒊𝒎𝒂𝒕𝒊𝒌𝒂𝒏")

                        elif cmd == "menu2":
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                               helpMessage2 = helpbot()
                               cl.sendMessage(to,"╔"+str(helpMessage2))

                        elif cmd == "menubot2":
                            if msg._from in Zie:
                               helpMessage2 = helpbot()
                               ka.sendMessage(to,"╔"+str(helpMessage2))

                        elif cmd == "grupset":
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                                md = ""
                                if msg.to in Leakiller["proqr"]: md+="╠☛ 𝑷𝒓𝒐𝒒𝒓 : 📳\n"
                                else: md+="╠☛ 𝑷𝒓𝒐𝒒𝒓 : 📴\n"
                                if msg.to in Leakiller["proKick"]: md+="╠☛ 𝑨𝒖𝒕𝒐 𝒌𝒊𝒄𝒌 : 📳\n"
                                else: md+="╠☛ 𝑨𝒖𝒕𝒐 𝒌𝒊𝒄𝒌 : 📴\n"
                                if msg.to in Leakiller["proCancel"]: md+="╠☛ 𝑷𝒓𝒐𝒄𝒂𝒏𝒄𝒆𝒍 : 📳\n"
                                else: md+="╠☛ 𝑷𝒓𝒐𝒄𝒂𝒏𝒄𝒆𝒍 : 📴\n"
                                if msg.to in Leakiller["proInvite"]: md+="╠☛ 𝑷𝒓𝒐𝒊𝒏𝒗𝒊𝒕𝒆 : 📳\n"
                                else: md+="╠☛ 𝑷𝒓𝒐𝒊𝒏𝒗𝒊𝒕𝒆 : 📴\n"
                                if msg.to in Leakiller["intaPoint"]: md+="╠☛ 𝑰𝒏𝒕𝒂𝒑𝒐𝒊𝒏𝒕 : 📳\n"
                                else: md+="╠☛ 𝑰𝒏𝒕𝒂𝒑𝒐𝒊𝒏𝒕 : 📴\n"
                                if msg.to in Leakiller["welcome"]: md+="╠☛ 𝑾𝒆𝒍𝒄𝒐𝒎𝒆 𝑴𝒔𝒈 : 📳\n"
                                else: md+="╠☛ 𝑾𝒆𝒍𝒄𝒐𝒎𝒆 𝑴𝒔𝒈 : 📴\n"
                                if msg.to in Leakiller["leaveMsg"]: md+="╠☛ 𝑳𝒆𝒂𝒗𝒆 𝑴𝒔𝒈 : 📳\n"
                                else: md+="╠☛ 𝑳𝒆𝒂𝒗𝒆 𝑴𝒔𝒈 : 📴\n"
                                cl.sendMessage(msg.to, "╔══❲ 𝑺𝒆𝒕𝒕 𝑮𝒓𝒐𝒖𝒑 ❳══\n"+ md +"╚══════════════")

                        elif text.lower() == "status":
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                                md = ""
                                if Leakiller["autoJoin"] == True: md+="╠☛ 𝑨𝒖𝒕𝒐 𝒋𝒐𝒊𝒏 : 📳\n"
                                else: md+="╠☛ 𝑨𝒖𝒕𝒐 𝒋𝒐𝒊𝒏 : 📴\n"
                                if Leakiller["sticker"] == True: md+="╠☛ 𝑺𝒕𝒊𝒄𝒌𝒆𝒓 : 📳\n"
                                else: md+="╠☛ 𝑺𝒕𝒊𝒄𝒌𝒆𝒓 📴\n"
                                if Leakiller["contact"] == True: md+="╠☛ 𝑪𝒐𝒏𝒕𝒂𝒄𝒕 : 📳\n"
                                else: md+="╠☛ 𝑪𝒐𝒏𝒕𝒂𝒄𝒕 : 📴 \n"
                                if Leakiller["detectMention"] == True: md+="╠☛ 𝑴𝒆𝒏𝒕𝒊𝒐𝒏 : 📳\n"
                                else: md+="╠☛ 𝑴𝒆𝒏𝒕𝒊𝒐𝒏 : 📴\n"
                                if Leakiller["autoAdd"] == True: md+="╠☛ 𝑴𝒔𝒈 𝑨𝒅𝒅 : 📳\n"
                                else: md+="╠☛ 𝑴𝒔𝒈 𝑨𝒅𝒅 : 📴\n"
                                userid = "https://line.me/ti/p/~" + cl.profile.userid
                                cl.sendMessage(msg.to, "╔══❲ 𝑺𝒕𝒂𝒕𝒖𝒔 𝑮𝒓𝒐𝒖𝒑 ❳══\n"+ md +"╚══════════════")

                        elif text.lower() == "addbot":
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                              gs = [mid,Amid,Bmid,Cmid,Dmid,Emid,Fmid,Smid]
                              targets = []
                              for x in gs:
                                  targets.append(x)
                              for target in targets:
                                  try:
                                      cl.findAndAddContactsByMid(target)
                                      time.sleep(4)
                                      ka.findAndAddContactsByMid(target)
                                      time.sleep(4)
                                      kb.findAndAddContactsByMid(target)
                                      time.sleep(4)
                                      kc.findAndAddContactsByMid(target)
                                      time.sleep(4)
                                      kd.findAndAddContactsByMid(target)
                                      time.sleep(4)
                                      ke.findAndAddContactsByMid(target)
                                      time.sleep(4)
                                      kf.findAndAddContactsByMid(target)
                                      time.sleep(4)                                     
                                      k1.findAndAddContactsByMid(target)
                                      time.sleep(4)  
                                  except:
                                      cl.sendMessage(msg.to,"𝑺𝒖𝒄𝒄𝒆𝒔 𝒂𝒅𝒅 𝒃𝒐𝒕𝒔")
                                      ka.sendMessage(msg.to,"𝑺𝒖𝒄𝒄𝒆𝒔 𝒂𝒅𝒅 𝒃𝒐𝒕𝒔")
                                      kb.sendMessage(msg.to,"𝑺𝒖𝒄𝒄𝒆𝒔 𝒂𝒅𝒅 𝒃𝒐𝒕𝒔")
                                      kc.sendMessage(msg.to,"𝑺𝒖𝒄𝒄𝒆𝒔 𝒂𝒅𝒅 𝒃𝒐𝒕𝒔")
                                      kd.sendMessage(msg.to,"𝑺𝒖𝒄𝒄𝒆𝒔 𝒂𝒅𝒅 𝒃𝒐𝒕𝒔")
                                      ke.sendMessage(msg.to,"𝑺𝒖𝒄𝒄𝒆𝒔 𝒂𝒅𝒅 𝒃𝒐𝒕𝒔")
                                      kf.sendMessage(msg.to,"𝑺𝒖𝒄𝒄𝒆𝒔 𝒂𝒅𝒅 𝒃𝒐𝒕𝒔")
                                      k1.sendMessage(msg.to,"𝑺𝒖𝒄𝒄𝒆𝒔 𝒂𝒅𝒅 𝒃𝒐𝒕𝒔")

                        elif cmd == "me" or text.lower() == 'me':
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                               msg.contentType = 13
                               msg.contentMetadata = {'mid': msg._from}
                               cl.sendMessage(msg.to,"Lea")
                               cl.sendContact(to, mid)

                        elif cmd == "reject":
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                              ginvited = cl.getGroupIdsInvited()
                              if ginvited != [] and ginvited != None:
                                  for gid in ginvited:
                                      cl.rejectGroupInvitation(gid)
                                  cl.sendMessage(to, "𝑩𝒆𝒓𝒉𝒂𝒔𝒊𝒍 𝒕𝒐𝒍𝒂𝒌 𝒔𝒆𝒃𝒂𝒏𝒚𝒂𝒌 {} 𝒖𝒏𝒅𝒂𝒏𝒈𝒂𝒏 𝒈𝒓𝒖𝒑".format(str(len(ginvited))))
                              else:
                                  cl.sendMessage(to, "𝑻𝒊𝒅𝒂𝒌 𝒂𝒅𝒂 𝒖𝒏𝒅𝒂𝒏𝒈𝒂𝒏 𝒚𝒂𝒏𝒈 𝒕𝒆𝒓𝒕𝒖𝒏𝒅𝒂")

                        elif cmd == 'bot:room':
                            a = []
                            b = cl.getGroup(to)
                            lss = cl.refreshContacts()
                            for i in b.members:
                              if i.mid not in mid:
                                 a.append(i.mid)
                                 if i.mid not in lss:
                                    cl.findAndAddContactsByMid(i.mid)
                                 time.sleep(0.4)
                            if a == []:
                               cl.sendMessage(to,"𝒃𝒆𝒍𝒖𝒎 𝒅𝒊𝒕𝒂𝒎𝒃𝒂𝒉𝒌𝒂𝒏")
                            else:cl.sendMessage(to,'𝒕𝒆𝒍𝒂𝒉 𝒅𝒊𝒕𝒂𝒎𝒃𝒂𝒉𝒌𝒂𝒏')

                        elif cmd == 'bot1:room':
                            a = []
                            b = ka.getGroup(to)
                            lss = ka.refreshContacts()
                            for i in b.members:
                              if i.mid not in Amid:
                                 a.append(i.mid)
                                 if i.mid not in lss:
                                    ka.findAndAddContactsByMid(i.mid)
                                 time.sleep(0.4)
                            if a == []:
                               ka.sendMessage(to,"𝒃𝒆𝒍𝒖𝒎 𝒅𝒊𝒕𝒂𝒎𝒃𝒂𝒉𝒌𝒂𝒏")
                            else:ka.sendMessage(to,'𝒕𝒆𝒍𝒂𝒉 𝒅𝒊𝒕𝒂𝒎𝒃𝒂𝒉𝒌𝒂𝒏')

                        elif cmd == 'bot2:room':
                            a = []
                            b = kb.getGroup(to)
                            lss = kb.refreshContacts()
                            for i in b.members:
                              if i.mid not in Bmid:
                                 a.append(i.mid)
                                 if i.mid not in lss:
                                    kb.findAndAddContactsByMid(i.mid)
                                 time.sleep(0.4)
                            if a == []:
                               kb.sendMessage(to,"𝒃𝒆𝒍𝒖𝒎 𝒅𝒊𝒕𝒂𝒎𝒃𝒂𝒉𝒌𝒂𝒏")
                            else:kb.sendMessage(to,'𝒕𝒆𝒍𝒂𝒉 𝒅𝒊𝒕𝒂𝒎𝒃𝒂𝒉𝒌𝒂𝒏')

                        elif cmd == 'bot3:room':
                            a = []
                            b = kc.getGroup(to)
                            lss = kc.refreshContacts()
                            for i in b.members:
                              if i.mid not in Cmid:
                                 a.append(i.mid)
                                 if i.mid not in lss:
                                    kc.findAndAddContactsByMid(i.mid)
                                 time.sleep(0.4)
                            if a == []:
                               kc.sendMessage(to,"𝒃𝒆𝒍𝒖𝒎 𝒅𝒊𝒕𝒂𝒎𝒃𝒂𝒉𝒌𝒂𝒏")
                            else:kc.sendMessage(to,'𝒕𝒆𝒍𝒂𝒉 𝒅𝒊𝒕𝒂𝒎𝒃𝒂𝒉𝒌𝒂𝒏')

                        elif cmd == 'bot4:room':
                            a = []
                            b = kd.getGroup(to)
                            lss = kd.refreshContacts()
                            for i in b.members:
                              if i.mid not in Dmid:
                                 a.append(i.mid)
                                 if i.mid not in lss:
                                    kd.findAndAddContactsByMid(i.mid)
                                 time.sleep(0.4)
                            if a == []:
                               kd.sendMessage(to,"𝒃𝒆𝒍𝒖𝒎 𝒅𝒊𝒕𝒂𝒎𝒃𝒂𝒉𝒌𝒂𝒏")
                            else:kd.sendMessage(to,'𝒕𝒆𝒍𝒂𝒉 𝒅𝒊𝒕𝒂𝒎𝒃𝒂𝒉𝒌𝒂𝒏')

                        elif cmd == 'bot5:room':
                            a = []
                            b = ke.getGroup(to)
                            lss = ke.refreshContacts()
                            for i in b.members:
                              if i.mid not in Emid:
                                 a.append(i.mid)
                                 if i.mid not in lss:
                                    ke.findAndAddContactsByMid(i.mid)
                                 time.sleep(0.4)
                            if a == []:
                               ke.sendMessage(to,"𝒃𝒆𝒍𝒖𝒎 𝒅𝒊𝒕𝒂𝒎𝒃𝒂𝒉𝒌𝒂𝒏")
                            else:ke.sendMessage(to,'𝒕𝒆𝒍𝒂𝒉 𝒅𝒊𝒕𝒂𝒎𝒃𝒂𝒉𝒌𝒂𝒏')

                        elif cmd == 'kicker:room':
                            a = []
                            b = k1.getGroup(to)
                            lss = k1.refreshContacts()
                            for i in b.members:
                              if i.mid not in Smid:
                                 a.append(i.mid)
                                 if i.mid not in lss:
                                    k1.findAndAddContactsByMid(i.mid)
                                 time.sleep(0.4)
                            if a == []:
                               k1.sendMessage(to,"𝒃𝒆𝒍𝒖𝒎 𝒅𝒊𝒕𝒂𝒎𝒃𝒂𝒉𝒌𝒂𝒏")
                            else:k1.sendMessage(to,'??𝒆𝒍𝒂𝒉 𝒅𝒊𝒕𝒂𝒎𝒃𝒂𝒉𝒌𝒂𝒏')

                        elif cmd.startswith("smuleaudio "):
                          if msg._from in Zie:
                            try:
                                sep = msg.text.split(" ")
                                dancoeg = msg.text.replace(sep[0] + " ","")
                                r = requests.get("https://smule.com/FFV_Zie_RockStar?link={}".format(dancoeg))
                                data = r.text
                                data = json.loads(data)
                                cl.sendImageWithURL(to, str(data["result"][0]["thumb"]))
                                cl.sendAudioWithURL(to, str(data["result"][0]["video"]))
                            except:
                                sendMention(to, sender, "「", "」\n𝑾𝒂𝒊𝒕𝒊𝒏𝒈 𝑷𝒓𝒐𝒈𝒓𝒆𝒔 𝑨𝒖𝒅𝒊𝒐 🔊")
                                cl.sendAudioWithURL(to, str(data["result"][0]["video"]))

                        elif cmd.startswith("open "):
                          if msg._from in Ang:
                            separate = text.split(" ")
                            number = text.replace(separate[0] + " ","")
                            groups = cl.getGroupIdsJoined()
                            ret_ = ""
                            try:
                                group = groups[int(number)-1]
                                G = cl.getGroup(group)
                                G.preventedJoinByTicket = False
                                cl.updateGroup(G)
                                try:
                                    gCreator = G.creator.mid
                                    dia = cl.getContact(gCreator)
                                    zx = ""
                                    zxc = ""
                                    zx2 = []
                                    xpesan = '⃣ Sukses Open Qr ⃣\⃣ Creator :  '
                                    diaa = str(dia.displayName)
                                    pesan = ''
                                    pesan2 = pesan+"@a\n"
                                    xlen = str(len(zxc)+len(xpesan))
                                    xlen2 = str(len(zxc)+len(pesan2)+len(xpesan)-1)
                                    zx = {'S':xlen, 'E':xlen2, 'M':dia.mid}
                                    zx2.append(zx)
                                    zxc += pesan2
                                except:
                                    gCreator = "Tidak ditemukan"
                                if G.invitee is None:
                                    gPending = "0"
                                else:
                                    gPending = str(len(G.invitee))
                                if G.preventedJoinByTicket == True:
                                    gQr = "Tertutup"
                                    gTicket = "Tidak ada"
                                else:
                                    gQr = "Terbuka"
                                    gTicket = "https://line.me/R/ti/g/{}".format(str(cl.reissueGroupTicket(G.id)))
                                timeCreated = []
                                timeCreated.append(time.strftime("%d-%m-%Y [ %H:%M:%S ]", time.localtime(int(G.createdTime) / 1000)))
                                ret_ += xpesan+zxc
                                ret_ += "\n⃣ Nama : {}".format(G.name)
                                ret_ += "\n⃣ Group Qr : {}".format(gQr)
                                ret_ += "\n⃣ Pendingan : {}".format(gPending)
                                ret_ += "\n⃣ Group Ticket : {}".format(gTicket)
                                ret_ += ""
                                cl.sendMessage(receiver, ret_, contentMetadata={'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}, contentType=0)
                            except:
                                pass

                        elif ("Gn " in msg.text):
                          if msg._from in Zie:
                              X = cl.getGroup(msg.to)
                              X.name = msg.text.replace("Gn ","")
                              cl.updateGroup(X)

                        elif ("Mid " in msg.text):
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                               if 'MENTION' in msg.contentMetadata.keys()!= None:
                                   names = re.findall(r'@(\w+)', text)
                                   mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                   mentionees = mention['MENTIONEES']
                                   lists = []
                                   for mention in mentionees:
                                       if mention["M"] not in lists:
                                           lists.append(mention["M"])
                                   ret_ = ""
                                   for ls in lists:
                                       ret_ += "{}".format(str(ls))
                                   cl.sendMessage(to, str(ret_),{'AGENT_ICON': 'http://dl.profile.line-cdn.net/'+'M', 'AGENT_NAME': 'Mention', 'AGENT_LINK': 'http://line.me/ti/p/~{}'.format(cl.getProfile().userid), 'AGENT_ICON': "http://dl.profile.line-cdn.net/" + cl.getProfile().picturePath})

                        elif cmd == "mymid":
                               cl.sendMessage(to, "Mid:\n{}".format(sender))

                        elif ("Info " in msg.text):
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                               key = eval(msg.contentMetadata["MENTION"])
                               key1 = key["MENTIONEES"][0]["M"]
                               mi = cl.getContact(key1)
                               cl.sendMessage(msg.to, "☛ Nama : "+str(mi.displayName)+"\n☛ Mid : " +key1+"\n☛ Status Msg"+str(mi.statusMessage))
                               cl.sendMessage(msg.to, None, contentMetadata={'mid': key1}, contentType=13)
                               if "videoProfile='{" in str(cl.getContact(key1)):
                                   cl.sendVideoWithURL(msg.to, 'http://dl.profile.line.naver.jp'+str(mi.picturePath)+'/vp.small')
                               else:
                                   cl.sendImageWithURL(msg.to, 'http://dl.profile.line.naver.jp'+str(mi.picturePath))

                        elif cmd == "mybot":
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                               ka.sendContact(msg.to, Amid)
                               time.sleep(0.15)
                               kb.sendContact(msg.to, Bmid)
                               time.sleep(0.15)
                               kc.sendContact(msg.to, Cmid)
                               time.sleep(0.15)
                               kd.sendContact(msg.to, Dmid)
                               time.sleep(0.15)
                               ke.sendContact(msg.to, Emid)

                        elif cmd == "invitelist" or cmd == "listinvite":
                          if msg._from in Zie:
                            groups = cl.getGroupIdsInvited()
                            ret_ = "====「 𝑰𝒏𝒗𝒊𝒕𝒂𝒕𝒊𝒐𝒏 𝑳𝒊𝒔𝒕 」"
                            no = 1
                            for gid in groups:
                                group = cl.getGroup(gid)
                                ret_ += "\n│•{}. {} | {}".format(str(no), str(group.name), str(len(group.members)))
                                no = (no+1)
                            ret_ += "\n│Total {} Pending".format(str(len(groups)))
                            ret_ += "\n├───「 Usage 」───"
                            ret_ += "\n├Accept 「Nomor」"
                            ret_ += "\n├Reject 「Nomor」"
                            ret_ += "\n====「 𝑳𝒆𝒂 𝑲𝒊𝒍𝒍𝒆𝒓 」"
                            cl.sendMessage(msg.to, str(ret_))

                        elif text.lower() == "myrechat":
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                               try:
                                   cl.removeAllMessages(op.param2)
                               except:
                                   pass

                        elif text.lower() == "rechat":
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                               try:
                                   ka.removeAllMessages(op.param2)
                                   ka.sendMessage(msg.to,"𝑺𝒆𝒎𝒖𝒂 𝒑𝒆𝒔𝒂𝒏 𝒕𝒆𝒍𝒂𝒉 𝒅𝒊𝒉𝒂𝒑𝒖𝒔")
                                   kb.removeAllMessages(op.param2)
                                   kb.sendMessage(msg.to,"𝑺𝒆𝒎𝒖𝒂 𝒑𝒆𝒔𝒂𝒏 𝒕𝒆𝒍𝒂𝒉 𝒅𝒊𝒉𝒂𝒑𝒖𝒔")
                                   kc.removeAllMessages(op.param2)
                                   kc.sendMessage(msg.to,"𝑺𝒆𝒎𝒖𝒂 𝒑𝒆𝒔𝒂𝒏 𝒕𝒆𝒍𝒂𝒉 𝒅𝒊𝒉𝒂𝒑𝒖𝒔")
                                   kd.removeAllMessages(op.param2)
                                   kd.sendMessage(msg.to,"𝑺𝒆𝒎𝒖𝒂 𝒑𝒆𝒔𝒂𝒏 𝒕𝒆𝒍𝒂𝒉 𝒅𝒊𝒉𝒂𝒑𝒖𝒔")
                                   ke.removeAllMessages(op.param2)
                                   ke.sendMessage(msg.to,"𝑺𝒆𝒎𝒖𝒂 𝒑𝒆𝒔𝒂𝒏 𝒕𝒆𝒍𝒂𝒉 𝒅𝒊𝒉𝒂𝒑𝒖𝒔")
                               except:
                                   ka.removeAllMessages(op.param2)
                                   ka.sendMessage(msg.to,"𝑺𝒆𝒎𝒖𝒂 𝒑𝒆𝒔𝒂𝒏 𝒕𝒆𝒍𝒂𝒉 𝒅𝒊𝒉𝒂𝒑𝒖𝒔")
                                   kb.removeAllMessages(op.param2)
                                   kb.sendMessage(msg.to,"𝑺𝒆𝒎𝒖𝒂 𝒑𝒆𝒔𝒂𝒏 𝒕𝒆𝒍𝒂𝒉 𝒅𝒊𝒉𝒂𝒑𝒖𝒔")
                                   kc.removeAllMessages(op.param2)
                                   kc.sendMessage(msg.to,"𝑺𝒆𝒎𝒖𝒂 𝒑𝒆𝒔𝒂𝒏 𝒕𝒆𝒍𝒂𝒉 𝒅𝒊𝒉𝒂𝒑𝒖𝒔")
                                   kd.removeAllMessages(op.param2)
                                   kd.sendMessage(msg.to,"𝑺𝒆𝒎𝒖𝒂 𝒑𝒆𝒔𝒂𝒏 𝒕𝒆𝒍𝒂𝒉 𝒅𝒊𝒉𝒂𝒑𝒖𝒔")
                                   ke.removeAllMessages(op.param2)
                                   ke.sendMessage(msg.to,"𝑺𝒆𝒎𝒖𝒂 𝒑𝒆𝒔𝒂𝒏 𝒕𝒆𝒍𝒂𝒉 𝒅𝒊𝒉𝒂𝒑𝒖𝒔")
                                   k1.removeAllMessages(op.param2)
                                   k1.sendMessage(msg.to,"𝑺𝒆𝒎𝒖𝒂 𝒑𝒆𝒔𝒂𝒏 𝒕𝒆𝒍𝒂𝒉 𝒅𝒊𝒉𝒂𝒑𝒖𝒔")

                        elif cmd.startswith("bcg: "):
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                               sep = text.split(" ")
                               pesan = text.replace(sep[0] + " ","")
                               saya = cl.getGroupIdsJoined()
                               for group in saya:
                                   cl.sendMessage(group,"[ 𝑩𝒓𝒐𝒂𝒅𝒄𝒂𝒔𝒕 ]\n" + str(pesan))

                        elif cmd.startswith("profilesmule: "):
                          if msg._from in Zie:    
                            try:
                                separate = msg.text.split(" ")
                                smule = msg.text.replace(separate[0] + " ","")
                                links = ("https://smule.com/"+smule)
                                ss = ("http://api2.ntcorp.us/screenshot/shot?url={}".format(urllib.parse.quote(links)))
                                cl.sendMessage(msg.to, "Sedang Mencari...")
                                time.sleep(2)
                                cl.sendMessage(msg.to, "𝑰𝑫 𝑺𝒎𝒖𝒍𝒆 : "+smule+"\n𝑳𝒊𝒏𝒌 : "+links)
                                cl.sendImageWithURL(msg.to, ss)
                            except Exception as error:
                                pass

                        elif text.lower() == "mykey":
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                               cl.sendMessage(msg.to, "𝒌𝒆𝒚 𝑵𝒐??「 " + str(Leakiller["keyCmd"]) + " 」")

                        elif cmd.startswith("setkey "):
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                               sep = text.split(" ")
                               key = text.replace(sep[0] + " ","")
                               if key in [""," ","\n",None]:
                                   cl.sendMessage(msg.to, "𝑪𝒉𝒂𝒏𝒈𝒆 ??𝒆𝒚 𝒇𝒂𝒊𝒍𝒆𝒅")
                               else:
                                   Leakiller["keyCmd"] = str(key).lower()
                                   cl.sendMessage(msg.to, "𝒔𝒖𝒄𝒄𝒆𝒔 𝒂𝒕「{}」".format(str(key).lower()))

                        elif text.lower() == "resetkey":
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                               Leakiller["keyCmd"]=""
                               cl.sendMessage(msg.to, "𝑺𝒖𝒄𝒄𝒆𝒔 𝒓𝒆𝒔𝒆𝒕 𝒌𝒆𝒚 𝒄𝒐𝒎𝒎𝒂𝒏𝒅")

                        elif cmd == "/reboot":
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                               cl.sendMessage(msg.to, "𝑾𝒂𝒊𝒕𝒊𝒏𝒈 𝒂 𝒔𝒆𝒄𝒄𝒐𝒏𝒅")
                               Leakiller["rePoint"] = msg.to
                               restartBot()
                               cl.sendMessage(msg.to, "𝑩𝒐𝒕 𝒘𝒂𝒔 𝒓𝒆𝒔𝒕𝒂𝒓𝒕𝒊𝒏𝒈")

                        elif cmd == "runtime":
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                               eltime = time.time() - mulai
                               bot = "𝒘𝒂𝒔 𝒓𝒖𝒏 " +waktu(eltime)
                               cl.sendMessage(msg.to,bot)

                        elif cmd == "ginfo":
                          if msg._from in Zie:
                            try:
                                G = cl.getGroup(msg.to)
                                if G.invitee is None:
                                    gPending = "0"
                                else:
                                    gPending = str(len(G.invitee))
                                if G.preventedJoinByTicket == True:
                                    gQr = "Tertutup"
                                    gTicket = "Tidak ada"
                                else:
                                    gQr = "Terbuka"
                                    gTicket = "https://line.me/R/ti/g/{}".format(str(cl.reissueGroupTicket(G.id)))
                                timeCreated = []
                                timeCreated.append(time.strftime("%d-%m-%Y [ %H:%M:%S ]", time.localtime(int(G.createdTime) / 1000)))
                                cl.sendMessage(msg.to, "  •⌻「𝑮𝒓𝒖𝒑 𝒊𝒏𝒇𝒐」⌻•\n\n 𝒏𝒂𝒎𝒂 𝒈𝒓𝒐𝒖𝒑 : {}".format(G.name)+ "\n𝒊𝒅 𝒈𝒓𝒐𝒖𝒑 : {}".format(G.id)+ "\n𝑷𝒆𝒎𝒃𝒖𝒂𝒕 : {}".format(G.creator.displayName)+ "\n𝑾𝒂𝒌𝒕𝒖 𝒅𝒊𝒃𝒖𝒂𝒕 : {}".format(str(timeCreated))+ "\n𝑱𝒖𝒎𝒍𝒂𝒉 𝒎𝒆𝒎𝒃𝒆𝒓 : {}".format(str(len(G.members)))+ "\n𝑱𝒖𝒎𝒍𝒂𝒉 𝒑𝒆𝒏𝒅𝒊𝒏𝒈 : {}".format(gPending)+ "\n𝑮𝒓𝒐𝒖𝒑 𝒒𝒓 : {}".format(gQr)+ "\n𝑮𝒓𝒐𝒖𝒑 𝒕𝒊𝒄𝒌𝒆𝒕 : {}".format(gTicket))
                                cl.sendMessage(msg.to, None, contentMetadata={'mid': G.creator.mid}, contentType=13)
                                cl.sendImageWithURL(msg.to, 'http://dl.profile.line-cdn.net/'+G.pictureStatus)
                            except Exception as e:
                                cl.sendMessage(msg.to, str(e))

                        elif cmd.startswith("infogrup"):
                          if msg._from in Zie:
                            separate = text.split(" ")
                            number = text.replace(separate[0] + " ","")
                            groups = cl.getGroupIdsJoined()
                            ret_ = ""
                            try:
                                group = groups[int(number)-1]
                                G = cl.getGroup(group)
                                try:
                                    gCreator = G.creator.displayName
                                except:
                                    gCreator = "No file"
                                if G.invitee is None:
                                    gPending = "0"
                                else:
                                    gPending = str(len(G.invitee))
                                if G.preventedJoinByTicket == True:
                                    gQr = "Tertutup"
                                    gTicket = "Tidak ada"
                                else:
                                    gQr = "Terbuka"
                                    gTicket = "https://line.me/R/ti/g/{}".format(str(cl.reissueGroupTicket(G.id)))
                                timeCreated = []
                                timeCreated.append(time.strftime("%d-%m-%Y [ %H:%M:%S ]", time.localtime(int(G.createdTime) / 1000)))
                                ret_ += "  •⌻ List Grup Info ⌻•\n"
                                ret_ += "\n⌬ Nama Group : {}".format(G.name)
                                ret_ += "\n⌬ ID Group : {}".format(G.id)
                                ret_ += "\n⌬ Pembuat : {}".format(gCreator)
                                ret_ += "\n⌬ Waktu Dibuat : {}".format(str(timeCreated))
                                ret_ += "\n⌬ Jumlah Member : {}".format(str(len(G.members)))
                                ret_ += "\n⌬ Jumlah Pending : {}".format(gPending)
                                ret_ += "\n⌬ Group Qr : {}".format(gQr)
                                ret_ += "\n⌬ Group Ticket : {}".format(gTicket)
                                ret_ += ""
                                cl.sendMessage(to, str(ret_))
                            except:
                                pass

                        elif cmd.startswith("infomem"):
                          if msg._from in Zie:
                            separate = msg.text.split(" ")
                            number = msg.text.replace(separate[0] + " ","")
                            groups = cl.getGroupIdsJoined()
                            ret_ = ""
                            try:
                                group = groups[int(number)-1]
                                G = cl.getGroup(group)
                                no = 0
                                ret_ = ""
                                for mem in G.members:
                                    no += 1
                                    ret_ += "\n " "● "+ str(no) + ". " + mem.displayName
                                cl.sendMessage(to,"● 𝑮𝒓𝒐𝒖𝒑 𝑵𝒂𝒎𝒆 : [ " + str(G.name) + " ]\n\n   [ 𝑳𝒊𝒔𝒕 𝑴𝒆𝒎𝒃𝒆𝒓 ]\n" + ret_ + "\n\n「𝑻𝒐𝒕𝒂𝒍 %i 𝑴𝒆𝒎𝒃𝒆𝒓𝒔」" % len(G.members))
                            except:
                                pass

                        elif cmd.startswith("leave: "):
                          if msg._from in Zie:
                            separate = msg.text.split(" ")
                            number = msg.text.replace(separate[0] + " ","")
                            groups = cl.getGroupIdsJoined()
                            group = groups[int(number)-1]
                            for i in group:
                                ginfo = cl.getGroup(i)
                                if ginfo == group:
                                    ka.leaveGroup(i)
                                    kb.leaveGroup(i)
                                    kc.leaveGroup(i)
                                    ka.sendMessage(msg.to,"𝑺𝒖𝒄𝒄𝒆𝒔 𝒍𝒆𝒂𝒗𝒆 𝒊𝒏 𝒈𝒓𝒐𝒖𝒑 " +str(ginfo.name))

                        elif cmd == "friendlist":
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                               ma = ""
                               a = 0
                               gid = cl.getAllContactIds()
                               for i in gid:
                                   G = cl.getContact(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "╠ " + str(a) + ". " +G.displayName+ "\n"
                               cl.sendMessage(msg.to,"╔══[ 𝑭𝒓𝒊𝒆𝒏𝒅 𝑳𝒊𝒔𝒕 ]\n║\n"+ma+"║\n╚══[ 𝑻𝒐𝒕𝒂𝒍「"+str(len(gid))+"」𝑭𝒓𝒊𝒆𝒏𝒅𝒔 ]")

                        elif cmd == "gruplist":
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                               ma = ""
                               a = 0
                               gid = cl.getGroupIdsJoined()
                               for i in gid:
                                   G = cl.getGroup(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "╠ " + str(a) + ". " +G.name+ "\n"
                               cl.sendMessage(msg.to,"╔══[ 𝐆??𝐨𝐮𝐩 𝐋𝐢𝐬𝐭 ]\n║\n"+ma+"║\n╚══[ ??𝒐𝒕𝒂𝒍「"+str(len(gid))+"」𝒈𝒓𝒐𝒖𝒑𝒔 ]")

                        elif cmd == "z1grup":
                            if msg._from in Zie:
                               ma = ""
                               a = 0
                               gid = ka.getGroupIdsJoined()
                               for i in gid:
                                   G = ka.getGroup(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "╠ " + str(a) + ". " +G.name+ "\n"
                               ka.sendMessage(msg.to,"╔══[ 𝐆𝐫𝐨𝐮𝐩 𝐋𝐢𝐬𝐭 ]\n║\n"+ma+"║\n╚══[ 𝑻𝒐𝒕𝒂𝒍「"+str(len(gid))+"」𝒈𝒓𝒐𝒖𝒑𝒔 ]")

                        elif cmd == "z2grup":
                            if msg._from in Zie:
                               ma = ""
                               a = 0
                               gid = kb.getGroupIdsJoined()
                               for i in gid:
                                   G = kb.getGroup(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "╠ " + str(a) + ". " +G.name+ "\n"
                               kb.sendMessage(msg.to,"╔══[ 𝐆𝐫𝐨𝐮𝐩 𝐋𝐢𝐬𝐭 ]\n║\n"+ma+"║\n╚══[ 𝑻𝒐𝒕𝒂𝒍「"+str(len(gid))+"」𝒈𝒓𝒐𝒖𝒑𝒔 ]")

                        elif cmd == "z3grup":
                            if msg._from in Zie:
                               ma = ""
                               a = 0
                               gid = kc.getGroupIdsJoined()
                               for i in gid:
                                   G = kc.getGroup(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "╠ " + str(a) + ". " +G.name+ "\n"
                               kc.sendMessage(msg.to,"╔══[ 𝐆𝐫𝐨𝐮𝐩 𝐋𝐢𝐬𝐭 ]\n║\n"+ma+"║\n╚══[ 𝑻𝒐𝒕𝒂𝒍「"+str(len(gid))+"」𝒈𝒓𝒐𝒖𝒑𝒔 ]")

                        elif cmd == "z4grup":
                            if msg._from in Zie:
                               ma = ""
                               a = 0
                               gid = kd.getGroupIdsJoined()
                               for i in gid:
                                   G = kd.getGroup(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "╠ " + str(a) + ". " +G.name+ "\n"
                               kd.sendMessage(msg.to,"╔══[ 𝐆𝐫𝐨𝐮𝐩 𝐋𝐢𝐬𝐭 ]\n║\n"+ma+"║\n╚══[ 𝑻𝒐𝒕𝒂𝒍「"+str(len(gid))+"」𝒈𝒓𝒐𝒖𝒑𝒔 ]")

                        elif cmd == "z5grup":
                            if msg._from in Zie:
                               ma = ""
                               a = 0
                               gid = ke.getGroupIdsJoined()
                               for i in gid:
                                   G = ke.getGroup(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "╠ " + str(a) + ". " +G.name+ "\n"
                               ke.sendMessage(msg.to,"╔══[ 𝐆𝐫𝐨𝐮𝐩 𝐋𝐢𝐬𝐭 ]\n║\n"+ma+"║\n╚══[ 𝑻𝒐𝒕𝒂𝒍「"+str(len(gid))+"」𝒈𝒓𝒐𝒖𝒑𝒔 ]")

                        elif cmd == "kickergrup":
                            if msg._from in Zie:
                               ma = ""
                               a = 0
                               gid = k1.getGroupIdsJoined()
                               for i in gid:
                                   G = k1.getGroup(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "╠ " + str(a) + ". " +G.name+ "\n"
                               k1.sendMessage(msg.to,"╔══[ 𝐆𝐫𝐨𝐮𝐩 𝐋𝐢𝐬𝐭 ]\n║\n"+ma+"║\n╚══[ 𝑻𝒐𝒕𝒂𝒍「"+str(len(gid))+"」𝒈𝒓𝒐𝒖𝒑𝒔 ]")

                        elif cmd == "ourl":
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                                if msg.toType == 2:
                                   X = cl.getGroup(msg.to)
                                   X.preventedJoinByTicket = False
                                   cl.updateGroup(X)
                                gurl = cl.reissueGroupTicket(msg.to)
                                cl.sendMessage(msg.to,"line://ti/g/" + gurl)

                        elif cmd == "curl":
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                                if msg.toType == 2:
                                   X = cl.getGroup(msg.to)
                                   X.preventedJoinByTicket = True
                                   cl.updateGroup(X)
                                   cl.sendMessage(msg.to, "𝑫𝒐𝒏𝒆°")

                        elif cmd == "zourl":
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                                if msg.toType == 2:
                                   X = ka.getGroup(msg.to)
                                   X.preventedJoinByTicket = False
                                   ka.updateGroup(X)
                                gurl = ka.reissueGroupTicket(msg.to)
                                ka.sendMessage(msg.to,"line://ti/g/" + gurl)

                        elif cmd == "zcurl":
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                                if msg.toType == 2:
                                   X = ka.getGroup(msg.to)
                                   X.preventedJoinByTicket = True
                                   ka.updateGroup(X)
                                   ka.sendMessage(msg.to, "𝑫𝒐𝒏𝒆°")

                        elif cmd == "all urlgrup":
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                                if msg.toType == 2:
                                   x = cl.getGroup(msg.to)
                                   if x.preventedJoinByTicket == True:
                                      x.preventedJoinByTicket = False
                                      cl.updateGroup(x)
                                   gurl = cl.reissueGroupTicket(msg.to)
                                   cl.sendMessage(msg.to, "● 𝑵𝒂𝒎𝒂 : "+str(x.name)+ "\n● 𝒖𝒓𝒍 𝒈𝒓𝒖𝒑 : http://line.me/R/ti/g/"+gurl)

                        elif cmd == "zall urlgrup":
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                                if msg.toType == 2:
                                   x = ka.getGroup(msg.to)
                                   if x.preventedJoinByTicket == True:
                                      x.preventedJoinByTicket = False
                                      ka.updateGroup(x)
                                   gurl = ka.reissueGroupTicket(msg.to)
                                   ka.sendMessage(msg.to, "● 𝑵𝒂𝒎𝒂 : "+str(x.name)+ "\n● 𝒖𝒓𝒍 𝒈𝒓𝒖𝒑 : http://line.me/R/ti/g/"+gurl)

#===========================================#
                        elif cmd == "pictgrup":
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                              if msg.toType == 2:
                                Leakiller["gPicture"] = True
                                cl.sendMessage(msg.to,"𝒑𝒍𝒆𝒂𝒔𝒆 𝒔𝒆𝒏𝒅 𝒑𝒊𝒄𝒕")
                        elif cmd == "updp bot":
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                                Leakiller["DPicture"] = True
                                cl.sendMessage(msg.to,"𝒑𝒍𝒆𝒂𝒔𝒆 𝒔𝒆𝒏𝒅 𝒑𝒊𝒄𝒕")
                        elif 'Dpbot ' in msg.text:
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                              spl = msg.text.replace('Dpbot ','')
                              if spl == '1':
                                  Leakiller["cPicture"][Amid] = True
                                  ka.sendMessage(msg.to, "𝑺𝒆𝒏𝒅 𝒑𝒊𝒄𝒕 𝒃𝒐𝒔𝒔")
                              if spl == '2':
                                  Leakiller["cPicture"][Bmid] = True
                                  kb.sendMessage(msg.to, "𝑺𝒆𝒏𝒅 𝒑𝒊𝒄𝒕 𝒃𝒐𝒔𝒔")
                              if spl == '3':
                                  Leakiller["cPicture"][Cmid] = True
                                  kc.sendMessage(msg.to, "𝑺𝒆𝒏𝒅 𝒑𝒊𝒄𝒕 𝒃𝒐𝒔𝒔")
                              if spl == '4':
                                  Leakiller["cPicture"][Dmid] = True
                                  kd.sendMessage(msg.to, "𝑺𝒆𝒏𝒅 𝒑𝒊𝒄𝒕 𝒃𝒐𝒔𝒔")
                              if spl == '5':
                                  Leakiller["cPicture"][Emid] = True
                                  ke.sendMessage(msg.to, "𝑺𝒆𝒏𝒅 𝒑𝒊𝒄𝒕 𝒃𝒐𝒔𝒔")
                        elif cmd == "my pict":
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                                Leakiller["cPicture"][mid] = True
                                cl.sendMessage(msg.to,"𝑺𝒆𝒏𝒅 𝒑𝒊𝒄𝒕 𝒃𝒐𝒔𝒔")
                        elif cmd == "kickerpict":
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                                Leakiller["cPicture"][Smid] = True
                                k1.sendMessage(msg.to,"𝑺𝒆𝒏𝒅 𝒑𝒊𝒄𝒕 𝒃𝒐𝒔𝒔")
                        elif cmd.startswith("zname: "):
                          if msg._from in Zie:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = cl.getProfile()
                                profile.displayName = string
                                cl.updateProfile(profile)
                                cl.sendMessage(msg.to,"𝑺𝒖𝒄𝒄𝒆𝒔 " + string + "")

                        elif cmd.startswith("z1cn: "):
                          if msg._from in Zie:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = ka.getProfile()
                                profile.displayName = string
                                ka.updateProfile(profile)
                                ka.sendMessage(msg.to,"𝑺𝒖𝒄𝒄𝒆𝒔 " + string + "")

                        elif cmd.startswith("z2cn: "):
                          if msg._from in Zie:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = kb.getProfile()
                                profile.displayName = string
                                kb.updateProfile(profile)
                                kb.sendMessage(msg.to,"𝑺𝒖𝒄𝒄𝒆𝒔 " + string + "")

                        elif cmd.startswith("z3cn: "):
                          if msg._from in Zie:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = kc.getProfile()
                                profile.displayName = string
                                kc.updateProfile(profile)
                                kc.sendMessage(msg.to,"𝑺𝒖𝒄𝒄𝒆𝒔 " + string + "")

                        elif cmd.startswith("z4cn: "):
                          if msg._from in Zie:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = kd.getProfile()
                                profile.displayName = string
                                kd.updateProfile(profile)
                                kd.sendMessage(msg.to,"𝑺𝒖𝒄𝒄𝒆𝒔 " + string + "")

                        elif cmd.startswith("z5cn: "):
                          if msg._from in Zie:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = ke.getProfile()
                                profile.displayName = string
                                ke.updateProfile(profile)
                                ke.sendMessage(msg.to,"𝑺𝒖𝒄𝒄𝒆𝒔 " + string + "")

                        elif cmd.startswith("kickercn: "):
                          if msg._from in Zie:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = k1.getProfile()
                                profile.displayName = string
                                k1.updateProfile(profile)
                                k1.sendMessage(msg.to,"𝑺𝒖𝒄𝒄𝒆𝒔 " + string + "")

                        elif cmd == "woy" or text.lower() == 'mention':
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                                group = cl.getGroup(msg.to)
                                k = len(group.members)//20
                                for j in range(k+1):
                                    aa = []
                                    for x in group.members[j*20 : (j+1)*20]:
                                        aa.append(x.mid)
                                    try:
                                        arrData = ""
                                        textx = "╔══════════════════\n╠☛ . "
                                        arr = []
                                        no = 1
                                        b = 1
                                        for i in aa:
                                            b = b + 1
                                            end = "\n"
                                            mention = "@x\n"
                                            slen = str(len(textx))
                                            elen = str(len(textx) + len(mention) - 1)
                                            arrData = {'S':slen, 'E':elen, 'M':i}
                                            arr.append(arrData)
                                            textx += mention
                                            if no < len(aa):
                                                no += 1
                                                textx += "╠☛ . ".format(str(b))
                                            else:
                                                textx += "╚══════════════════\n╔══════════════════\n  「 𝑻𝒐𝒕𝒂𝒍 𝒎𝒆𝒎𝒃𝒆𝒓 : {} 」\n╚══════════════════".format(str(len(aa)))
                                                try:
                                                    no = "[ {} ]".format(str(cl.getGroup(msg.to).name))

                                                except:
                                                    no = " "
                                        msg.to = msg.to
                                        msg.text = textx
                                        msg.contentMetadata = {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}
                                        msg.contentType = 0
                                        cl.sendMessage(to, textx,{'AGENT_NAME':'[ Mentions ]', 'AGENT_LINK': 'line://ti/p/~{}'.format(cl.getProfile().userid), 'AGENT_ICON': "http://dl.profile.line-cdn.net/" + cl.getProfile().picturePath, 'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
                                    except Exception as e:
                                        cl.sendText(msg.to,str(e))
                        elif cmd == "botlist":
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                                ma = ""
                                a = 0
                                for m_id in Leakiller["Bots"]:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +cl.getContact(m_id).displayName + "\n"
                                cl.sendMessage(msg.to,"  ✴𝑫𝒂𝒇𝒕𝒂𝒓 𝒃𝒐𝒕✴\n\n"+ma+"\n𝑻𝒐𝒕𝒂𝒍 : %s 𝑩𝒐𝒕" %(str(len(Leakiller["Bots"]))))

                        elif cmd == "adminlist":
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                                mb = ""
                                b = 0
                                for m_id in Leakiller["admin"]:
                                    b = b + 1
                                    end = '\n'
                                    mb += str(b) + ". " +cl.getContact(m_id).displayName + "\n"
                                cl.sendMessage(msg.to,"「✴𝑫𝒂𝒇𝒕𝒂𝒓 𝒂𝒅𝒎𝒊𝒏✴」\n\n"+mb+"\n𝑻𝒐𝒕𝒂𝒍 : %s  𝒂𝒅𝒎𝒊𝒏 𝑩𝒐𝒕" %(str(len(Leakiller["admin"]))))

                        elif cmd == "respon":
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                                ka.sendMessage(msg.to,"𝑯𝒂𝒅𝒊𝒓 𝒅𝒂𝒏 𝒔𝒊𝒂𝒑 𝒎𝒆𝒍𝒂𝒚𝒂𝒏𝒊 𝒃𝒐𝒔𝒔 𝒒𝒖𝒉")
                                kb.sendMessage(msg.to,"𝑯𝒂𝒅𝒊𝒓 𝒅𝒂𝒏 𝒔𝒊𝒂𝒑 𝒎𝒆𝒍𝒂𝒚𝒂𝒏𝒊 𝒃𝒐𝒔𝒔 𝒒𝒖𝒉")
                                kc.sendMessage(msg.to,"𝑯𝒂𝒅𝒊𝒓 𝒅𝒂𝒏 𝒔𝒊𝒂𝒑 𝒎𝒆𝒍𝒂𝒚𝒂𝒏𝒊 𝒃𝒐𝒔𝒔 𝒒𝒖𝒉")
                                kd.sendMessage(msg.to,"𝑯𝒂𝒅𝒊𝒓 𝒅𝒂𝒏 𝒔𝒊𝒂𝒑 𝒎𝒆𝒍𝒂𝒚𝒂𝒏𝒊 𝒃𝒐𝒔𝒔 𝒒𝒖𝒉")
                                ke.sendMessage(msg.to,"𝑯𝒂𝒅𝒊𝒓 𝒅𝒂𝒏 𝒔𝒊𝒂𝒑 𝒎𝒆𝒍𝒂𝒚𝒂𝒏𝒊 𝒃𝒐𝒔𝒔 𝒒𝒖𝒉")

                        elif cmd == "pyment":
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                                ka.sendMessage(msg.to,"𝐈𝐧𝐟𝐨𝐫𝐦𝐚𝐬𝐢 𝐍𝐨 𝐑𝐞𝐤𝐞𝐧𝐢𝐧𝐠\n𝐘𝐚𝐲𝐚𝐬𝐚𝐧 𝐀𝐋-𝐌𝐔𝐇𝐇𝐀𝐉𝐈𝐑𝐈𝐍\n𝙱𝙰𝙽𝙺 - 𝙱𝙽𝙸\n𝟎𝟔𝟕𝟒𝟓𝟖𝟎𝟗𝟒𝟕\n𝐀𝐭𝐚𝐬 𝐍𝐚𝐦𝐚:\n𝐁𝐩𝐤 𝐟𝐞𝐫𝐢 𝐬𝐮𝐫𝐲𝐚𝐝𝐢")

                        elif cmd == ".inv":
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                                try:
                                    ang = [Amid,Bmid,Cmid,Dmid,Emid]
                                    cl.inviteIntoGroup(msg.to, ang)
                                    ka.acceptGroupInvitation(msg.to,)
                                    kb.acceptGroupInvitation(msg.to,)
                                    kc.acceptGroupInvitation(msg.to,)
                                    kd.acceptGroupInvitation(msg.to,)
                                    ke.acceptGroupInvitation(msg.to,)
                                except:
                                    pass

                        elif cmd == "ajs stay":
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                                try:
                                    ang = [Smid]
                                    random.choice(Amin).inviteIntoGroup(msg.to, ang)
                                except:
                                    try:
                                        ang = [Smid]
                                        cl.inviteIntoGroup(msg.to, ang)
                                    except:
                                        pass

                        elif cmd == "ajs bye":
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                                G = k1.getGroup(msg.to)
                                k1.sendMessage(msg.to, "𝑺𝒂𝒎𝒑𝒂𝒊 𝒋𝒖𝒎𝒑𝒂 𝒎𝒆𝒎𝒃𝒆𝒓 "+str(G.name))
                                k1.leaveGroup(msg.to)

                        elif cmd == "z1bye":
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                                G = ka.getGroup(msg.to)
                                ka.sendMessage(msg.to, "𝑺𝒂𝒎𝒑𝒂𝒊 𝒋𝒖𝒎𝒑𝒂 𝒎𝒆𝒎𝒃𝒆𝒓 "+str(G.name))
                                ka.leaveGroup(msg.to)

                        elif cmd == "z2bye":
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                                G = kb.getGroup(msg.to)
                                kb.sendMessage(msg.to, "𝑺𝒂𝒎𝒑𝒂𝒊 𝒋𝒖𝒎𝒑𝒂 𝒎𝒆𝒎𝒃𝒆𝒓 "+str(G.name))
                                kb.leaveGroup(msg.to)

                        elif cmd == "z3bye":
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                                G = kc.getGroup(msg.to)
                                kc.sendMessage(msg.to, "𝑺𝒂𝒎𝒑𝒂𝒊 𝒋𝒖𝒎𝒑𝒂 𝒎𝒆𝒎𝒃𝒆𝒓 "+str(G.name))
                                kc.leaveGroup(msg.to)

                        elif cmd == "z4bye":
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                                G = kd.getGroup(msg.to)
                                kd.sendMessage(msg.to, "𝑺𝒂𝒎𝒑𝒂𝒊 𝒋𝒖𝒎𝒑𝒂 𝒎𝒆𝒎𝒃𝒆𝒓 "+str(G.name))
                                kd.leaveGroup(msg.to)

                        elif cmd == "z5bye":
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                                G = ke.getGroup(msg.to)
                                ke.sendMessage(msg.to, "𝑺𝒂𝒎𝒑𝒂𝒊 𝒋𝒖𝒎𝒑𝒂 𝒎𝒆𝒎𝒃𝒆𝒓 "+str(G.name))
                                ke.leaveGroup(msg.to)

                        elif cmd == "masuk":
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                                G = cl.getGroup(msg.to)
                                G.preventedJoinByTicket = False
                                cl.updateGroup(G)
                                invsend = 0
                                Ticket = cl.reissueGroupTicket(msg.to)
                                ka.acceptGroupInvitationByTicket(msg.to,Ticket)
                                kb.acceptGroupInvitationByTicket(msg.to,Ticket)
                                kc.acceptGroupInvitationByTicket(msg.to,Ticket)
                                kd.acceptGroupInvitationByTicket(msg.to,Ticket)
                                ke.acceptGroupInvitationByTicket(msg.to,Ticket)
                                G = cl.getGroup(msg.to)
                                G.preventedJoinByTicket = True
                                cl.updateGroup(G)

                        elif cmd == "pulang":
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                                G = cl.getGroup(msg.to)
                                ka.sendMessage(msg.to, "𝑺𝒂𝒎𝒑𝒂𝒊 𝒋𝒖𝒎𝒑𝒂 𝒎𝒆𝒎𝒃𝒆𝒓 "+str(G.name))
                                kb.leaveGroup(msg.to)
                                kc.leaveGroup(msg.to)
                                kd.leaveGroup(msg.to)
                                ke.leaveGroup(msg.to)
                                ka.leaveGroup(msg.to)

                        elif cmd == "/bye":
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                                G = cl.getGroup(msg.to)
                                cl.sendMessage(msg.to, "𝑺𝒂𝒎𝒑𝒂𝒊 𝒋𝒖𝒎𝒑𝒂 𝒎𝒆𝒎𝒃𝒆𝒓 🙏 "+str(G.name))
                                cl.leaveGroup(msg.to)

                        elif cmd.startswith("leave "):
                            if msg._from in Zie:
                                proses = text.split(" ")
                                ng = text.replace(proses[0] + " ","")
                                gid = cl.getGroupIdsJoined()
                                for i in gid:
                                    h = cl.getGroup(i).name
                                    if h == ng:
                                        ka.sendMessage(i, "")
                                        kb.leaveGroup(i)
                                        kc.leaveGroup(i)
                                        kd.leaveGroup(i)
                                        ke.leaveGroup(i)
                                        ka.sendMessage(to,"𝑳𝒆𝒂𝒗𝒆 𝒔𝒖𝒄𝒄𝒆𝒔 𝒇𝒓𝒐𝒎 " +h)

                        elif cmd == "z1join":
                            if msg._from in Zie:
                                G = cl.getGroup(msg.to)
                                G.preventedJoinByTicket = False
                                cl.updateGroup(G)
                                invsend = 0
                                Ticket = cl.reissueGroupTicket(msg.to)
                                ka.acceptGroupInvitationByTicket(msg.to,Ticket)
                                G = ka.getGroup(msg.to)
                                G.preventedJoinByTicket = True
                                ka.updateGroup(G)

                        elif cmd == "z2join":
                            if msg._from in Zie:
                                G = cl.getGroup(msg.to)
                                G.preventedJoinByTicket = False
                                cl.updateGroup(G)
                                invsend = 0
                                Ticket = cl.reissueGroupTicket(msg.to)
                                kb.acceptGroupInvitationByTicket(msg.to,Ticket)
                                G = kb.getGroup(msg.to)
                                G.preventedJoinByTicket = True
                                kb.updateGroup(G)

                        elif cmd == "z3join":
                            if msg._from in Zie:
                                G = cl.getGroup(msg.to)
                                G.preventedJoinByTicket = False
                                cl.updateGroup(G)
                                invsend = 0
                                Ticket = cl.reissueGroupTicket(msg.to)
                                kc.acceptGroupInvitationByTicket(msg.to,Ticket)
                                G = kc.getGroup(msg.to)
                                G.preventedJoinByTicket = True
                                kc.updateGroup(G)

                        elif cmd == "z4join":
                            if msg._from in Zie:
                                G = cl.getGroup(msg.to)
                                G.preventedJoinByTicket = False
                                cl.updateGroup(G)
                                invsend = 0
                                Ticket = cl.reissueGroupTicket(msg.to)
                                kd.acceptGroupInvitationByTicket(msg.to,Ticket)
                                G = kd.getGroup(msg.to)
                                G.preventedJoinByTicket = True
                                kd.updateGroup(G)

                        elif cmd == "z5join":
                            if msg._from in Zie:
                                G = cl.getGroup(msg.to)
                                G.preventedJoinByTicket = False
                                cl.updateGroup(G)
                                invsend = 0
                                Ticket = cl.reissueGroupTicket(msg.to)
                                ke.acceptGroupInvitationByTicket(msg.to,Ticket)
                                G = ke.getGroup(msg.to)
                                G.preventedJoinByTicket = True
                                ke.updateGroup(G)

                        elif cmd == "ajs join":
                            if msg._from in Zie:
                                G = cl.getGroup(msg.to)
                                G.preventedJoinByTicket = False
                                cl.updateGroup(G)
                                invsend = 0
                                Ticket = cl.reissueGroupTicket(msg.to)
                                k1.acceptGroupInvitationByTicket(msg.to,Ticket)
                                G = k1.getGroup(msg.to)
                                G.preventedJoinByTicket = True
                                k1.updateGroup(G)

                        elif cmd == ".speed respon":
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                                get_profile_time_start = time.time()
                                get_profile = cl.getProfile()
                                get_profile_time = time.time() - get_profile_time_start
                                get_group_time_start = time.time()
                                get_group = cl.getGroupIdsJoined()
                                get_group_time = time.time() - get_group_time_start
                                get_contact_time_start = time.time()
                                get_contact = cl.getContact(mid)
                                get_contact_time = time.time() - get_contact_time_start
                                cl.sendMessage(msg.to, "🚩response 🚩\n\n - 🌏 Speed Profile\n   %.10f\n - ➡ Speed Contact\n   %.10f\n - ➡ Speed Group\n   %.10f" % (get_profile_time/3,get_contact_time/3,get_group_time/3))

                        elif cmd == "speed" or cmd == "sp":
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                               start = time.time()
                               cl.sendMessage(to, "•••")
                               elapsed_time = time.time() - start
                               cl.sendMessage(to,format(str(elapsed_time)))

                        elif cmd == ".speed" or cmd == ".sp":
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                               start = time.time()
                               ka.sendMessage("u3b07c57b6239e5216aa4c7a02687c86d", '.')
                               elapsed_time = time.time() - start
                               ka.sendMessage(msg.to, "%s s" % (elapsed_time))
                               start2 = time.time()
                               kb.sendMessage("u3b07c57b6239e5216aa4c7a02687c86d", '.')
                               elapsed_time = time.time() - start2
                               kb.sendMessage(msg.to, "%s s" % (elapsed_time))
                               start3 = time.time()
                               kc.sendMessage("u3b07c57b6239e5216aa4c7a02687c86d", '.')
                               elapsed_time = time.time() - start3
                               kc.sendMessage(msg.to, "%s " % (elapsed_time))
                               start4 = time.time()
                               kd.sendMessage("u3b07c57b6239e5216aa4c7a02687c86d", '.')
                               elapsed_time = time.time() - start4
                               kd.sendMessage(msg.to, "%s s" % (elapsed_time))
                               start5 = time.time()
                               ke.sendMessage("u3b07c57b6239e5216aa4c7a02687c86d", '.')
                               elapsed_time = time.time() - start5
                               ke.sendMessage(msg.to, "%s s" % (elapsed_time))

                        elif cmd == "lurk on":
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                                 tz = pytz.timezone("Asia/Jakarta")
                                 timeNow = datetime.now(tz=tz)
                                 Leakiller['readPoint'][msg.to] = msg_id
                                 Leakiller['readMember'][msg.to] = {}
                                 cl.sendMessage(msg.to, "𝑳𝒖𝒓𝒌𝒊𝒏𝒈 ??𝒆𝒓𝒉𝒂𝒔𝒊𝒍 𝒅𝒊𝒂𝒌𝒕𝒊𝒇𝒌??𝒏\n𝑻𝒂𝒏𝒈𝒈𝒂?? : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\n𝑱𝒂𝒎 [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]")

                        elif cmd == "lurk off":
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                                 tz = pytz.timezone("Asia/Jakarta")
                                 timeNow = datetime.now(tz=tz)
                                 del Leakiller['readPoint'][msg.to]
                                 del Leakiller['readMember'][msg.to]
                                 cl.sendMessage(msg.to, "𝑳𝒖𝒓𝒌𝒊𝒏𝒈 𝒃𝒆𝒓𝒉𝒂𝒔𝒊𝒍 𝒅𝒊𝒏𝒐𝒏𝒂𝒌𝒕𝒊𝒇𝒌𝒂𝒏\n𝑻𝒂𝒏𝒈𝒈𝒂𝒍 : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\n𝑱𝒂𝒎 [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]")

                        elif cmd == "lurkers":
                          if msg._from in Zie:
                            if msg.to in Leakiller['readPoint']:
                                if Leakiller['readMember'][msg.to] != {}:
                                    aa = []
                                    for x in Leakiller['readMember'][msg.to]:
                                        aa.append(x)
                                    try:
                                        arrData = ""
                                        textx = "  [ Result {} member ]    \n  [ Lurkers ]\n1. ".format(str(len(aa)))
                                        arr = []
                                        no = 1
                                        b = 1
                                        for i in aa:
                                            b = b + 1
                                            end = "\n"
                                            mention = "@x\n"
                                            slen = str(len(textx))
                                            elen = str(len(textx) + len(mention) - 1)
                                            arrData = {'S':slen, 'E':elen, 'M':i}
                                            arr.append(arrData)
                                            tz = pytz.timezone("Asia/Jakarta")
                                            timeNow = datetime.now(tz=tz)
                                            textx += mention
                                            if no < len(aa):
                                                no += 1
                                                textx += str(b) + ". "
                                            else:
                                                try:
                                                    no = "[ {} ]".format(str(cl.getGroup(msg.to).name))
                                                except:
                                                    no = "  "
                                        msg.to = msg.to
                                        msg.text = textx+"\n⌬ Tanggal : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\n⌚ Jam [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]"
                                        msg.contentMetadata = {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}
                                        msg.contentType = 0
                                        cl.sendMessage1(msg)
                                    except:
                                        pass
                                    try:
                                        del Leakiller['readPoint'][msg.to]
                                        del Leakiller['readMember'][msg.to]
                                    except:
                                        pass
                                    Leakiller['readPoint'][msg.to] = msg.id
                                    Leakiller['readMember'][msg.to] = {}
                                else:
                                    cl.sendMessage(msg.to, "𝑼𝒔𝒆𝒓 𝒌𝒐𝒔𝒐𝒏𝒈...")
                            else:
                                cl.sendMessage(msg.to, "𝑲𝒆𝒕𝒊𝒌 𝒍𝒖𝒓𝒌𝒊𝒏𝒈 𝒐𝒏 ")

                        elif cmd == "sider on":
                          if Leakiller["selfbot"] == True:
                           if msg._from in Zie:
                              try:
                                  tz = pytz.timezone("Asia/Jakarta")
                                  timeNow = datetime.now(tz=tz)
                                  cl.sendMessage(msg.to, "╔══════════════\n╠☛ 𝒔𝒕𝒂𝒓𝒕𝒊𝒏𝒈 𝒄𝒆𝒌 𝒔𝒊𝒅𝒆𝒓\n╚══════════════\n╔══════════════\n╠☛ 𝑫𝒂𝒕𝒆 : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\n╠☛ 𝒉𝒐𝒖𝒓 "+ datetime.strftime(timeNow,'%H:%M:%S')+"\n╚══════════════")
                                  del cctv['point'][msg.to]
                                  del cctv['sidermem'][msg.to]
                                  del cctv['cyduk'][msg.to]
                              except:
                                  pass
                              cctv['point'][msg.to] = msg.id
                              cctv['sidermem'][msg.to] = ""
                              cctv['cyduk'][msg.to]=True

                        elif cmd == "sider off":
                          if Leakiller["selfbot"] == True:
                           if msg._from in Zie:
                              if msg.to in cctv['point']:
                                  tz = pytz.timezone("Asia/Jakarta")
                                  timeNow = datetime.now(tz=tz)
                                  cctv['cyduk'][msg.to]=False
                                  cl.sendMessage(msg.to, "╔══════════════\n╠☛ 𝒔𝒊𝒅𝒆𝒓 𝒐𝒇𝒇 𝒎𝒐𝒅𝒆\n╚══════════════")
                              else:
                                  cl.sendMessage(msg.to, "𝒔𝒊𝒅𝒆𝒓 𝒊𝒏 𝒐𝒇𝒇 𝒎𝒐𝒅𝒆")

                        elif cmd.startswith("sholat: "):
                          if msg._from in Zie:
                             sep = text.split(" ")
                             location = text.replace(sep[0] + " ","")
                             with requests.session() as web:
                                  web.headers["user-agent"] = random.choice(settings["userAgent"])
                                  r = web.get("http://api.corrykalam.net/apisholat.php?lokasi={}".format(urllib.parse.quote(location)))
                                  data = r.text
                                  data = json.loads(data)
                                  tz = pytz.timezone("Asia/Jakarta")
                                  timeNow = datetime.now(tz=tz)
                                  if data[1] != "Subuh : " and data[2] != "Dzuhur : " and data[3] != "Ashar : " and data[4] != "Maghrib : " and data[5] != "Isha : ":
                                         ret_ = "「𝑱𝒂𝒅𝒘𝒂𝒍 𝑺𝒉𝒐𝒍𝒂𝒕」"
                                         ret_ += "\n Lokasi : " + data[0]
                                         ret_ += "\n⌬ " + data[1]
                                         ret_ += "\n⌬ " + data[2]
                                         ret_ += "\n⌬ " + data[3]
                                         ret_ += "\n⌬ " + data[4]
                                         ret_ += "\n⌬ " + data[5]
                                         ret_ += "\n\n 𝑻𝒂𝒏𝒈𝒈𝒂𝒍 : " + datetime.strftime(timeNow,'%Y-%m-%d')
                                         ret_ += "\n 𝑱𝒂𝒎 : " + datetime.strftime(timeNow,'%H:%M:%S')
                                  cl.sendMessage(msg.to, str(ret_))

                        elif cmd.startswith("cuaca: "):
                          if msg._from in Zie:
                            separate = text.split(" ")
                            location = text.replace(separate[0] + " ","")
                            with requests.session() as web:
                                web.headers["user-agent"] = random.choice(settings["userAgent"])
                                r = web.get("http://api.corrykalam.net/apicuaca.php?kota={}".format(urllib.parse.quote(location)))
                                data = r.text
                                data = json.loads(data)
                                tz = pytz.timezone("Asia/Jakarta")
                                timeNow = datetime.now(tz=tz)
                                if "result" not in data:
                                    ret_ = "「Status Cuaca」"
                                    ret_ += "\n Lokasi : " + data[0].replace("Temperatur di kota ","")
                                    ret_ += "\n Suhu : " + data[1].replace("Suhu : ","") + " C"
                                    ret_ += "\n Kelembaban : " + data[2].replace("Kelembaban : ","") + " %"
                                    ret_ += "\n Tekanan udara : " + data[3].replace("Tekanan udara : ","") + " HPa"
                                    ret_ += "\n Kecepatan angin : " + data[4].replace("Kecepatan angin : ","") + " m/s"
                                    ret_ += "\n\n Tanggal : " + datetime.strftime(timeNow,'%Y-%m-%d')
                                    ret_ += "\n Jam : " + datetime.strftime(timeNow,'%H:%M:%S')
                                cl.sendMessage(msg.to, str(ret_))

                        elif cmd.startswith("lokasi: "):
                          if msg._from in Zie:
                            separate = msg.text.split(" ")
                            location = msg.text.replace(separate[0] + " ","")
                            with requests.session() as web:
                                web.headers["user-agent"] = random.choice(settings["userAgent"])
                                r = web.get("http://api.corrykalam.net/apiloc.php?lokasi={}".format(urllib.parse.quote(location)))
                                data = r.text
                                data = json.loads(data)
                                if data[0] != "" and data[1] != "" and data[2] != "":
                                    link = "https://www.google.co.id/maps/@{},{},15z".format(str(data[1]), str(data[2]))
                                    ret_ = "「Info Lokasi」"
                                    ret_ += "\n Location : " + data[0]
                                    ret_ += "\n Google Maps : " + link
                                else:
                                    ret_ = "[Details Location] Error : 𝑳𝒐𝒄𝒂𝒕𝒊𝒐𝒏 𝒏𝒐𝒕 𝒇𝒐𝒖𝒏𝒅"
                                cl.sendMessage(msg.to,str(ret_))

                        elif cmd.startswith("lirik: "):
                           if msg._from in Zie:
                               sep = msg.text.split(" ")
                               search = msg.text.replace(sep[0] + " ","")
                               params = {'songname': search}
                               with requests.session() as web:
                                   web.headers["User-Agent"] = random.choice(settings["userAgent"])
                                   r = web.get("https://ide.fdlrcn.com/workspace/yumi-apis/joox?{}".format(urllib.parse.urlencode(params)))
                                   try:
                                      data = json.loads(r.text)
                                      for song in data:
                                          songs = song[5]
                                          lyric = songs.replace('ti:','Title - ')
                                          lyric = lyric.replace('ar:','Artist - ')
                                          lyric = lyric.replace('al:','Album - ')
                                          removeString = "[1234567890.:]"
                                          for char in removeString:
                                              lyric = lyric.replace(char,'')
                                          ret_ = "╔══[ Lyric ]"
                                          ret_ += "\n╠ Nama lagu : {}".format(str(song[0]))
                                          ret_ += "\n╠ Durasi : {}".format(str(song[1]))
                                          ret_ += "\n╠ Link : {}".format(str(song[3]))
                                          ret_ += "\n╚══[ Finish ]\n\nLirik nya :\n{}".format(str(lyric))
                                          cl.sendMessage(msg.to, str(ret_))
                                   except:
                                       cl.sendMessage(to, "𝑳𝒊𝒓𝒊𝒌 𝒕𝒊𝒅𝒂𝒌 𝒅𝒊𝒕𝒆𝒎𝒖𝒌𝒂𝒏")

                        elif cmd.startswith("music: "):
                           if msg._from in Zie:
                              sep = msg.text.split(" ")
                              search = msg.text.replace(sep[0] + " ","")
                              params = {'songname': search}
                              with requests.session() as web:
                                  web.headers["User-Agent"] = random.choice(settings["userAgent"])
                                  r = web.get("https://ide.fdlrcn.com/workspace/yumi-apis/joox?{}".format(urllib.parse.urlencode(params)))
                                  try:
                                      data = json.loads(r.text)
                                      for song in data:
                                          ret_ = "╔══[ Music ]"
                                          ret_ += "\n╠ Nama lagu : {}".format(str(song[0]))
                                          ret_ += "\n╠ Durasi : {}".format(str(song[1]))
                                          ret_ += "\n╠ Link : {}".format(str(song[3]))
                                          ret_ += "\n╚══[ 𝑾𝒂𝒊𝒕𝒊𝒏𝒈 𝑨𝒖𝒅𝒊𝒐 ]"
                                      cl.sendMessage(msg.to, str(ret_))
                                      cl.sendMessage(msg.to, "𝑳𝒐𝒂𝒅𝒊𝒏𝒈....")
                                      cl.sendAudioWithURL(msg.to, song[3])
                                  except:
                                      cl.sendMessage(to, "𝑴𝒖𝒔𝒊𝒌 𝒕𝒊𝒅𝒂𝒌 𝒅𝒊𝒕𝒆𝒎𝒖𝒌𝒂𝒏")

                        elif cmd.startswith("zimage: "):
                          if msg._from in Zie:
                            sep = msg.text.split(" ")
                            search = msg.text.replace(sep[0] + " ","")
                            url = "https://api.xeonwz.ga/api/image/google?q={}".format(urllib.parse.quote(search))
                            with requests.session() as web:
                                web.headers["User-Agent"] = random.choice(settings["userAgent"])
                                r = web.get(url)
                                data = r.text
                                data = json.loads(data)
                                if data["data"] != []:
                                    start = timeit.timeit()
                                    items = data["data"]
                                    path = random.choice(items)
                                    a = items.index(path)
                                    b = len(items)
                                    cl.sendMessage(msg.to,"「Google Image」\nType : Search Image\nTime taken : %seconds" % (start))
                                    cl.sendImageWithURL(msg.to, str(path))

                        elif cmd.startswith("smule: "):
                          if msg._from in Zie:    
                            try:
                                separate = msg.text.split(" ")
                                smule = msg.text.replace(separate[0] + " ","")
                                links = ("https://smule.com/"+smule)
                                ss = ("http://api2.ntcorp.us/screenshot/shot?url={}".format(urllib.parse.quote(links)))
                                cl.sendMessage(msg.to, "𝑺𝒆𝒅𝒂𝒏𝒈 𝑴𝒆𝒏𝒄𝒂𝒓𝒊...")
                                time.sleep(2)
                                cl.sendMessage(msg.to, "ID Smule : "+smule+"\nLink : "+links)
                                cl.sendImageWithURL(msg.to, ss)
                            except Exception as error:
                                pass

                          if cmd.startswith("openqr no "):
                                if msg.toType == 2:
                                    text = cmd.split(" ")
                                    number = text[2]
                                    if number.isdigit():
                                        groups = cl.getGroupIdsJoined()
                                        if int(number) < len(groups) and int(number) >= 0:
                                            groupid = groups[int(number)]
                                            try:
                                                X = cl.getGroup(groupid)
                                                X.preventedJoinByTicket = False
                                                cl.updateGroup(X)
                                                gurl = cl.reissueGroupTicket(groupid)
                                                cl.sendMessage(msg.to,"𝐢𝐧𝐢 𝐥𝐢𝐧𝐤 𝐧𝐲𝐚 𝐛𝐨𝐬𝐬𝐪𝐮𝐡... \nline://ti/g/" + gurl)
                                            except:
                                                cl.sendMessage(msg.to," 𝐆𝐚𝐠𝐚𝐥 𝐛𝐨𝐬𝐬𝐪𝐮𝐡... ")

                        elif cmd.startswith("yt4: "):
                          if msg._from in Zie:
                            try:
                                sep = msg.text.split(" ")
                                textToSearch = msg.text.replace(sep[0] + " ","")
                                query = urllib.parse.quote(textToSearch)
                                search_url="https://www.youtube.com/results?search_query="
                                mozhdr = {'User-Agent': 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'}
                                sb_url = search_url + query
                                sb_get = requests.get(sb_url, headers = mozhdr)
                                soupeddata = BeautifulSoup(sb_get.content, "html.parser")
                                yt_links = soupeddata.find_all("a", class_ = "yt-uix-tile-link")
                                x = (yt_links[1])
                                yt_href =  x.get("href")
                                yt_href = yt_href.replace("watch?v=", "")
                                qx = "https://youtu.be" + str(yt_href)
                                vid = pafy.new(qx)
                                stream = vid.streams
                                best = vid.getbest()
                                best.resolution, best.extension
                                for s in stream:
                                    me = best.url
                                    hasil = ""
                                    title = "Judul [ " + vid.title + " ]"
                                    author = '\n\n Author : ' + str(vid.author)
                                    durasi = '\n Duration : ' + str(vid.duration)
                                    suka = '\n Likes : ' + str(vid.likes)
                                    rating = '\n Rating : ' + str(vid.rating)
                                    deskripsi = '\n Deskripsi : ' + str(vid.description)
                                cl.sendVideoWithURL(msg.to, me)
                                cl.sendMessage(msg.to,title+ author+ durasi+ suka+ rating+ deskripsi)
                            except Exception as e:
                                cl.sendText(msg.to,str(e))

                        elif cmd.startswith("yt3: "):
                          if msg._from in Zie:
                            try:
                                sep = msg.text.split(" ")
                                textToSearch = msg.text.replace(sep[0] + " ","")
                                query = urllib.parse.quote(textToSearch)
                                search_url="https://www.youtube.com/results?search_query="
                                mozhdr = {'User-Agent': 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'}
                                sb_url = search_url + query
                                sb_get = requests.get(sb_url, headers = mozhdr)
                                soupeddata = BeautifulSoup(sb_get.content, "html.parser")
                                yt_links = soupeddata.find_all("a", class_ = "yt-uix-tile-link")
                                x = (yt_links[1])
                                yt_href =  x.get("href")
                                yt_href = yt_href.replace("watch?v=", "")
                                qx = "https://youtu.be" + str(yt_href)
                                vid = pafy.new(qx)
                                stream = vid.streams
                                bestaudio = vid.getbestaudio()
                                bestaudio.bitrate
                                best = vid.getbest()
                                best.resolution, best.extension
                                for s in stream:
                                    shi = bestaudio.url
                                    me = best.url
                                    vin = s.url
                                    hasil = ""
                                    title = "Judul [ " + vid.title + " ]"
                                    author = '\n\n Author : ' + str(vid.author)
                                    durasi = '\n Duration : ' + str(vid.duration)
                                    suka = '\n Likes : ' + str(vid.likes)
                                    rating = '\n Rating : ' + str(vid.rating)
                                    deskripsi = '\n Deskripsi : ' + str(vid.description)
                                cl.sendImageWithURL(msg.to, me)
                                cl.sendAudioWithURL(msg.to, shi)
                                cl.sendMessage(msg.to,title+ author+ durasi+ suka+ rating+ deskripsi)
                            except Exception as e:
                                cl.sendMessage(msg.to,str(e))

                        elif cmd.startswith("profileig: "):
                          if msg._from in Zie:
                            try:
                                sep = msg.text.split(" ")
                                instagram = msg.text.replace(sep[0] + " ","")
                                response = requests.get("https://www.instagram.com/"+instagram+"?__a=1")
                                data = response.json()
                                namaIG = str(data['user']['full_name'])
                                bioIG = str(data['user']['biography'])
                                mediaIG = str(data['user']['media']['count'])
                                verifIG = str(data['user']['is_verified'])
                                usernameIG = str(data['user']['username'])
                                followerIG = str(data['user']['followed_by']['count'])
                                profileIG = data['user']['profile_pic_url_hd']
                                privateIG = str(data['user']['is_private'])
                                followIG = str(data['user']['follows']['count'])
                                link = " Link : " + "https://www.instagram.com/" + instagram
                                text = " Name : "+namaIG+"\n Username : "+usernameIG+"\n Biography : "+bioIG+"\n Follower : "+followerIG+"\n Following : "+followIG+"\n Post : "+mediaIG+"\n Verified : "+verifIG+"\n Private : "+privateIG+"" "\n" + link
                                cl.sendImageWithURL(msg.to, profileIG)
                                cl.sendMessage(msg.to, str(text))
                            except Exception as e:
                                    cl.sendMessage(msg.to, str(e))

                        elif cmd.startswith("cekdate: "):
                          if msg._from in Zie:
                            sep = msg.text.split(" ")
                            tanggal = msg.text.replace(sep[0] + " ","")
                            r=requests.get('https://script.google.com/macros/exec?service=AKfycbw7gKzP-WYV2F5mc9RaR7yE3Ve1yN91Tjs91hp_jHSE02dSv9w&nama=ervan&tanggal='+tanggal)
                            data=r.text
                            data=json.loads(data)
                            lahir = data["data"]["lahir"]
                            usia = data["data"]["usia"]
                            ultah = data["data"]["ultah"]
                            zodiak = data["data"]["zodiak"]
                            cl.sendMessage(msg.to,"⇸「 𝑰 𝑵 𝑭 𝑶 」⇷\n\n"+" 𝑫𝒂𝒕𝒆 𝑶𝒇 𝑩𝒊𝒓𝒕𝒉 : "+lahir+"\n 𝑨𝒈𝒆 : "+usia+"\n 𝑼𝒍𝒕𝒂𝒉 : "+ultah+"\n 𝒁𝒐𝒅𝒊𝒂𝒌 : "+zodiak)

                        elif cmd.startswith("max: "):
                          if Leakiller["selfbot"] == True:
                           if msg._from in Zie:
                                proses = text.split(":")
                                strnum = text.replace(proses[0] + ":","")
                                num =  int(strnum)
                                Leakiller["Maxlimit"] = num
                                cl.sendMessage(msg.to,"𝑴𝒂𝒙 𝒔𝒑𝒂𝒎 𝑻𝒂𝒈 " +strnum)

                        elif cmd.startswith("scall: "):
                          if Leakiller["selfbot"] == True:
                           if msg._from in Zie:
                                proses = text.split(":")
                                strnum = text.replace(proses[0] + ":","")
                                num =  int(strnum)
                                Leakiller["limit"] = num
                                cl.sendMessage(msg.to,"𝑴𝒂𝒙 𝒔𝒑𝒂𝒎 𝒄𝒂𝒍𝒍 " +strnum)

                        elif cmd.startswith("stag "):
                          if Leakiller["selfbot"] == True:
                           if msg._from in Zie:
                                if 'MENTION' in msg.contentMetadata.keys()!=None:
                                    key = eval(msg.contentMetadata["MENTION"])
                                    key1 = key["MENTIONEES"][0]["M"]
                                    zx = ""
                                    zxc = " "
                                    zx2 = []
                                    pesan2 = "@a"" "
                                    xlen = str(len(zxc))
                                    xlen2 = str(len(zxc)+len(pesan2)-1)
                                    zx = {'S':xlen, 'E':xlen2, 'M':key1}
                                    zx2.append(zx)
                                    zxc += pesan2
                                    msg.contentType = 0
                                    msg.text = zxc
                                    lol = {'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}
                                    msg.contentMetadata = lol
                                    jmlh = int(Leakiller["Maxlimit"])
                                    if jmlh <= 1000:
                                        for x in range(jmlh):
                                            try:
                                                cl.sendMessage1(msg)
                                            except Exception as e:
                                                cl.sendText(msg.to,str(e))
                                    else:
                                        cl.sendMessage(msg.to,"𝑱𝒖𝒎𝒍𝒂𝒉 𝒎𝒆𝒍𝒆𝒃𝒊𝒉𝒊 𝟏𝟎𝟎𝟎")

                        elif cmd == "scall":
                          if Leakiller["selfbot"] == True:
                           if msg._from in Zie:
                             if msg.toType == 2:
                                group = cl.getGroup(to)
                                members = [mem.mid for mem in group.members]
                                jmlh = int(Leakiller["limit"])
                                cl.sendMessage(to, "𝑺𝒖𝒄𝒄𝒆𝒔 {} 𝑺𝒑𝒂𝒎 𝑪𝒂𝒍𝒍".format(str(LiproSett["limit"])))
                                if jmlh <= 1000:
                                  for x in range(jmlh):
                                     try:
                                         cl.acquireGroupCallRoute(to)
                                         cl.inviteIntoGroupCall(to, contactIds=members)
                                     except:
                                         pass
                                else:
                                    cl.sendMessage(to,"𝑱𝒖𝒎𝒍𝒂𝒉 𝒎𝒆𝒍𝒆𝒃𝒊𝒉𝒊 𝒃𝒂𝒕𝒂𝒔")

                        elif 'Gift: ' in msg.text:
                          if Leakiller["selfbot"] == True:
                           if msg._from in Zie:
                              korban = msg.text.replace('Gift: ','')
                              korban2 = korban.split()
                              midd = korban2[0]
                              jumlah = int(korban2[1])
                              if jumlah <= 1000:
                                  for var in range(0,jumlah):
                                      cl.sendMessage(midd, None, contentMetadata={'PRDID': 'a0768339-c2d3-4189-9653-2909e9bb6f58', 'PRDTYPE': 'THEME', 'MSGTPL': '6'}, contentType=9)

                        elif 'Spam: ' in msg.text:
                          if Leakiller["selfbot"] == True:
                           if msg._from in Zie:
                              korban = msg.text.replace('Spam: ','')
                              korban2 = korban.split()
                              midd = korban2[0]
                              jumlah = int(korban2[1])
                              if jumlah <= 1000:
                                  for var in range(0,jumlah):
                                      cl.sendMessage(midd, str(Leakiller["spamMsg"]))
                                      ka.sendMessage(midd, str(Leakiller["spamMsg"]))
                                      kb.sendMessage(midd, str(Leakiller["spamMsg"]))
                                      kc.sendMessage(midd, str(Leakiller["spamMsg"]))
                                      kd.sendMessage(midd, str(Leakiller["spamMsg"]))
                                      ke.sendMessage(midd, str(Leakiller["spamMsg"]))

                        elif 'ID line: ' in msg.text:
                          if Leakiller["selfbot"] == True:
                           if msg._from in Zie:
                              msgs = msg.text.replace('ID line: ','')
                              conn = cl.findContactsByUserid(msgs)
                              if True:
                                  cl.sendMessage(msg.to, "http://line.me/ti/p/~" + msgs)
                                  cl.sendMessage(msg.to, None, contentMetadata={'mid': conn.mid}, contentType=13)

                        elif 'Welcome ' in msg.text:
                          if Leakiller["selfbot"] == True:
                           if msg._from in Zie:
                              spl = msg.text.replace('Welcome ','')
                              if spl == 'on':
                                  if msg.to in Leakiller["welcome"]:
                                       msgs = "𝑴𝒔𝒈 𝑾𝒆𝒍𝒄𝒐𝒎𝒆 𝒘𝒂𝒔 𝒐𝒏"
                                  else:
                                       Leakiller["welcome"][msg.to] = True
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "𝑰𝒏 𝑮𝒓𝒐𝒖𝒑: " +str(ginfo.name)
                                  cl.sendMessage(msg.to, "「𝒐𝒏 𝒎𝒐𝒅𝒆」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in Leakiller["welcome"]:
                                         del Leakiller["welcome"][msg.to]
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "𝑰𝒏 𝑮𝒓𝒐𝒖𝒑 : " +str(ginfo.name)
                                    else:
                                         msgs = "𝑴𝒔𝒈 𝑾𝒆𝒍𝒄𝒐𝒎𝒆 𝒎𝒐𝒅𝒆 𝒐𝒏"
                                    cl.sendMessage(msg.to, "「𝒐𝒇𝒇 𝒎𝒐𝒅𝒆」\n" + msgs)
                        elif 'Left ' in msg.text:
                          if Leakiller["selfbot"] == True:
                           if msg._from in Zie:
                              spl = msg.text.replace('Left ','')
                              if spl == 'on':
                                  if msg.to in Leakiller["leaveMsg"]:
                                       msgs = "𝑴𝒔𝒈 𝑳𝒆𝒇𝒕 𝒘𝒂𝒔 𝒐𝒏"
                                  else:
                                       Leakiller["leaveMsg"][msg.to] = True
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "𝑰𝒏 𝑮𝒓𝒐𝒖𝒑 : " +str(ginfo.name)
                                  cl.sendMessage(msg.to, "「𝒐𝒏 𝒎𝒐𝒅𝒆」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in Leakiller["leaveMsg"]:
                                         del Leakiller["leaveMsg"][msg.to]
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "𝑰𝒏 𝑮𝒓𝒐𝒖𝒑 : " +str(ginfo.name)
                                    else:
                                         msgs = "𝑴𝒔𝒈 𝑳𝒆𝒂𝒗𝒆 𝒎𝒐𝒅𝒆 𝒐𝒏"
                                    cl.sendMessage(msg.to, "「𝒐𝒇𝒇 𝒎𝒐𝒅𝒆」\n" + msgs)
                        elif 'Proqr ' in msg.text:
                          if Leakiller["selfbot"] == True:
                           if msg._from in Zie:
                              spl = msg.text.replace('Proqr ','')
                              if spl == 'on':
                                  if msg.to in Leakiller["proqr"]:
                                       msgs = "𝑺𝒖𝒄𝒄𝒆𝒔"
                                  else:
                                       Leakiller["proqr"][msg.to] = True
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "𝑰𝒏 𝑮𝒓𝒐𝒖𝒑 : " +str(ginfo.name)
                                  cl.sendMessage(msg.to, "「𝒐𝒏 𝒎𝒐𝒅𝒆」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in Leakiller["proqr"]:
                                         del Leakiller["proqr"][msg.to]
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "𝑰𝒏 𝑮𝒓𝒐𝒖𝒑 : " +str(ginfo.name)
                                    else:
                                         msgs = "Protect url on"
                                    cl.sendMessage(msg.to, "「𝒐𝒇𝒇 𝒎𝒐𝒅𝒆」\n" + msgs)
                        elif 'Autokick ' in msg.text:
                          if Leakiller["selfbot"] == True:
                           if msg._from in Zie:
                              spl = msg.text.replace('Autokick ','')
                              if spl == 'on':
                                  if msg.to in Leakiller["proKick"]:
                                       msgs = "𝑨𝒖𝒕𝒐𝒌𝒊𝒄𝒌 𝒐𝒏"
                                  else:
                                       Leakiller["proKick"][msg.to] = True
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "𝑰𝒏 𝑮𝒓𝒐𝒖𝒑 : " +str(ginfo.name)
                                  cl.sendMessage(msg.to, "「𝒐𝒏 𝒎𝒐𝒅𝒆」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in Leakiller["proKick"]:
                                         del Leakiller["proKick"][msg.to]
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "𝑰𝒏 𝑮𝒓𝒐𝒖𝒑 : " +str(ginfo.name)
                                    else:
                                         msgs = "Autokick off"
                                    cl.sendMessage(msg.to, "「𝒐𝒇𝒇 𝒎𝒐𝒅𝒆」\n" + msgs)
                        elif 'Procancel ' in msg.text:
                          if Leakiller["selfbot"] == True:
                           if msg._from in Zie:
                              spl = msg.text.replace('Procancel ','')
                              if spl == 'on':
                                  if msg.to in Leakiller["proCancel"]:
                                       msgs = "𝑷𝒓𝒐𝒄𝒂𝒏𝒄𝒆𝒍 𝒐𝒏"
                                  else:
                                       Leakiller["proCancel"] = True
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "𝑰𝒏 𝑮𝒓𝒐𝒖𝒑 : " +str(ginfo.name)
                                  cl.sendMessage(msg.to, "「𝒐𝒏 𝒎𝒐𝒅𝒆」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in Leakiller["proCancel"]:
                                         Leakiller["proCancel"][msg.to]
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "𝑰𝒏 𝑮𝒓𝒐𝒖𝒑 : " +str(ginfo.name)
                                    else:
                                         msgs = "Procancel off"
                                    cl.sendMessage(msg.to, "「𝒐𝒇𝒇 𝒎𝒐𝒅𝒆」\n" + msgs)
                        elif 'Protect ' in msg.text:
                          if Leakiller["selfbot"] == True:
                           if msg._from in Zie:
                              spl = msg.text.replace('Protect ','')
                              if spl == 'on':
                                  if msg.to in Leakiller["proqr"]:
                                       msgs = ""
                                  else:
                                       Leakiller["proqr"][msg.to] = True
                                  if msg.to in Leakiller["proKick"]:
                                      msgs = ""
                                  else:
                                       Leakiller["proKick"][msg.to] = True
                                  if msg.to in Leakiller["proInvite"]:
                                      msgs = ""
                                  else:
                                       Leakiller["proInvite"][msg.to] = True
                                  if msg.to in Leakiller["proCancel"]:
                                      ginfo = cl.getGroup(msg.to)
                                      msgs = "𝑯𝒊𝒈𝒉 𝑨𝒍𝒍𝒑𝒓𝒐𝒕𝒆𝒄𝒕𝒊𝒐𝒏 𝒎𝒐𝒅𝒆 𝒐𝒏 𝒂𝒕 : " +str(ginfo.name)
                                  else:
                                       Leakiller["proCancel"][msg.to] = True
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "𝑯𝒊𝒈𝒉 𝑨𝒍𝒍𝒑𝒓𝒐𝒕𝒆𝒄𝒕𝒊𝒐𝒏 𝒎𝒐𝒅𝒆 𝒐𝒏 𝒂𝒕 : " +str(ginfo.name)
                                  cl.sendMessage(msg.to, "「𝒐𝒏 𝒎𝒐𝒅𝒆」\n\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in Leakiller["proqr"]:
                                         del Leakiller["proqr"][msg.to]
                                    else:
                                         msgs = ""
                                    if msg.to in Leakiller["proKick"]:
                                         del Leakiller["proKick"][msg.to]
                                    else:
                                         msgs = ""
                                    if msg.to in Leakiller["proInvite"]:
                                         del Leakiller["proInvite"][msg.to]
                                    else:
                                         msgs = ""
                                    if msg.to in Leakiller["proCancel"]:
                                         del Leakiller["proCancel"][msg.to]
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "𝑷𝒓𝒐𝒕𝒆𝒄𝒕𝒊𝒐𝒏 𝒎𝒐𝒅𝒆 𝒐𝒇𝒇 𝒂𝒕 : " +str(ginfo.name)
                                    else:
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "𝑷𝒓𝒐𝒕𝒆𝒄𝒕𝒊𝒐𝒏 𝒎𝒐𝒅𝒆 𝒐𝒇𝒇 𝒂𝒕 : " +str(ginfo.name)
                                    cl.sendMessage(msg.to, "「𝒐𝒇𝒇 𝒎𝒐𝒅𝒆」\n\n" + msgs)
                        elif 'Inta ' in msg.text:
                          if Leakiller["selfbot"] == True:
                           if msg._from in Zie:
                              spl = msg.text.replace('Inta ','')
                              if spl == 'on':
                                  if msg.to in Leakiller["intaPoint"]:
                                       msgs = "𝑰𝒏𝒕𝒂 𝒐𝒏"
                                  else:
                                       Leakiller["intaPoint"][msg.to] = True
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "𝑰𝒏𝒕𝒂𝑷𝒐𝒊𝒏𝒕 𝒐𝒏 𝒂𝒕 𝑮𝒓𝒐𝒖𝒑 : " +str(ginfo.name)
                                  cl.sendMessage(msg.to, "「𝒐𝒏 𝒎𝒐𝒅𝒆」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in Leakiller["intaPoint"]:
                                         del Leakiller["intaPoint"][msg.to]
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "𝑰𝒏𝒕𝒂𝒑𝒐𝒊𝒏𝒕 𝒐𝒇𝒇 𝒂𝒕 𝑮𝒓𝒐𝒖𝒑 : " +str(ginfo.name)
                                    else:
                                         msgs = "𝑰𝒏𝒕𝒂 𝒐𝒇𝒇"
                                    cl.sendMessage(msg.to, "「𝒐𝒇𝒇 𝒎𝒐𝒅𝒆」\n" + msgs)

                        elif 'Mytoken' in msg.text:
                          if Leakiller["selfbot"] == True:
                           if msg._from in Zie:
                               cl.sendMessage(msg.to,"𝒊𝒏𝒊 𝒕𝒐𝒌𝒆𝒏𝒌𝒖\n"+cl.authToken)
                               ka.sendMessage(msg.to,"𝒊𝒏𝒊 𝒕𝒐𝒌𝒆𝒏𝒌𝒖\n"+ka.authToken)
                               kb.sendMessage(msg.to,"𝒊𝒏𝒊 𝒕𝒐𝒌𝒆𝒏𝒌𝒖\n"+kb.authToken)
                               kc.sendMessage(msg.to,"𝒊𝒏𝒊 𝒕𝒐𝒌𝒆𝒏𝒌𝒖\n"+kc.authToken)
                               kd.sendMessage(msg.to,"𝒊𝒏𝒊 𝒕𝒐𝒌𝒆𝒏𝒌𝒖\n"+kd.authToken)
                               ke.sendMessage(msg.to,"𝒊𝒏𝒊 𝒕𝒐𝒌𝒆𝒏𝒌𝒖\n"+kf.authToken)

                        elif ("Add con " in msg.text):
                          if LiproSett["selfbot"] == True:
                            if msg._from in Ang:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                   targets.append(x["M"])
                               for target in targets:
                                   try:
                                       kays = cl.getContact(target)
                                       time.sleep(4)
                                       cl.findAndAddContactsByMid(kays.mid)
                                       time.sleep(4)
                                       cl.sendMessage(msg.to,"Done add " + cl.getContact(target).displayName + " Done add my friend")
                                   except Exception as e:
                                       print(e)

                        elif ("Bot kick " in msg.text):
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Lea:
                                       try:
                                           cl.sendMessage(msg.to, "𝒔𝒐𝒓𝒓𝒚 𝒃𝒐𝒄𝒂𝒉 𝒍𝒖,,𝒈𝒘 𝒌𝒊𝒄𝒌..!!!")
                                           random.choice(Amin).kickoutFromGroup(msg.to, [target])
                                       except:
                                           pass

                        elif ("Z1 kick " in msg.text):
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Lea:
                                       try:
                                           ka.kickoutFromGroup(msg.to, [target])
                                       except:
                                           pass

                        elif ("Z2 kick " in msg.text):
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Lea:
                                       try:
                                           kb.kickoutFromGroup(msg.to, [target])
                                       except:
                                           pass

                        elif ("Z3 kick " in msg.text):
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Lea:
                                       try:
                                           kc.kickoutFromGroup(msg.to, [target])
                                       except:
                                           pass

                        elif ("Z4 kick " in msg.text):
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Lea:
                                       try:
                                           kd.kickoutFromGroup(msg.to, [target])
                                       except:
                                           pass

                        elif ("Z5 kick " in msg.text):
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Lea:
                                       try:
                                           ke.kickoutFromGroup(msg.to, [target])
                                       except:
                                           pass

                        elif ("Kiss " in msg.text):
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Lea:
                                       try:
                                           cl.kickoutFromGroup(msg.to, [target])
                                       except:
                                           pass

                        elif ("Kicker kick " in msg.text):
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Lea:
                                       try:
                                           G = cl.getGroup(msg.to)
                                           G.preventedJoinByTicket = False
                                           cl.updateGroup(G)
                                           invsend = 0
                                           Ti = cl.reissueGroupTicket(msg.to)
                                           k1.acceptGroupInvitationByTicket(msg.to,Ti)
                                           k1.kickoutFromGroup(msg.to, [target])
                                           X = k1.getGroup(msg.to)
                                           X.preventedJoinByTicket = True
                                           k1.updateGroup(X)
                                           k1.leaveGroup(msg.to)
                                       except:
                                           pass

                        elif ("Cancel" in msg.text):
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                               group = cl.getGroup(msg.to)
                               if group.invitee is None:
                                   cl.sendMessage(op.message.to, "𝒆𝒎𝒑𝒕𝒚 ")
                               else:
                                   nama = [contact.mid for contact in group.invitee]
                                   for x in nama:
                                     if x not in Lea and x not in Leakiller["Bots"] and x not in Leakiller["admin"]:
                                       cl.cancelGroupInvitation(msg.to, [x])
                                       time.sleep(0.3)
                                   cl.sendMessage(to, "𝒅𝒐𝒏𝒆.")

                        elif ("Bot cancel" in msg.text):
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                               group = cl.getGroup(msg.to)
                               if group.invitee is None:
                                   cl.sendMessage(op.message.to, "𝒆𝒎𝒑𝒕𝒚 ")
                               else:
                                   nama = [contact.mid for contact in group.invitee]
                                   for x in nama:
                                     if x not in Lea and x not in Leakiller["Bots"] and x not in Leakiller["admin"]:
                                       random.choice(Amin).cancelGroupInvitation(msg.to, [x])
                                       time.sleep(0.3)
                                   cl.sendMessage(to, "𝒅𝒐𝒏𝒆.")

                        elif ("Addadmin " in msg.text):
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target in Leakiller["admin"]:
                                       cl.sendMessage(msg.to,"𝒘𝒂𝒔 𝒂𝒅𝒎𝒊𝒏")
                                   else:
                                       try:
                                           Leakiller["admin"][target] = True
                                           cl.sendMessage(msg.to,"𝑺𝒖𝒄𝒄𝒆𝒔 𝒂𝒅𝒅 𝒂𝒅𝒎𝒊𝒏")
                                       except:
                                           pass
                        elif ("Addbot " in msg.text):
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target in Leakiller["Bots"]:
                                       cl.sendMessage(msg.to,"𝒘𝒂𝒔 𝒃𝒐𝒕")
                                   else:
                                       try:
                                           Leakiller["Bots"][target] = True
                                           cl.sendMessage(msg.to,"𝑺𝒖𝒄𝒄𝒆𝒔 𝒂𝒅𝒅 𝒃𝒐𝒕")
                                       except:
                                           pass
                        elif ("Deladmin " in msg.text):
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Leakiller["admin"]:
                                       cl.sendMessage(msg.to,"𝒏𝒐𝒕 𝒊𝒏 𝒂𝒅𝒎𝒊𝒏")
                                   else:
                                        try:
                                            del Leakiller["admin"][target]
                                            cl.sendMessage(msg.to,"𝑺𝒖𝒄𝒄𝒆𝒔 𝒅𝒆𝒍𝒆𝒕𝒆 𝒂𝒅𝒎𝒊𝒏")
                                        except:
                                            pass
                        elif ("Delbot " in msg.text):
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Leakiller["Bots"]:
                                       cl.sendMessage(msg.to,"𝒏𝒐𝒕 𝒊𝒏 𝒃𝒐𝒕𝒔")
                                   else:
                                        try:
                                            del Leakiller["Bots"][target]
                                            cl.sendMessage(msg.to,"𝑺𝒖𝒄𝒄𝒆𝒔 𝒅𝒆𝒍𝒆𝒕𝒆 𝒃𝒐𝒕𝒔")
                                        except:
                                            pass
                        elif cmd == "cbot" or text.lower() == 'clear bot':
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                              ang = cl.getContacts(Leakiller["Bots"])
                              mc = "%i Bots " % len(ang)
                              cl.sendMessage(msg.to,"𝒅𝒐𝒏𝒆 𝒃𝒐𝒔𝒔 " +mc)
                              Leakiller["Bots"] = {}
                        elif cmd == "cadmin" or text.lower() == 'clear admin':
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                              ang = cl.getContacts(Leakiller["admin"])
                              mc = "%i Admin " % len(ang)
                              cl.sendMessage(msg.to,"𝒅𝒐𝒏𝒆 𝒃𝒐𝒔𝒔 " +mc)
                              Leakiller["admin"] = {}
                        elif cmd == "admin:on" or text.lower() == 'admin:on':
                          if Leakiller["selfbot"] == True:
                            if msg._from in Z8e:
                                Leakiller["addadmin"] = True
                                cl.sendMessage(msg.to,"𝑺𝒆𝒏𝒅 𝑪𝒐??𝒕𝒂𝒄𝒕...")
                        elif cmd == "admin:del" or text.lower() == 'admin:del':
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                                Leakiller["deladmin"] = True
                                cl.sendMessage(msg.to,"𝑺𝒆𝒏𝒅 𝑪𝒐𝒏𝒕𝒂𝒄𝒕...")
                        elif cmd == "admin:off" or text.lower() == 'admin off':
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                                Leakiller["addadmin"] = False
                                cl.sendMessage(msg.to,"𝑺𝒆𝒏𝒅 𝑪𝒐𝒏𝒕𝒂𝒄𝒕...")
                        elif cmd == "deladmin:off" or text.lower() == 'deladmin off':
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                                Leakiller["deladmin"] = False
                                cl.sendMessage(msg.to,"𝒅𝒐𝒏𝒆")
                        elif cmd == "bot:on" or text.lower() == 'bot on':
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                                Leakiller["abots"] = True
                                cl.sendMessage(msg.to,"𝑺𝒆𝒏𝒅 𝑪𝒐𝒏𝒕𝒂𝒄𝒕...")
                        elif cmd == "bot:off" or text.lower() == 'bot off':
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                                Leakiller["abots"] = False
                                cl.sendMessage(msg.to,"𝒅𝒐𝒏𝒆 𝒃𝒐𝒔𝒔")
                        elif cmd == "bot:del" or text.lower() == 'bot del':
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                                Leakiller["dbots"] = True
                                cl.sendMessage(msg.to,"𝑺𝒆𝒏𝒅 𝑪𝒐𝒏𝒕𝒂𝒄𝒕...")
                        elif cmd == "delbot:off" or text.lower() == 'delbot off':
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                                Leakiller["dbots"] = False
                                cl.sendMessage(msg.to,"𝒅𝒐𝒏𝒆")
                        elif cmd == "allrefresh" or text.lower() == 'refresh':
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                                Leakiller["addadmin"] = False
                                Leakiller["deladmin"] = False
                                Leakiller["abots"] = False
                                Leakiller["dbots"] = False
                                Leakiller["ablacklist"] = False
                                Leakiller["dblacklist"] = False
                                cl.sendMessage(msg.to,"𝒅𝒐𝒏𝒆 𝒃𝒐𝒔𝒒𝒖𝒉")
                        elif cmd == "baper" or text.lower() == 'lemper':
                            cl.sendImageWithURL(msg.to,"𝐩𝐮𝐬𝐤𝐮𝐧 𝐚𝐣𝐚 𝐥𝐮 𝐤𝐚𝐥𝐨 𝐛𝐚𝐩𝐞𝐫𝐚𝐧") 
                        elif cmd == "pm" or text.lower() == 'pm bentar':
                            cl.sendMessage(msg.to, "𝐦𝐮𝐥𝐚𝐢 𝐧𝐢𝐜𝐡 𝐤𝐚𝐧𝐠 𝐜𝐚𝐛𝐮𝐥 𝐦𝐨 𝐧𝐢𝐤𝐮𝐧𝐠")
                        elif cmd == "kojom" or text.lower() == 'mojok':
                            cl.sendMessage(msg.to, "𝐦𝐨 𝐤𝐨𝐣𝐨𝐦 𝐬𝐚𝐦𝐚 𝐜𝐩𝐚 𝐥𝐮???,𝐤𝐚𝐲𝐚𝐤 𝐲𝐠 𝐥𝐚𝐤𝐮 𝐚𝐣𝐚")
                        elif cmd == "sue" or text.lower() == 'suek':
                            cl.sendMessage(msg.to, "𝐤𝐚𝐥𝐨 𝐬𝐮𝐞𝐤 𝐲𝐚 𝐝𝐢𝐣𝐚𝐡𝐢𝐭 𝐝𝐮𝐝𝐮𝐥")
                        elif cmd == "dudul" or text.lower() == 'dodol':
                            cl.sendMessage(msg.to, "𝐧𝐚𝐡,,,𝐭𝐮𝐡 𝐥𝐮 𝐭𝐚𝐮 𝐤𝐥𝐨 𝐝𝐢𝐚 𝐝𝐮𝐝𝐮𝐥...")
                        elif cmd == "asem" or text.lower() == 'sem':
                            cl.sendMessage(msg.to, "𝐤𝐞𝐭𝐢𝐚𝐤 𝐥𝐮 𝐭𝐮𝐡 𝐲𝐠 𝐚𝐬𝐞𝐦,𝐝𝐚𝐬𝐚𝐫𝐧𝐲𝐚 𝐥𝐮 𝐣𝐚𝐫𝐚𝐧𝐠 𝐦𝐚𝐧𝐝𝐢 𝐬𝐢𝐜𝐡...")
                        elif cmd == "nah" or text.lower() == 'nah':
                            cl.sendMessage(msg.to, "𝐧𝐚𝐡 𝐚𝐩𝐚...??,,,𝐤𝐚𝐠𝐚 𝐣𝐞𝐥𝐚𝐬 𝐚𝐦𝐚𝐭 𝐥𝐮 𝐣𝐚𝐝𝐢 𝐨𝐫𝐚𝐧𝐠...")
                        elif cmd == "bot" or text.lower() == 'botak':
                            cl.sendMessage(msg.to, "𝐚𝐩𝐚 𝐥𝐮 𝐦𝐚𝐧𝐠𝐠𝐢𝐥\" 𝐠𝐰...???")
                        elif cmd == "bah" or text.lower() == 'bahh':
                            cl.sendMessage(msg.to, "𝒉𝒐𝒓𝒂𝒔 𝒃𝒂𝒉.., 𝒉𝒂𝒃𝒊𝒔 𝒃𝒆𝒓𝒂𝒔 𝒎𝒂𝒌𝒂𝒏 𝒈𝒂𝒃𝒂𝒉")
                        elif cmd == "naik" or text.lower() == 'naik':
                            cl.sendMessage(msg.to, "𝐦𝐨𝐨𝐡𝐡𝐡,,,,,𝐝𝐢𝐚𝐭𝐚𝐬 𝐤𝐚𝐧𝐠 𝐜𝐚𝐛𝐮𝐥 𝐬𝐞𝐦𝐮𝐚...")
                        elif cmd == "assalamualaikum" or text.lower() == 'asalamualaikum':
                            cl.sendMessage(msg.to, "𝐰𝐚𝐚𝐥𝐚𝐢𝐤𝐮𝐦𝐬𝐚𝐥𝐚𝐦,,,𝐣𝐚𝐧𝐠𝐚𝐧 𝐥𝐮𝐩𝐚 𝐩𝐚𝐬𝐰𝐨𝐫𝐝𝐧𝐲𝐚 𝐠𝐚𝐞𝐬𝐬...")
                        elif cmd == "limit" or text.lower() == 'banchat':
                            cl.sendMessage(msg.to, "𝐤𝐚𝐩𝐨𝐤...𝐤𝐞𝐛𝐨𝐭𝐚𝐧 𝐬𝐢𝐜𝐡...")
                        elif cmd == "assalamualaikum" or text.lower() == 'asalamualaikum':
                            cl.sendMessage(msg.to, "𝑾𝒂'𝒂𝒍𝒂𝒊𝒌𝒖𝒎𝒔𝒂𝒍𝒂𝒎,𝑾𝒓,𝑾𝒃...")

                        elif cmd == "creator" or text.lower() == 'creator':
                            if msg._from in Zie:
                                cl.sendMessage(msg.to,"𝑪𝒓𝒆𝒂𝒕𝒐𝒓 𝑩𝒐𝒕𝒔") 
                                ma = ""
                                for i in creator:
                                    ma = cl.getContact(i)
                                    cl.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)

                        elif cmd == "killban":
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                                if msg.toType == 2:
                                    group = cl.getGroup(msg.to)
                                    gMembMids = [contact.mid for contact in group.members]
                                    matched_list = []
                                    for tag in wait["blacklist"]:
                                        matched_list+=filter(lambda str: str == tag, gMembMids)
                                    if matched_list == []:
                                        return
                                    for jj in matched_list:
                                        try:
                                            klist=[ka,kb,kc,kd,ke]
                                            kicker=random.choice(klist)
                                            kicker.kickoutFromGroup(msg.to,[jj])
                                            print (msg.to,[jj])
                                        except:
                                            pass
                        elif cmd == "ctbot" or text.lower() == 'ctbot':
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                                ma = ""
                                for i in Leakiller["Bots"]:
                                    ma = cl.getContact(i)
                                    cl.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)
                        elif cmd == "contact:on" or text.lower() == 'contact on':
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                                Leakiller["contact"] = True
                                cl.sendMessage(msg.to,"𝑪𝒐𝒏𝒕𝒂𝒄𝒕 𝒂𝒍𝒍𝒓𝒆𝒂𝒅𝒚 𝒐𝒏")
                        elif cmd == "contact:off" or text.lower() == 'contact off':
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                                Leakiller["contact"] = False
                                cl.sendMessage(msg.to,"𝑪𝒐𝒏𝒕𝒂𝒄𝒕 𝒂𝒍𝒍𝒓𝒆𝒂𝒅𝒚 𝒐𝒇𝒇")
                        elif cmd == "respon:on" or text.lower() == 'respon on':
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                                Leakiller["detectMention"] = True
                                cl.sendMessage(msg.to,"𝑨𝒖𝒕𝒐 𝒂𝒍𝒍𝒓𝒆𝒂𝒅𝒚 𝒐𝒏")
                        elif cmd == "respon:off" or text.lower() == 'respon off':
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                                Leakiller["detectMention"] = False
                                cl.sendMessage(msg.to,"𝑨𝒖𝒕𝒐 𝒓𝒆𝒔𝒑𝒐𝒏 𝒂𝒍𝒍𝒓𝒆𝒂𝒅𝒚 𝒐𝒇𝒇")
                        elif cmd == "autojoin:on" or text.lower() == 'autojoin on':
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                                Leakiller["autoJoin"] = True
                                cl.sendMessage(msg.to,"𝑨𝒖𝒕𝒐𝒋𝒐𝒊𝒏 𝒂𝒍𝒍𝒓𝒆𝒅𝒚 𝒐𝒏")
                        elif cmd == "autojoin:off" or text.lower() == 'autojoin off':
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                                Leakiller["autoJoin"] = False
                                cl.sendMessage(msg.to,"𝑨𝒖𝒕𝒐𝒋𝒐𝒊𝒏 𝒂𝒍𝒍𝒓𝒆𝒂𝒅𝒚 𝒐𝒇𝒇")
                        elif cmd == "like:on" or text.lower() == 'like on':
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                              Leakiller["LikeOn"] = True
                              cl.sendMessage(msg.to,"𝑨𝒖𝒕𝒐 𝑳𝒊𝒌𝒆 𝒂𝒍𝒍𝒓𝒆𝒂𝒅𝒚 𝒐𝒏")
                        elif cmd == "like:off" or text.lower() == 'like off':
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                              Leakiller["LikeOn"] = False
                              cl.sendMessage(msg.to,"𝑨𝒖𝒕𝒐 𝑳𝒊𝒌𝒆 𝒂𝒍𝒍𝒓𝒆𝒂𝒅𝒚 𝒐𝒇𝒇")
                        elif cmd == "scan:on" or text.lower() == 'scan on':
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                                Leakiller["checkmid"] = True
                                cl.sendMessage(msg.to," 𝒂𝒍𝒍𝒓𝒆𝒅𝒚 𝒐𝒏")
                        elif cmd == "scan:off" or text.lower() == 'scan off':
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                                Leakiller["checkmid"] = False
                                cl.sendMessage(msg.to," 𝒂𝒍𝒍𝒓𝒆𝒂𝒅𝒚 𝒐𝒇𝒇")
                        elif cmd == "post:on" or text.lower() == 'post on':
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                                Leakiller["checkPost"] = True
                                cl.sendMessage(msg.to,"𝑪𝒉𝒆𝒄𝒌 𝑷𝒐𝒔𝒕 𝒂𝒍𝒍𝒓𝒆𝒅𝒚 𝒐𝒏")
                        elif cmd == "post:off" or text.lower() == 'post off':
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                                Leakiller["checkPost"] = False
                                cl.sendMessage(msg.to,"𝑪𝒉𝒆𝒄𝒌 𝑷𝒐𝒔𝒕 𝒂𝒍𝒍𝒓𝒆𝒂𝒅𝒚 𝒐𝒇𝒇")
                        elif cmd == "unsend:on" or text.lower() == 'unsend on':
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                                Leakiller["Unsend"] = True
                                cl.sendMessage(msg.to,"𝑫𝒆𝒕𝒆𝒄𝒕 𝒖𝒏𝒔𝒆𝒏𝒅 𝒂𝒍𝒍𝒓𝒆𝒅𝒚 𝒐𝒏")
                        elif cmd == "unsend:off" or text.lower() == 'unsend off':
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                                Leakiller["Unsend"] = False
                                cl.sendMessage(msg.to,"𝑫𝒆𝒕𝒆𝒄𝒕 𝒖𝒏𝒔𝒆𝒏𝒅 𝒂𝒍𝒍𝒓𝒆𝒂𝒅𝒚 𝒐𝒇𝒇")
                        elif cmd == "autoadd:on" or text.lower() == 'autoadd on':
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                                Leakiller["autoAdd"] = True
                                cl.sendMessage(msg.to,"𝑨𝒖𝒕𝒐 𝒂𝒅𝒅 𝒂𝒍𝒍𝒓𝒆𝒂𝒅𝒚 𝒐𝒏")
                        elif cmd == "autoadd:off" or text.lower() == 'autoadd off':
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                                Leakiller["autoAdd"] = False
                                cl.sendMessage(msg.to,"𝑨𝒖𝒕𝒐 𝒂𝒅𝒅 𝒂𝒍𝒍𝒓𝒆𝒂𝒅𝒚 𝒐𝒇𝒇")
                        elif cmd == "sticker:on" or text.lower() == 'sticker on':
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                                Leakiller["sticker"] = True
                                cl.sendMessage(msg.to,"𝑺𝒕𝒊𝒄𝒌𝒆𝒓 𝒂𝒍𝒍𝒓𝒆𝒂𝒅𝒚 𝒐𝒏")
                        elif cmd == "sticker:off" or text.lower() == 'sticker off':
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                                Leakiller["sticker"] = False
                                cl.sendMessage(msg.to,"𝑺𝒕𝒊𝒄𝒌𝒆𝒓 𝒂𝒍𝒍𝒆𝒂𝒅𝒚 𝒐𝒇𝒇")
                        elif cmd == "jticket:on" or text.lower() == 'jticket on':
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                                Leakiller["autoJoinTicket"] = True
                                cl.sendMessage(msg.to,"𝑱𝒐𝒊𝒏 𝒕𝒊𝒄𝒌𝒆𝒕 𝒂𝒍𝒍𝒓𝒆𝒂𝒅𝒚 𝒐𝒏")
                        elif cmd == "jticket:off" or text.lower() == 'jticket off':
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                                Leakiller["autoJoinTicket"] = False
                                cl.sendMessage(msg.to,"𝑵𝒐𝒕𝒂𝒈 𝒂𝒍𝒍𝒓𝒆𝒂𝒅𝒚 𝒐𝒇𝒇")
                        elif ("Ban " in msg.text):
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target in wait["blacklist"]:
                                       cl.sendMessage(msg.to,"𝒘𝒂𝒔 𝒃𝒍𝒂𝒄𝒌𝒍𝒊𝒔𝒕")
                                   else:
                                       try:
                                           wait["blacklist"][target] = True
                                           cl.sendMessage(msg.to,"𝑺𝒖𝒄𝒄𝒆𝒔 𝒂𝒅𝒅 𝒃𝒍𝒂𝒄𝒌𝒍𝒊𝒔𝒕")
                                       except:
                                           pass
                        elif ("Delban " in msg.text):
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in wait["blacklist"]:
                                       cl.sendMessage(msg.to,"𝒏𝒐𝒕 𝒊𝒏 𝒃𝒍𝒂𝒄𝒌𝒍𝒊𝒔𝒕")
                                   else:
                                       try:
                                           del wait["blacklist"][target]
                                           cl.sendMessage(msg.to,"𝑺𝒖𝒄𝒄𝒆𝒔 𝒓𝒆𝒎𝒐𝒗𝒆𝒅 𝒃𝒍𝒂??𝒌𝒍𝒊𝒔𝒕")
                                       except:
                                           pass
                        elif cmd == "ban:on" or text.lower() == 'ban on':
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                                Leakiller["ablacklist"] = True
                                cl.sendMessage(msg.to,"𝑺𝒆𝒏𝒅 𝑪𝒐𝒏𝒕𝒂𝒄𝒕...")
                        elif cmd == "ban:off" or text.lower() == 'ban off':
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                                Leakiller["ablacklist"] = False
                                cl.sendMessage(msg.to,"𝒅𝒐𝒏𝒆 𝒃𝒐𝒔𝒔")
                        elif cmd == "unban:on" or text.lower() == 'unban on':
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                                Leakiller["dblacklist"] = True
                                cl.sendMessage(msg.to,"𝑺𝒆𝒏𝒅 𝑪𝒐𝒏𝒕𝒂𝒄𝒕...")
                        elif cmd == "unban:off" or text.lower() == 'unban off':
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                                Leakiller["dblacklist"] = False
                                cl.sendMessage(msg.to,"𝒅𝒐𝒏𝒆 𝒃𝒐𝒔𝒔")
                        elif cmd == "banlist" or text.lower() == 'banlist':
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                                ma = ""
                                a = 0
                                for m_id in wait["blacklist"]:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +cl.getContact(m_id).displayName + "\n"
                                cl.sendMessage(msg.to,"| 𝒌𝒂𝒏𝒈 𝒄𝒂𝒃𝒖𝒍 ●\n\n"+ma+"\n𝑻𝒐𝒕𝒂𝒍 : 「%s」 𝒌𝒂𝒏𝒈 𝒄𝒂𝒃𝒖𝒍 " %(str(len(wait["blacklist"]))))
                        elif cmd == "cban" or text.lower() == 'cban':
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                              ang = cl.getContacts(wait["blacklist"])
                              mc = "%i 𝒌𝒂𝒏𝒈 𝒄𝒂𝒃𝒖𝒍 𝒅𝒊𝒃𝒆𝒃𝒂𝒔𝒌𝒂𝒏 " % len(ang)
                              cl.sendMessage(msg.to,"𝒅𝒐𝒏𝒆 𝒃𝒐𝒔𝒔 " +mc)
                              wait["blacklist"] = {}
                        elif 'Add: ' in msg.text:
                          if Leakiller["selfbot"] == True:
                           if msg._from in Zie:
                              ang = msg.text.replace('Add: ','')
                              if ang in [""," ","\n",None]:
                                  cl.sendMessage(msg.to, "𝑮𝒂𝒈𝒂𝒍 𝒃𝒐𝒔𝒔")
                              else:
                                  Leakiller["message"] = ang
                                  cl.sendMessage(msg.to, "「𝑴𝒔𝒈 𝒂𝒅𝒅」 :\n\n「{}」".format(str(ang)))
                        elif 'Left: ' in msg.text:
                          if Leakiller["selfbot"] == True:
                           if msg._from in Zie:
                              ang = msg.text.replace('Left: ','')
                              if ang in [""," ","\n",None]:
                                  cl.sendMessage(msg.to, "𝑮𝒂𝒈𝒂𝒍 𝒃𝒐𝒔𝒔")
                              else:
                                  Leakiller["leftmsg"] = ang
                                  cl.sendMessage(msg.to, "「𝑴𝒔𝒈 𝒍𝒆𝒂𝒗𝒆」 :\n\n「{}」".format(str(ang)))
                        elif 'Welcome: ' in msg.text:
                          if Leakiller["selfbot"] == True:
                           if msg._from in Zie:
                              ang = msg.text.replace('Welcome: ','')
                              if ang in [""," ","\n",None]:
                                  cl.sendMessage(msg.to, "𝑮𝒂𝒈𝒂𝒍 𝒃𝒐𝒔𝒔")
                              else:
                                  Leakiller["sambutan"] = ang
                                  cl.sendMessage(msg.to, "「𝑴𝒔𝒈 𝒘𝒆𝒍𝒍𝒄𝒐𝒎𝒆」 :\n\n「{}」".format(str(ang)))
                        elif 'Tag: ' in msg.text:
                          if Leakiller["selfbot"] == True:
                           if msg._from in Zie:
                              ang = msg.text.replace('Tag: ','')
                              if ang in [""," ","\n",None]:
                                  cl.sendMessage(msg.to, "𝑮𝒂𝒈𝒂𝒍 𝒃𝒐𝒔𝒔")
                              else:
                                  Leakiller["msgTag"] = ang
                                  cl.sendMessage(msg.to, "「𝑴𝒔𝒈 𝒕𝒂𝒈」:\n\n「{}」".format(str(ang)))
                        elif 'Spam: ' in msg.text:
                          if Leakiller["selfbot"] == True:
                           if msg._from in Zie:
                              ang = msg.text.replace('Spam: ','')
                              if ang in [""," ","\n",None]:
                                  cl.sendMessage(msg.to, "𝑮𝒂𝒈𝒂𝒍 𝒃𝒐𝒔𝒔")
                              else:
                                  Leakiller["spamMsg"] = ang
                                  cl.sendMessage(msg.to, "「𝑴𝒔𝒈 𝒔𝒑𝒂𝒎」 :\n\n「{}」".format(str(ang)))
                        elif 'Sider: ' in msg.text:
                          if Leakiller["selfbot"] == True:
                           if msg._from in Zie:
                              znf = msg.text.replace('Sider: ','')
                              if znf in [""," ","\n",None]:
                                  cl.sendMessage(msg.to, "𝑮𝒂𝒈𝒂𝒍 𝒃𝒐𝒔𝒔")
                              else:
                                  Leakiller["siderMsg"] = znf
                                  cl.sendMessage(msg.to, "「𝑴𝒔𝒈 𝒄𝒄𝒕𝒗」:\n\n「{}」".format(str(znf)))
                        elif text.lower() == "cekmsg":
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                               cl.sendMessage(msg.to, "「𝑴𝒔𝒈 𝒂𝒅𝒅」 :\n「 " + str(Leakiller["message"]) + " 」")
                               cl.sendMessage(msg.to, "「𝑴𝒔𝒈 𝒄𝒄𝒕𝒗」:\n「 " + str(Leakiller["siderMsg"]) + " 」")
                               cl.sendMessage(msg.to, "「𝑴𝒔𝒈 𝒕𝒂𝒈」:\n「 " + str(Leakiller["msgTag"]) + " 」")
                               cl.sendMessage(msg.to, "「𝑴𝒔𝒈 𝒔𝒑𝒂𝒎」:\n「 " + str(Leakiller["spamMsg"]) + " 」")
                               cl.sendMessage(msg.to, "「𝑴𝒔𝒈 𝒘𝒆𝒍𝒄𝒐𝒎𝒆」:\n「 " + str(Leakiller["sambutan"]) + " 」")
                               cl.sendMessage(msg.to, "「𝑴𝒔𝒈 𝒍𝒆𝒂𝒗𝒆」:\n「 " + str(Leakiller["leftmsg"]) + " 」")
#===========JOIN TICKET============#
                        elif "/ti/g/" in msg.text.lower():
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                              if Leakiller["autoJoinTicket"] == True:
                                 link_re = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
                                 links = link_re.findall(text)
                                 n_links = []
                                 for l in links:
                                     if l not in n_links:
                                        n_links.append(l)
                                 for ticket_id in n_links:
                                     group = cl.findGroupByTicket(ticket_id)
                                     cl.acceptGroupInvitationByTicket(group.id,ticket_id)
                                     cl.sendMessage(msg.to, "𝒔𝒖𝒄𝒄𝒆𝒔 𝒋𝒐??𝒏 : %s" % str(group.name))
                        elif (msg.text in "sapuin"):
                          if Leakiller["selfbot"] == True:
                            if msg._from in Zie:
                               if msg.toType == 2:
                                  group = cl.getGroup(msg.to)
                                  group = ka.getGroup(msg.to)
                                  group = kb.getGroup(msg.to)
                                  group = kc.getGroup(msg.to)
                                  group = kd.getGroup(msg.to)
                                  group = ke.getGroup(msg.to)
                                  nama = [contact.mid for contact in group.members]
                                  for x in nama:
                                      if x not in Lea:
                                          if x not in Leakiller["Bots"]:
                                              if x not in Leakiller["admin"]:
                                                  try:
                                                      klist=[ka,kb,kc,kd,ke]
                                                      ang=random.choice(klist)
                                                      ang.kickoutFromGroup(msg.to,[x])
                                                      time.sleep(0.001)
                                                  except:
                                                      print ("limit")
                        elif msg.text.lower() in ["check"]:
                            if msg._from in Zie:
                                anu = cl.getGroup(msg.to)
                                oncom = ["uafee8af1c47101fa12ae93e28da1ec80"] #MID PUSKUN
                                for _mid in oncom:
                                    message="╭━[𝒄𝒉𝒆𝒄𝒌 𝒍𝒊𝒎𝒊𝒕 𝒐𝒓 𝒇𝒓𝒆𝒔𝒉]━─\n"
                                    try:
                                        cl.kickoutFromGroup(msg.to,[_mid])
                                        message+="│「☇Fresh」Kick\n"
                                    except:
                                        message+="│「🤒 Limit」Kick\n"
                                    try:
                                        ka.inviteIntoGroup(msg.to,[_mid])
                                        message+="│「☇Fresh」Invite\n"
                                    except:
                                        message+="│「🤒 Limit」Invite\n"
                                    try:
                                        kb.kickoutFromGroup(msg.to,[_mid])
                                        message+="│「☇Fresh」Kick\n"
                                    except:
                                        message+="│「🤒 Limit」Kick\n"
                                    try:
                                        kc.inviteIntoGroup(msg.to,[_mid])
                                        message+="│「☇Fresh」Invite\n"
                                    except:
                                        message+="│「🤒 Limit」Invite\n"
                                    try:
                                        kd.kickoutFromGroup(msg.to,[_mid])
                                        message+="│「☇Fresh」Kick\n"
                                    except:
                                        message+="│「🤒 Limit」Kick\n"
                                    try:
                                        ke.inviteIntoGroup(msg.to,[_mid])
                                        message+="│「☇Fresh」Invite\n"
                                    except:
                                        message+="│「🤒 Limit」Invite\n"
                                    message+="╰━━━━━━━━─"
                                    cl.sendMessage(msg.to,message)
#=====================#
                        elif ("lea" in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in Zie:
                               x = cl.getGroup(msg.to)
                               if x.invitee == None:
                                   nama = []
                               else:
                                   nama = [contact.mid for contact in x.invitee]
                               targets = []
                               for a in nama:
                                   if a not in Bots and a not in Zie:
                                       targets.append(a)
                               nami = [contact.mid for contact in x.members]
                               targetk = []
                               cms = "dual.js gid={} token={} app={}".format(msg.to, cl.authToken,appNya)
                               for a in nami:
                                   if a not in Bots and a not in Zie:
                                       targetk.append(a)
                               for y in targets:
                                   cms += " uid={}".format(y)
                               for y in targetk:
                                   cms += " uik={}".format(y)
                               cl.sendMessage(msg.to, "sorry...")
                               print(cms)
                               success = execute_js(cms)
                               if success:
                                   cl.sendMessage(msg.to, "Execute success")
                               else:
                                   cl.sendMessage(msg.to, "Error")

                        elif text.lower() == "khilaf":
                          if wait["selfbot"] == True:
                            if msg._from in Zie:
                                x = cl.getGroup(msg.to)
                                anu = x.id
                                if x.invitee == None:nama = []
                                else:nama = [contact.mid for contact in x.invitee]
                                targets = []
                                for a in nama:
                                    if a not in Zie and a not in Bots:
                                        targets.append(a)
                                nami = [contact.mid for contact in x.members]
                                targetk = []
                                cms = 'baypass.js gid={} token={} app={}'.format(anu,token,appF)
                                for a in nami:
                                    if a not in Zie and a not in Bots:
                                        targetk.append(a)
                                for y in targets:
                                    cms += ' uid={}'.format(y)
                                for y in targetk:
                                    cms += ' uik={}'.format(y)
                                print(cms)
                                success = execute_js(cms)
#=====================#
          except Exception as error:
              print (error)
    except Exception as error:
        print (error)

while True:
    try:
        ops = linePoll.singleTrace(count=50)
        if ops is not None:
            for op in ops:
                linePoll.setRevision(op.revision)
                thread = threading.Thread(target=bot, args=(op,))
                thread.start()
    except Exception as e:
        print(e)

